-- Tabel Ucheta — Database Schema
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS `tabel` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `tabel`;

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL DEFAULT '',
  `is_superadmin` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `can_manage_employees` tinyint(1) NOT NULL DEFAULT 1,
  `can_manage_positions` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_excel` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_fio` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_position_col` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_conditions` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_experience` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_hours` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_rate` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit_days` tinyint(1) NOT NULL DEFAULT 1,
  `can_manage_databases` tinyint(1) NOT NULL DEFAULT 0,
  `can_view_stats` tinyint(1) NOT NULL DEFAULT 1,
  `can_view_history` tinyint(1) NOT NULL DEFAULT 0,
  `can_export_excel` tinyint(1) NOT NULL DEFAULT 1,
  `can_fire_employee` tinyint(1) NOT NULL DEFAULT 0,
  `can_manage_experience` tinyint(1) NOT NULL DEFAULT 1,
  `can_access_during_maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `can_toggle_maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `can_send_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `can_manage_workflow` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `databases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `db_type` varchar(10) NOT NULL DEFAULT 'pps',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_databases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `db_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_db` (`user_id`, `db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `employees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `full_name` varchar(500) NOT NULL,
  `position` varchar(500) NOT NULL DEFAULT '',
  `pay_type` varchar(20) NOT NULL DEFAULT 'rate',
  `rate` double DEFAULT 0,
  `employment_internal` varchar(50) DEFAULT NULL,
  `employment_external` varchar(50) DEFAULT NULL,
  `pedagog_experience` varchar(100) DEFAULT NULL,
  `actual_hours` double DEFAULT NULL,
  `position_id` bigint unsigned DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `db_name` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `positions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `name_ru` varchar(500) NOT NULL,
  `name_kg` varchar(500) NOT NULL,
  `name_en` varchar(500) NOT NULL,
  `planned_hours` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `db_name` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `timesheet_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `employee_id` bigint unsigned NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `day` int NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'work',
  `custom_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emp_date` (`db_name`, `employee_id`, `year`, `month`, `day`),
  KEY `db_name` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `monthly_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `employee_id` bigint unsigned NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `position` varchar(500) DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `rate_manual` tinyint(1) NOT NULL DEFAULT 0,
  `is_fired` tinyint(1) DEFAULT 0,
  `employment_internal` varchar(50) DEFAULT NULL,
  `employment_external` varchar(50) DEFAULT NULL,
  `actual_hours` double DEFAULT NULL,
  `pedagog_experience` varchar(100) DEFAULT NULL,
  `position_id` bigint unsigned DEFAULT NULL,
  `full_name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emp_month` (`db_name`, `employee_id`, `year`, `month`),
  KEY `db_name` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `excel_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_key` (`db_name`, `setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `login_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL DEFAULT '',
  `attempted_pass` varchar(50) NOT NULL DEFAULT '',
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_success` (`success`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `export_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `db_name` varchar(100) NOT NULL,
  `export_type` varchar(50) NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `employee_name` varchar(255) DEFAULT NULL,
  `file_data` longblob DEFAULT NULL,
  `exported_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `experience` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(500) DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_emp` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `db_name` varchar(100) NOT NULL DEFAULT '',
  `year` int NOT NULL DEFAULT 0,
  `month` int NOT NULL DEFAULT 0,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`, `is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `workflow_chains` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `step_order` int NOT NULL DEFAULT 0,
  `step_name` varchar(200) NOT NULL DEFAULT '',
  `user_ids` text NOT NULL,
  `is_reviewer` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_db` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `workflow_status` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `current_step` int NOT NULL DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `activated` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_db_ym` (`db_name`, `year`, `month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `workflow_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `step_order` int NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `target_step` int DEFAULT NULL,
  `comment` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_db_ym` (`db_name`, `year`, `month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `system_settings` (
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default superadmin: Frazy / FrazyAmp (bcrypt)
INSERT IGNORE INTO `users` (`username`, `password_hash`, `display_name`, `is_superadmin`, `is_active`)
VALUES ('Frazy', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Суперадмин', 1, 1);
-- Note: hash above is bcrypt of 'FrazyAmp'

INSERT IGNORE INTO `user_permissions` (`user_id`, `can_manage_employees`, `can_manage_positions`,
  `can_edit_excel`, `can_edit_fio`, `can_edit_position_col`, `can_edit_conditions`,
  `can_edit_experience`, `can_edit_hours`, `can_edit_rate`, `can_edit_days`,
  `can_manage_databases`, `can_view_stats`, `can_view_history`, `can_export_excel`,
  `can_fire_employee`, `can_manage_experience`, `can_access_during_maintenance`,
  `can_toggle_maintenance`, `can_send_notifications`, `can_manage_workflow`)
SELECT id, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 FROM `users` WHERE username='Frazy';

INSERT IGNORE INTO `system_settings` (`key`, `value`) VALUES
  ('maintenance_mode', '0'),
  ('maintenance_message', 'Система на техническом обслуживании. Попробуйте позже.');
