// ─── Calendar ───
function getMonthCalendar(year, month) {
  const daysInMonth = new Date(year, month, 0).getDate();
  const days = [];
  for (let d = 1; d <= daysInMonth; d++) {
    const dt = new Date(year, month - 1, d);
    const wd = dt.getDay(); // 0=Sun, 1=Mon...6=Sat
    const weekday = wd === 0 ? 6 : wd - 1; // 0=Mon..6=Sun
    days.push({ day: d, weekday, is_sunday: wd === 0 });
  }
  return days;
}

function getDayNames(lang) {
  if (lang === 'ru') return ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
  if (lang === 'kg') return ['Дш','Шш','Шр','Бш','Жм','Иш','Жш'];
  return ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
}

// ─── Status → Mark mapping ───
function statusToMark() {
  return {
    vacation: 'К', sick: 'О', business_trip: 'С',
    maternity: 'КӨ', childcare: 'БӨ', study_leave: 'ОӨ',
    admin_leave: 'АӨ', absence: 'Дк', late: 'Кк', early_leave: 'Эк',
  };
}

async function getStatusToMarkFromDb(db, dbName) {
  try {
    const row = await db.queryOne(
      "SELECT setting_value FROM excel_settings WHERE db_name = ? AND setting_key = 'marks_list'",
      [dbName]
    );
    if (row) {
      const list = JSON.parse(row.setting_value);
      if (Array.isArray(list)) {
        const map = {};
        for (const item of list) {
          if (item.status && item.symbol) map[item.status] = item.symbol;
        }
        if (Object.keys(map).length > 0) return map;
      }
    }
  } catch (e) {}
  return statusToMark();
}

// ─── Employee month calculation ───
function calcEmployeeMonth(employee, entriesDict, daysInfo, dbType = 'pps') {
  const rate = parseFloat(employee.rate) || 0;
  const payType = employee.pay_type || 'rate';
  const stm = statusToMark();
  const dailyValue = (dbType !== 'staff' && payType === 'rate') ? rate * 6 : 0;

  let workingDays = 0, weekends = 0, holidays = 0;
  const dayCells = [];
  let totalPayAccum = 0.0;
  const markCounts = {};

  for (const di of daysInfo) {
    const { day, weekday, is_sunday } = di;
    const entry = entriesDict[day] || null;
    const status = entry ? entry.status : (is_sunday ? 'day_off' : 'work');
    const custom = entry ? (entry.custom_value || null) : null;

    const isWorking = status === 'work';
    if (isWorking) workingDays++;
    else if (status === 'day_off') weekends++;
    else if (status === 'holiday') holidays++;

    const mark = stm[status] || null;
    if (mark) markCounts[mark] = (markCounts[mark] || 0) + 1;
    if (custom && !mark) markCounts[custom] = (markCounts[custom] || 0) + 1;

    let cellDisplay;
    if (dbType === 'staff') {
      if (payType === 'rate' && isWorking) {
        const dayVal = weekday === 5 ? Math.round(rate * 5 * 100) / 100 : Math.round(rate * 7 * 100) / 100;
        totalPayAccum += dayVal;
        cellDisplay = dayVal;
      } else {
        cellDisplay = isWorking ? '+' : (stm[status] || (status === 'sick' ? 'О' : '-'));
      }
    } else {
      if (payType === 'rate') {
        cellDisplay = isWorking ? Math.round(dailyValue * 100) / 100 : (stm[status] || (status === 'sick' ? 'О' : '-'));
      } else {
        cellDisplay = isWorking ? '+' : (stm[status] || (status === 'sick' ? 'О' : '-'));
      }
    }

    if (custom && status === 'work') cellDisplay = custom;

    dayCells.push({ day, weekday, is_sunday, status, display: cellDisplay, custom_value: custom });
  }

  const workingHours = (dbType !== 'staff' && payType === 'rate') ? Math.round(workingDays * dailyValue * 100) / 100 : 0;
  const totalPay = dbType === 'staff'
    ? (payType === 'rate' ? Math.round(totalPayAccum * 100) / 100 : rate)
    : (payType === 'rate' ? Math.round(workingDays * dailyValue * 100) / 100 : rate);

  return {
    day_cells: dayCells,
    working_days: workingDays,
    working_hours: workingHours,
    total_pay: totalPay,
    total_days: daysInfo.length,
    weekends,
    holidays,
    daily_value: dailyValue,
    mark_counts: markCounts,
  };
}

// ─── Experience calculation ───
function calcExperience(periods, asOfDate = null) {
  const asOf = asOfDate ? new Date(asOfDate) : new Date();
  let totalDays = 0;

  for (const p of periods) {
    const from = new Date(p.date_from);
    let to = p.is_current ? asOf : (p.date_to ? new Date(p.date_to) : asOf);
    if (to > asOf) to = asOf;
    if (from > to) continue;
    const diff = Math.floor((to - from) / (1000 * 60 * 60 * 24));
    totalDays += diff;
  }

  const years = Math.floor(totalDays / 365);
  const months = Math.floor((totalDays % 365) / 30);
  const days = totalDays % 365 % 30;

  let display = '';
  if (years > 0) display = `${years} г. ${months} м.`;
  else if (months > 0) display = `${months} м. ${days} д.`;
  else display = `${days} д.`;

  return { total_days: totalDays, years, months, days, display, periods };
}

// ─── Get employees for month batch ───
async function getEmployeesForMonthBatch(db, employees, year, month, dbName) {
  if (!employees.length) return {};

  const empIds = employees.map(e => parseInt(e.id));
  const placeholders = empIds.map(() => '?').join(',');

  const rows = await db.query(
    `SELECT employee_id, position, rate, rate_manual, employment_internal, employment_external,
            actual_hours, pedagog_experience, position_id, full_name, year, month
     FROM monthly_settings WHERE db_name = ? AND employee_id IN (${placeholders})
     AND (year < ? OR (year = ? AND month <= ?))
     ORDER BY employee_id, year DESC, month DESC`,
    [dbName, ...empIds, year, year, month]
  );

  const grouped = {};
  for (const row of rows) {
    const eid = parseInt(row.employee_id);
    if (!grouped[eid]) grouped[eid] = [];
    grouped[eid].push(row);
  }

  const result = {};
  for (const emp of employees) {
    const eid = parseInt(emp.id);
    const empRows = grouped[eid] || [];
    const e = { ...emp };

    if (!empRows.length) {
      e.rate_manual = 0;
      result[eid] = e;
      continue;
    }

    const fields = ['full_name', 'position', 'rate', 'actual_hours', 'pedagog_experience', 'position_id'];
    const found = {};
    let rateManualFound = false;

    for (const row of empRows) {
      for (const f of fields) {
        if (!found[f] && row[f] !== null && row[f] !== undefined) {
          found[f] = true;
          if (f === 'rate') {
            e.rate = parseFloat(row.rate);
            e.rate_manual = parseInt(row.rate_manual);
            rateManualFound = true;
          } else if (f === 'actual_hours') {
            e.actual_hours = parseFloat(row.actual_hours);
          } else if (f === 'position_id') {
            e.position_id = parseInt(row.position_id);
          } else {
            e[f] = row[f];
          }
        }
      }

      if (!found._employment) {
        const hasEmpSet = row.employment_internal !== null || row.employment_external !== null;
        const hasOther = row.position !== null || row.rate !== null ||
          row.actual_hours !== null || row.pedagog_experience !== null ||
          row.position_id !== null || row.full_name !== null;
        if (hasEmpSet || !hasOther) {
          found._employment = true;
          e.employment_internal = row.employment_internal;
          e.employment_external = row.employment_external;
        }
      }

      if (Object.keys(found).length >= fields.length + 1) break;
    }

    if (!rateManualFound) e.rate_manual = 0;
    result[eid] = e;
  }

  return result;
}

// ─── IP Helper ───
function getClientIp(req) {
  const keys = ['x-forwarded-for', 'x-real-ip', 'x-client-ip'];
  for (const k of keys) {
    if (req.headers[k]) {
      const ip = req.headers[k].split(',')[0].trim();
      if (ip) return ip;
    }
  }
  return req.socket.remoteAddress || '0.0.0.0';
}

// ─── Month keys ───
function getMonthKeys() {
  return ['january','february','march','april','may','june','july','august','september','october','november','december'];
}

module.exports = {
  getMonthCalendar, getDayNames, statusToMark, getStatusToMarkFromDb,
  calcEmployeeMonth, calcExperience, getEmployeesForMonthBatch,
  getClientIp, getMonthKeys,
};
