const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306'),
  database: process.env.DB_NAME || 'tabel',
  user: process.env.DB_USER || 'tabel',
  password: process.env.DB_PASS || 'tabelpass',
  waitForConnections: true,
  connectionLimit: 20,
  charset: 'utf8mb4',
  timezone: '+00:00',
});

async function query(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

async function insert(table, data) {
  const keys = Object.keys(data);
  const values = Object.values(data);
  const placeholders = keys.map(() => '?').join(', ');
  const sql = `INSERT INTO \`${table}\` (\`${keys.join('`, `')}\`) VALUES (${placeholders})`;
  const [result] = await pool.execute(sql, values);
  return result.insertId;
}

async function update(table, data, where) {
  const setClause = Object.keys(data).map(k => `\`${k}\` = ?`).join(', ');
  const whereClause = Object.keys(where).map(k => `\`${k}\` = ?`).join(' AND ');
  const sql = `UPDATE \`${table}\` SET ${setClause} WHERE ${whereClause}`;
  const [result] = await pool.execute(sql, [...Object.values(data), ...Object.values(where)]);
  return result.affectedRows;
}

async function remove(table, where) {
  const whereClause = Object.keys(where).map(k => `\`${k}\` = ?`).join(' AND ');
  const sql = `DELETE FROM \`${table}\` WHERE ${whereClause}`;
  const [result] = await pool.execute(sql, Object.values(where));
  return result.affectedRows;
}

async function upsert(table, data, keys) {
  const allKeys = Object.keys(data);
  const values = Object.values(data);
  const placeholders = allKeys.map(() => '?').join(', ');
  const updateClause = allKeys
    .filter(k => !keys.includes(k))
    .map(k => `\`${k}\` = VALUES(\`${k}\`)`)
    .join(', ');
  const sql = `INSERT INTO \`${table}\` (\`${allKeys.join('`, `')}\`) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${updateClause}`;
  const [result] = await pool.execute(sql, values);
  return result.insertId || result.affectedRows;
}

module.exports = { pool, query, queryOne, insert, update, remove, upsert };
