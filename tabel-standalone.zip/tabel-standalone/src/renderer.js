'use strict';
const fs = require('fs');
const path = require('path');

const MONTH_KEYS = ['january','february','march','april','may','june','july','august',
  'september','october','november','december'];

const ALL_T = {
  ru: {
    app_title:'Табель учёта рабочего времени',employees:'Сотрудники',timesheet:'Табель',
    add_employee:'Добавить сотрудника',full_name:'ФИО',position:'Должность',
    pay_type:'Тип оплаты',rate:'Ставка',employment_internal:'Внутренний',
    employment_external:'Внешний',internal:'Внутренний',external:'Внешний',
    staff:'Штат',part_time:'Совместитель',pedagog_experience:'Пед. стаж',
    actual_hours:'Факт. часы',positions:'Должности',add_position:'Добавить должность',
    planned_hours:'Плановые часы',vacation:'Каникулы',business_trip:'Командировка',
    maternity:'Декрет',childcare:'Уход за ребенком',study_leave:'Учебный отпуск',
    admin_leave:'Адм. выходной',absence:'Неявка',late:'Опоздание',early_leave:'Ранний уход',
    fixed:'Фиксированная сумма',rate_based:'По ставке',fixed_based:'Без ставки (фикс.)',
    save:'Сохранить',cancel:'Отмена',delete:'Удалить',edit:'Редактировать',
    month:'Месяц',year:'Год',current_month:'Текущий месяц',
    prev_month:'Предыдущий месяц',next_month:'Следующий месяц',
    select_month:'Выбрать месяц',export_excel:'Скачать Excel',
    export_full:'Полный отчёт',export_brief:'Краткий отчёт',export_employee:'По сотруднику',
    working_days:'Рабочие дни',working_hours:'Рабочие часы',days_in_month:'Дней в месяце',
    weekends:'Выходные',holidays:'Праздники',total_pay:'Итого к выплате',
    day:'День',sun:'Вс',mon:'Пн',tue:'Вт',wed:'Ср',thu:'Чт',fri:'Пт',sat:'Сб',
    work:'Работа',day_off:'Выходной',holiday:'Праздник',sick:'Больничный',absent:'Не работал',
    no_employees:'Нет сотрудников. Добавьте первого!',
    confirm_delete:'Вы уверены, что хотите удалить этого сотрудника?',
    select_month_prompt:'Какой месяц редактируем?',number:'№',status:'Статус',
    hint_fio:'Начните вводить ФИО',hint_position:'Должность подставится автоматически',
    hint_rate:'Для "По ставке" — дневная ставка',hint_day_cell:'Нажмите для выбора',
    hint_export:'Скачайте отчёт в Excel',hint_sunday:'Воскресенья — выходные',
    hint_pay_type:'По ставке: зарплата = ставка × 6 × рабочие дни',
    language:'Язык',settings:'Настройки',custom_value:'Своё значение',
    enter_value:'Введите значение',total:'Итого',summary:'Сводка',
    worked_days_total:'Отработано дней',worked_hours_total:'Отработано часов',brief_suffix:'краткий',
    january:'Январь',february:'Февраль',march:'Март',april:'Апрель',
    may:'Май',june:'Июнь',july:'Июль',august:'Август',
    september:'Сентябрь',october:'Октябрь',november:'Ноябрь',december:'Декабрь',
    official_marks:'Расмий белгилер',for_all_employees:'Для всех сотрудников',
    select_position:'Выберите должность',employment_conditions:'Условия работы',
    click_to_change_all:'Клик для изменения всех',click_to_change_employment:'Клик для изменения условий',
    click_to_select_position:'Клик для выбора должности',
    actual_hours_hint:'Фактические часы',rate_hint:'Ставка или фикс. сумма',
    rate_manual_hint:'Ставка установлена вручную. Дважды кликните для сброса.',
    rate_reset_confirm:'Сбросить ручную ставку и пересчитать автоматически?',
    statistics:'Статистика',export_history:'История экспортов',
    not_selected:'Не выбрано',staff_internal:'Штатный',
    part_time_internal:'Совм. внутренний',part_time_external:'Совм. внешний',
    es_title:'Excel Заголовок и Условные Обозначения',es_save_all:'Сохранить всё',
    es_header_panel:'Заголовок (шапка Excel)',es_left:'ЛЕВО — Согласовано',
    es_center:'ЦЕНТР — Университет',es_right:'ПРАВО — Утверждаю',
    es_row1:'Строка 1',es_row2:'Строка 2',es_row3:'Строка 3',
    es_left_col:'Лево',es_center_col:'Центр',es_right_col:'Право',
    es_department:'Кафедра',es_signatures:'Строки подписей',
    es_sig1:'Подпись 1',es_sig2:'Подпись 2',es_sig3:'Подпись 3',
    es_marks_panel:'Условные Обозначения (лист 2 Excel)',
    es_symbol:'Символ',es_description:'Описание',es_status:'Статус',
    es_add_mark:'Добавить обозначение',
  },
  kg: {
    app_title:'Иш убактысын эсепке алуу',employees:'Кызматкерлер',timesheet:'Табель',
    add_employee:'Кызматкер кошуу',full_name:'Аты-жөнү',position:'Кызматы',
    pay_type:'Төлөм түрү',rate:'Ставка',employment_internal:'Ички',
    employment_external:'Тышкы',internal:'Ички',external:'Тышкы',
    staff:'Штат',part_time:'Кош жумуштуу',pedagog_experience:'Пед. тажрыйба',
    actual_hours:'Факт. саат',positions:'Кызмат орундары',add_position:'Кызмат кошуу',
    planned_hours:'Пландаштырылган саат',vacation:'Каникулдар',business_trip:'Иш сапарлар',
    maternity:'Кош бойлуулук жана төрөт өргүү',childcare:'Бала багуу боюнча өргүү',
    study_leave:'Окуусуна байланыштуу эмгек акысыз өргүү',
    admin_leave:'Администрация тарабынан эмгек акысыз берилген дем алыш күнү',
    absence:'Дайынсыз ишке келбей калуу',late:'Ишке кечигип келүү',early_leave:'Иштен эрте кетип калуу',
    fixed:'Туруктуу сумма',rate_based:'Ставка боюнча',fixed_based:'Ставкасыз (туруктуу)',
    save:'Сактоо',cancel:'Жокко чыгаруу',delete:'Өчүрүү',edit:'Өзгөртүү',
    month:'Ай',year:'Жыл',current_month:'Учурдагы ай',
    prev_month:'Өткөн ай',next_month:'Кийинки ай',select_month:'Айды тандоо',
    export_excel:'Excel жүктөө',export_full:'Толук отчёт',export_brief:'Кыскача отчёт',export_employee:'Кызматкер боюнча',
    working_days:'Жумуш күндөрү',working_hours:'Жумуш сааттары',
    days_in_month:'Айдагы күндөр',weekends:'Дем алыш',holidays:'Майрамдар',
    total_pay:'Жалпы төлөм',day:'Күн',
    sun:'Жш',mon:'Дш',tue:'Шш',wed:'Шр',thu:'Бш',fri:'Жм',sat:'Иш',
    work:'Жумуш',day_off:'Дем алыш',holiday:'Майрам',sick:'Оорулуу',absent:'Иштеген жок',
    no_employees:'Кызматкерлер жок. Биринчисин кошуңуз!',
    confirm_delete:'Бул кызматкерди өчүрүүнү каалайсызбы?',
    select_month_prompt:'Кайсы айды оңдойбуз?',number:'№',status:'Статус',
    hint_fio:'Аты-жөнүн жаза баштаңыз',hint_position:'Кызматы автоматтык коюлат',
    hint_rate:'Ставка боюнча — күндүк ставка',hint_day_cell:'Тандоо үчүн басыңыз',
    hint_export:'Excel отчётун жүктөңүз',hint_sunday:'Жекшемби — дем алыш',
    hint_pay_type:'Ставка боюнча: айлык = ставка × 6 × жумуш күндөрү',
    language:'Тил',settings:'Жөндөөлөр',custom_value:'Башка маани',
    enter_value:'Маани киргизиңиз',total:'Жалпы',summary:'Жыйынтык',
    worked_days_total:'Иштеген күндөр',worked_hours_total:'Иштеген сааттар',brief_suffix:'кыскача',
    january:'Январь',february:'Февраль',march:'Март',april:'Апрель',
    may:'Май',june:'Июнь',july:'Июль',august:'Август',
    september:'Сентябрь',october:'Октябрь',november:'Ноябрь',december:'Декабрь',
    official_marks:'Расмий белгилер',for_all_employees:'Бардык кызматкерлер үчүн',
    select_position:'Кызматты тандаңыз',employment_conditions:'Шарттары',
    click_to_change_all:'Бардыгын өзгөртүү',click_to_change_employment:'Шарттарды өзгөртүү',
    click_to_select_position:'Кызматты тандоо',
    actual_hours_hint:'Факттык сааттар',rate_hint:'Ставка же туруктуу сумма',
    rate_manual_hint:'Ставка кол менен коюлган. Кайтаруу үчүн эки жолу басыңыз.',
    rate_reset_confirm:'Кол менен коюлган ставканы баштапкы абалга келтирип, автоматтык түрдө эсептесинби?',
    statistics:'Статистика',export_history:'Экспорт тарыхы',
    not_selected:'Тандалган эмес',staff_internal:'Штаттык',
    part_time_internal:'Кош жумуш ички',part_time_external:'Кош жумуш тышкы',
    es_title:'Excel Баштык жана Шарттуу Белгилер',es_save_all:'Баарын сактоо',
    es_header_panel:'Баштык (Excel шапкасы)',es_left:'СОЛ — Макулдашылды',
    es_center:'ОРТ — Университет',es_right:'ОҢ — Бекитем',
    es_row1:'1-сап',es_row2:'2-сап',es_row3:'3-сап',
    es_left_col:'Сол',es_center_col:'Орт',es_right_col:'Оң',
    es_department:'Кафедра',es_signatures:'Колтамга саптары',
    es_sig1:'Колтамга 1',es_sig2:'Колтамга 2',es_sig3:'Колтамга 3',
    es_marks_panel:'Шарттуу Белгилер (Excel 2-баракча)',
    es_symbol:'Символ',es_description:'Сүрөттөмөсү',es_status:'Статус',
    es_add_mark:'Белги кошуу',
  },
  en: {
    app_title:'Work Time Tracking',employees:'Employees',timesheet:'Timesheet',
    add_employee:'Add Employee',full_name:'Full Name',position:'Position',
    pay_type:'Pay Type',rate:'Rate',employment_internal:'Internal',
    employment_external:'External',internal:'Internal',external:'External',
    staff:'Staff',part_time:'Part-time',pedagog_experience:'Teaching Exp.',
    actual_hours:'Actual Hours',positions:'Positions',add_position:'Add Position',
    planned_hours:'Planned Hours',vacation:'Vacation',business_trip:'Business Trip',
    maternity:'Maternity Leave',childcare:'Childcare Leave',study_leave:'Study Leave',
    admin_leave:'Admin Day Off',absence:'Absence',late:'Late',early_leave:'Early Leave',
    fixed:'Fixed Amount',rate_based:'Rate-based',fixed_based:'No rate (fixed)',
    save:'Save',cancel:'Cancel',delete:'Delete',edit:'Edit',
    month:'Month',year:'Year',current_month:'Current Month',
    prev_month:'Previous Month',next_month:'Next Month',select_month:'Select Month',
    export_excel:'Download Excel',export_full:'Full Report',export_brief:'Brief Report',export_employee:'By Employee',
    working_days:'Working Days',working_hours:'Working Hours',
    days_in_month:'Days in Month',weekends:'Weekends',holidays:'Holidays',
    total_pay:'Total Pay',day:'Day',
    sun:'Sun',mon:'Mon',tue:'Tue',wed:'Wed',thu:'Thu',fri:'Fri',sat:'Sat',
    work:'Work',day_off:'Day Off',holiday:'Holiday',sick:'Sick Leave',absent:'Absent',
    no_employees:'No employees. Add the first one!',
    confirm_delete:'Are you sure you want to delete this employee?',
    select_month_prompt:'Which month to edit?',number:'#',status:'Status',
    hint_fio:'Start typing name',hint_position:'Position auto-fills',
    hint_rate:'Rate-based: daily rate',hint_day_cell:'Click to select',
    hint_export:'Download Excel report',hint_sunday:'Sundays auto day-off',
    hint_pay_type:'Rate-based: pay = rate x 6 x working days',
    language:'Language',settings:'Settings',custom_value:'Custom value',
    enter_value:'Enter value',total:'Total',summary:'Summary',
    worked_days_total:'Days worked',worked_hours_total:'Hours worked',brief_suffix:'brief',
    january:'January',february:'February',march:'March',april:'April',
    may:'May',june:'June',july:'July',august:'August',
    september:'September',october:'October',november:'November',december:'December',
    official_marks:'Official Marks',for_all_employees:'For All Employees',
    select_position:'Select Position',employment_conditions:'Conditions',
    click_to_change_all:'Click to change all',click_to_change_employment:'Click to change conditions',
    click_to_select_position:'Click to select position',
    actual_hours_hint:'Actual hours',rate_hint:'Rate or fixed amount',
    rate_manual_hint:'Rate set manually. Double-click to reset.',
    rate_reset_confirm:'Reset manual rate and recalculate automatically?',
    statistics:'Statistics',export_history:'Export History',
    not_selected:'Not selected',staff_internal:'Staff',
    part_time_internal:'Part-time int.',part_time_external:'Part-time ext.',
    es_title:'Excel Header & Legend Settings',es_save_all:'Save All',
    es_header_panel:'Header (Excel header rows)',es_left:'LEFT — Approved',
    es_center:'CENTER — University',es_right:'RIGHT — Confirmed',
    es_row1:'Row 1',es_row2:'Row 2',es_row3:'Row 3',
    es_left_col:'Left',es_center_col:'Center',es_right_col:'Right',
    es_department:'Department',es_signatures:'Signature rows',
    es_sig1:'Signature 1',es_sig2:'Signature 2',es_sig3:'Signature 3',
    es_marks_panel:'Legend (Excel sheet 2)',
    es_symbol:'Symbol',es_description:'Description',es_status:'Status',
    es_add_mark:'Add mark',
  },
};

function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

function renderBody(tmpl,T,lang,yr,mo){
  let h=tmpl;
  h=h.replace(/\$\{T\['([^']+)'\](?: \|\| '')?\}/g,(_,k)=>esc(T[k]||''));
  h=h.replace(/\$\{currentYear\}/g,String(yr));
  h=h.replace(/__LANG_RU__/g,lang==='ru'?'active':'');
  h=h.replace(/__LANG_KG__/g,lang==='kg'?'active':'');
  h=h.replace(/__LANG_EN__/g,lang==='en'?'active':'');
  const opts=MONTH_KEYS.map((mk,i)=>{
    const idx=i+1;
    return '<option value="'+idx+'"'+(idx===mo?' selected':'')+'>'+esc(T[mk]||mk)+'</option>';
  }).join('');
  h=h.replace(/__MONTH_OPTIONS__/g,opts);
  return h;
}

function loginPage(){return `<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Табель учёта</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',-apple-system,sans-serif;background:#fafbfc;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px}.w{width:100%;max-width:400px}.hdr{text-align:center;margin-bottom:28px}.ico{width:52px;height:52px;background:#0969da;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:14px;box-shadow:0 4px 12px rgba(9,105,218,.25)}h1{font-size:20px;font-weight:700;margin-bottom:4px;color:#24292f}p{font-size:13px;color:#57606a}.card{background:#fff;border:1px solid #e1e4e8;border-radius:6px;padding:24px;box-shadow:0 3px 6px rgba(0,0,0,.08)}.fg{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}label{font-size:12px;font-weight:600;color:#57606a;text-transform:uppercase;letter-spacing:.4px}input{padding:9px 12px;background:#fff;border:1px solid #e1e4e8;border-radius:6px;color:#24292f;font-family:inherit;font-size:14px;outline:none;width:100%}input:focus{border-color:#0969da;box-shadow:0 0 0 3px rgba(9,105,218,.1)}.btn{width:100%;padding:10px;background:#0969da;border:none;border-radius:6px;color:#fff;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;margin-top:6px}.btn:hover{background:#0550ae}.btn:disabled{opacity:.6;cursor:not-allowed}.err{display:none;background:#ffebe9;border:1px solid #ffadb5;border-radius:6px;padding:9px 12px;font-size:13px;color:#cf222e;margin-bottom:14px;gap:8px;align-items:center}.err.show{display:flex}.foot{text-align:center;margin-top:20px;font-size:12px;color:#8c959f}</style></head><body>
<div class="w"><div class="hdr"><div class="ico">📋</div><h1>Табель учёта рабочего времени</h1><p>Войдите в систему для продолжения</p></div>
<div class="card"><div class="err" id="err"><span>⚠️</span><span id="et"></span></div>
<div class="fg"><label>Логин</label><input type="text" id="u" placeholder="Введите логин" autocomplete="username" autofocus></div>
<div class="fg"><label>Пароль</label><input type="password" id="p" placeholder="••••••••" autocomplete="current-password"></div>
<button class="btn" onclick="go()" id="btn">Войти</button></div>
<div class="foot">Система учёта рабочего времени</div></div>
<script>
document.addEventListener('keydown',e=>{if(e.key==='Enter')go();});
async function go(){
  const u=document.getElementById('u').value.trim(),p=document.getElementById('p').value;
  const btn=document.getElementById('btn'),err=document.getElementById('err'),et=document.getElementById('et');
  if(!u||!p){et.textContent='Введите логин и пароль';err.classList.add('show');return;}
  btn.textContent='Входим...';btn.disabled=true;err.classList.remove('show');
  try{
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
    let d;try{d=await r.json();}catch(e){et.textContent=r.status===503?'🔧 Система на обслуживании.':'Ошибка ('+r.status+')';err.classList.add('show');btn.textContent='Войти';btn.disabled=false;return;}
    if(d.ok){window.location.reload();}else{et.textContent=d.error||'Неверный логин или пароль';err.classList.add('show');btn.textContent='Войти';btn.disabled=false;}
  }catch(e){et.textContent='Ошибка соединения.';err.classList.add('show');btn.textContent='Войти';btn.disabled=false;}
}
</script></body></html>`;}

function maintenancePage(msg){return '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Техработы</title></head><body style="font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#fafbfc"><div style="text-align:center;max-width:500px;padding:40px"><div style="font-size:64px;margin-bottom:16px">🔧</div><h1 style="font-size:22px;font-weight:700;margin-bottom:8px">Технические работы</h1><p style="font-size:14px;color:#57606a;line-height:1.6">'+esc(msg)+'</p><button onclick="(async()=>{try{await fetch(\'/api/logout\');}catch(e){}window.location.reload();})()" style="margin-top:24px;padding:9px 20px;background:#f6f8fa;border:1px solid #d0d7de;border-radius:6px;font-size:13px;cursor:pointer">← Выйти</button></div></body></html>';}

let _css=null,_body=null,_js=null;
function load(){
  const pub=path.join(__dirname,'../public');
  if(!_css) _css=fs.readFileSync(path.join(pub,'app.css'),'utf8');
  if(!_body) _body=fs.readFileSync(path.join(pub,'app_body.html'),'utf8');
  if(!_js) _js=fs.readFileSync(path.join(pub,'app.js'),'utf8');
}

async function renderPage(req){
  const lang=req.session.lang||'ru';
  if(!req.session.userId) return loginPage();
  const db=require('./db');
  const mrow=await db.queryOne("SELECT value FROM system_settings WHERE `key`='maintenance_mode'");
  if(mrow&&mrow.value==='1'&&!req.session.isSuperadmin){
    const perms=req.session.perms||{};
    if(!perms.can_access_during_maintenance){
      const mr2=await db.queryOne("SELECT value FROM system_settings WHERE `key`='maintenance_message'");
      return maintenancePage(mr2?mr2.value:'Система на техническом обслуживании.');
    }
  }
  load();
  const T=ALL_T[lang]||ALL_T.ru;
  const now=new Date();
  const yr=now.getFullYear();
  const mo=now.getMonth()+1;
  const body=renderBody(_body,T,lang,yr,mo);
  const init=`<script>
const T=${JSON.stringify(T)};
const LANG=${JSON.stringify(lang)};
const MONTH_KEYS=${JSON.stringify(MONTH_KEYS)};
let currentYear=${yr};
let currentMonth=${mo};
var API_BASE='/api/';
var EXPORT_BASE='/export/';
let selectedYear=parseInt(localStorage.getItem('selectedYear'))||currentYear;
let selectedMonth=parseInt(localStorage.getItem('selectedMonth'))||currentMonth;
let currentPage='timesheet';
let employees=[];
let positions=[];
let timesheetData=null;
let editingEmpId=null;
let editingPosId=null;
<\/script>`;
  return `<!DOCTYPE html>\n<html lang="${esc(lang)}">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>${esc(T.app_title||'Табель учёта')}</title>\n<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">\n<style>\nhtml,body{margin:0;padding:0;background:#fafbfc;}\n${_css}\n</style>\n</head>\n<body class="tabel-ucheta-page">\n${init}\n${body}\n<script>\n${_js}\n<\/script>\n</body>\n</html>`;
}

module.exports={renderPage};
