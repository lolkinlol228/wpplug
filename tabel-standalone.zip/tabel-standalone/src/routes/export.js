const express = require('express');
const router = express.Router();
const ExcelJS = require('exceljs');
const db = require('../db');
const { requireAuth } = require('./auth');
const {
  getMonthCalendar, calcEmployeeMonth, getEmployeesForMonthBatch,
  getStatusToMarkFromDb, calcExperience
} = require('../helpers');

async function checkExportPerm(req, res) {
  if (req.session.isSuperadmin) return true;
  const perms = req.session.perms || {};
  if (!perms.can_export_excel) {
    res.status(403).send('No permission');
    return false;
  }
  return true;
}

async function getTimesheetData(dbName, year, month) {
  const dbRow = await db.queryOne('SELECT db_type FROM `databases` WHERE name = ?', [dbName]);
  const dbType = dbRow ? (dbRow.db_type || 'pps') : 'pps';

  const employees = await db.query(
    "SELECT * FROM employees WHERE db_name = ? ORDER BY CASE WHEN pay_type = 'fixed' THEN 1 ELSE 0 END, full_name",
    [dbName]
  );

  const daysInfo = getMonthCalendar(year, month);

  // Find fired employees
  const firedIds = new Set();
  if (employees.length) {
    const empIds = employees.map(e => parseInt(e.id));
    const ph = empIds.map(() => '?').join(',');
    const firedCandidates = await db.query(
      `SELECT employee_id, MAX(year*100+month) as fired_ym FROM monthly_settings
       WHERE db_name = ? AND is_fired = 1 AND employee_id IN (${ph})
       AND (year < ? OR (year = ? AND month <= ?))
       GROUP BY employee_id`,
      [dbName, ...empIds, year, year, month]
    );
    for (const fc of firedCandidates) {
      const eid = parseInt(fc.employee_id);
      const fy = Math.floor(fc.fired_ym / 100), fm = fc.fired_ym % 100;
      const restored = await db.queryOne(
        `SELECT COUNT(*) as cnt FROM monthly_settings
         WHERE db_name = ? AND employee_id = ? AND is_fired = 0
         AND (year > ? OR (year = ? AND month >= ?))`,
        [dbName, eid, fy, fy, fm]
      );
      if (!restored || restored.cnt == 0) firedIds.add(eid);
    }
  }

  const activeEmployees = employees.filter(e => !firedIds.has(parseInt(e.id)));
  const empDicts = await getEmployeesForMonthBatch(db, activeEmployees, year, month, dbName);

  let allEntries = {};
  if (activeEmployees.length) {
    const ids = activeEmployees.map(e => parseInt(e.id));
    const ph = ids.map(() => '?').join(',');
    const entryRows = await db.query(
      `SELECT * FROM timesheet_entries WHERE db_name = ? AND employee_id IN (${ph}) AND year = ? AND month = ?`,
      [dbName, ...ids, year, month]
    );
    for (const e of entryRows) {
      const eid = parseInt(e.employee_id);
      if (!allEntries[eid]) allEntries[eid] = {};
      allEntries[eid][parseInt(e.day)] = e;
    }
  }

  const result = [];
  for (const emp of activeEmployees) {
    const eid = parseInt(emp.id);
    const empDict = empDicts[eid] ? { ...empDicts[eid] } : { ...emp };
    empDict.rate_manual = parseInt(empDict.rate_manual) || 0;
    const entriesDict = allEntries[eid] || {};
    const calc = calcEmployeeMonth(empDict, entriesDict, daysInfo, dbType);
    calc.employee = empDict;
    result.push(calc);
  }

  const markMap = await getStatusToMarkFromDb(db, dbName);
  const esRow = await db.queryOne("SELECT setting_value FROM excel_settings WHERE db_name = ? AND setting_key = 'marks_list'", [dbName]);
  let marksList = [];
  try { marksList = esRow ? JSON.parse(esRow.setting_value) : []; } catch(e) {}

  return { employees: result, daysInfo, dbType, markMap, marksList };
}

async function getExcelSettings(dbName) {
  const rows = await db.query('SELECT setting_key, setting_value FROM excel_settings WHERE db_name = ?', [dbName]);
  const s = {};
  for (const r of rows) s[r.setting_key] = r.setting_value;
  return s;
}

const MONTH_NAMES_RU = [
  '', 'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
];
const DAY_NAMES_SHORT = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];

// ─── Full Export ───
async function buildFullExcel(dbName, year, month) {
  const { employees, daysInfo, dbType, markMap, marksList } = await getTimesheetData(dbName, year, month);
  const settings = await getExcelSettings(dbName);

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Табель', { pageSetup: { orientation: 'landscape', fitToPage: true } });

  // Header rows
  const monthName = MONTH_NAMES_RU[month] || month;
  const numDays = daysInfo.length;
  const totalCols = 4 + numDays + 3; // №, ФИО, Должность, Ставка, days..., Раб.дни, Часы, Итого

  // Header rows: org info
  const h1 = settings.header_left1 || '';
  const h2 = settings.header_center1 || '';
  const h3 = settings.header_right1 || '';

  ws.addRow([h1, '', '', '', ...Array(numDays + 2).fill(''), h3]);
  ws.addRow([settings.header_left2 || '', '', '', '', ...Array(numDays + 2).fill(''), settings.header_right2 || '']);
  ws.addRow([settings.header_left3 || '', '', '', '', ...Array(numDays + 2).fill(''), settings.header_right3 || '']);
  ws.addRow([]);
  ws.addRow([`${settings.header_center1 || ''}`]);
  ws.addRow([`${settings.header_center2 || ''}`]);
  ws.addRow([`${settings.header_center3 || ''}`]);
  ws.addRow([]);
  ws.addRow([`ТАБЕЛЬ учёта рабочего времени за ${monthName} ${year} г.`]);
  ws.addRow([]);

  // Column headers
  const dayHeaders = daysInfo.map(d => d.day);
  ws.addRow(['№', 'ФИО', 'Должность', 'Ставка', ...dayHeaders, 'Раб.дни', 'Часы/Итого', 'Итого']);
  ws.addRow(['', '', '', '', ...daysInfo.map(d => DAY_NAMES_SHORT[d.weekday] || ''), '', '', '']);

  // Style header
  const headerRowNum = ws.rowCount - 1;
  const dayHeaderRow = ws.getRow(headerRowNum);
  const dayNameRow = ws.getRow(ws.rowCount);
  dayHeaderRow.eachCell(cell => {
    cell.font = { bold: true, size: 8 };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1565C0' } };
    cell.font = { bold: true, size: 8, color: { argb: 'FFFFFFFF' } };
    cell.border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };
  });

  // Set column widths
  ws.getColumn(1).width = 4;
  ws.getColumn(2).width = 28;
  ws.getColumn(3).width = 20;
  ws.getColumn(4).width = 8;
  for (let i = 0; i < numDays; i++) ws.getColumn(5 + i).width = 4;
  ws.getColumn(5 + numDays).width = 7;
  ws.getColumn(6 + numDays).width = 8;
  ws.getColumn(7 + numDays).width = 10;

  // Data rows
  employees.forEach((emp, idx) => {
    const e = emp.employee;
    const dayValues = emp.day_cells.map(dc => {
      if (dc.status === 'work') return dc.display;
      return dc.display || '-';
    });

    const row = ws.addRow([
      idx + 1,
      e.full_name || '',
      e.position || '',
      e.rate || 0,
      ...dayValues,
      emp.working_days,
      emp.working_hours || emp.total_pay,
      emp.total_pay,
    ]);

    row.eachCell((cell, colNum) => {
      cell.font = { size: 7 };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: false };
      cell.border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };
    });

    // Left align FIO
    row.getCell(2).alignment = { horizontal: 'left', vertical: 'middle' };
    row.getCell(2).font = { size: 7 };

    // Color sundays
    daysInfo.forEach((di, i) => {
      if (di.is_sunday) {
        const cell = row.getCell(5 + i);
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFCE4E4' } };
      }
      const dc = emp.day_cells[i];
      if (dc && dc.status !== 'work' && dc.status !== 'day_off') {
        const cell = row.getCell(5 + i);
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFE0B2' } };
      }
    });

    // Highlight total
    const totalCell = row.getCell(7 + numDays);
    totalCell.font = { size: 8, bold: true };
    totalCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE3F2FD' } };
  });

  // Signatures
  ws.addRow([]);
  ws.addRow([settings.sig1 || '']);
  ws.addRow([settings.sig2 || '']);
  ws.addRow([settings.sig3 || '']);

  // Sheet 2: legend
  const ws2 = wb.addWorksheet('Условные обозначения');
  ws2.addRow(['Символ', 'Статус', 'Описание']);
  ws2.getRow(1).font = { bold: true };
  for (const m of marksList) {
    ws2.addRow([m.symbol, m.status, m.description]);
  }
  ws2.getColumn(1).width = 10;
  ws2.getColumn(2).width = 20;
  ws2.getColumn(3).width = 50;

  return wb;
}

// ─── Routes ───
router.get('/full/:year/:month', requireAuth, async (req, res) => {
  if (!(await checkExportPerm(req, res))) return;
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).send('No database selected');
  const year = parseInt(req.params.year), month = parseInt(req.params.month);

  try {
    const wb = await buildFullExcel(dbName, year, month);
    const monthName = MONTH_NAMES_RU[month] || month;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="tabel_${year}_${month}.xlsx"`);
    await wb.xlsx.write(res);
    res.end();

    // Log export
    await db.insert('export_log', {
      user_id: req.session.userId,
      username: req.session.username || '',
      db_name: dbName,
      export_type: 'full',
      year, month,
    });
  } catch (e) {
    console.error('Export error:', e);
    res.status(500).send('Export failed: ' + e.message);
  }
});

router.get('/brief/:year/:month', requireAuth, async (req, res) => {
  if (!(await checkExportPerm(req, res))) return;
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).send('No database selected');
  const year = parseInt(req.params.year), month = parseInt(req.params.month);

  try {
    const { employees } = await getTimesheetData(dbName, year, month);
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('Сводка');
    ws.addRow(['№', 'ФИО', 'Должность', 'Рабочие дни', 'Итого к выплате']);
    ws.getRow(1).font = { bold: true };
    ws.getRow(1).eachCell(cell => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1565C0' } };
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.alignment = { horizontal: 'center' };
    });

    employees.forEach((emp, i) => {
      const e = emp.employee;
      const row = ws.addRow([i + 1, e.full_name, e.position || '', emp.working_days, emp.total_pay]);
      row.getCell(2).alignment = { horizontal: 'left' };
    });

    ws.getColumn(1).width = 4;
    ws.getColumn(2).width = 30;
    ws.getColumn(3).width = 22;
    ws.getColumn(4).width = 14;
    ws.getColumn(5).width = 16;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="tabel_brief_${year}_${month}.xlsx"`);
    await wb.xlsx.write(res);
    res.end();

    await db.insert('export_log', {
      user_id: req.session.userId, username: req.session.username || '',
      db_name: dbName, export_type: 'brief', year, month,
    });
  } catch (e) {
    res.status(500).send('Export failed: ' + e.message);
  }
});

router.get('/employee/:empId/:year/:month', requireAuth, async (req, res) => {
  if (!(await checkExportPerm(req, res))) return;
  const dbName = req.session.activeDb;
  const empId = parseInt(req.params.empId);
  const year = parseInt(req.params.year), month = parseInt(req.params.month);

  try {
    const { employees, daysInfo, dbType } = await getTimesheetData(dbName, year, month);
    const empData = employees.find(e => parseInt(e.employee.id) === empId);
    if (!empData) return res.status(404).send('Employee not found');

    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('Табель');
    const e = empData.employee;
    const monthName = MONTH_NAMES_RU[month] || month;

    ws.addRow([`Табель учёта — ${e.full_name} — ${monthName} ${year}`]);
    ws.getRow(1).font = { bold: true, size: 12 };
    ws.addRow([`Должность: ${e.position || '—'}`]);
    ws.addRow([`Ставка: ${e.rate || 0}`]);
    ws.addRow([]);

    ws.addRow(['День', 'День недели', 'Статус', 'Значение']);
    ws.getRow(5).font = { bold: true };

    for (const dc of empData.day_cells) {
      ws.addRow([dc.day, DAY_NAMES_SHORT[dc.weekday] || '', dc.status, dc.display]);
    }

    ws.addRow([]);
    ws.addRow(['Итого рабочих дней:', empData.working_days]);
    ws.addRow(['Итого к выплате:', empData.total_pay]);

    ws.getColumn(1).width = 6;
    ws.getColumn(2).width = 12;
    ws.getColumn(3).width = 18;
    ws.getColumn(4).width = 14;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="tabel_emp_${empId}_${year}_${month}.xlsx"`);
    await wb.xlsx.write(res);
    res.end();

    await db.insert('export_log', {
      user_id: req.session.userId, username: req.session.username || '',
      db_name: dbName, export_type: 'employee', year, month,
      employee_name: e.full_name,
    });
  } catch (e) {
    res.status(500).send('Export failed: ' + e.message);
  }
});

module.exports = router;
