const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { getClientIp } = require('../helpers');

const router = express.Router();

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'unauthorized' });
  next();
}

function requireSuperadmin(req, res, next) {
  if (!req.session.isSuperadmin) return res.status(403).json({ error: 'forbidden' });
  next();
}

async function checkPerm(req, res, key) {
  if (req.session.isSuperadmin) return true;
  const perms = req.session.perms || {};
  if (!perms[key]) {
    res.status(403).json({ error: 'forbidden', perm: key });
    return false;
  }
  return true;
}

async function getUserPerms(userId) {
  const row = await db.queryOne('SELECT * FROM user_permissions WHERE user_id = ?', [userId]);
  return row || {};
}

async function checkRateLimit(username, ip) {
  const countIp = await db.queryOne(
    "SELECT COUNT(*) as cnt FROM login_log WHERE ip_address = ? AND success = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
    [ip]
  );
  if (countIp && countIp.cnt >= 10) return false;

  const countUser = await db.queryOne(
    "SELECT COUNT(*) as cnt FROM login_log WHERE username = ? AND success = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
    [username]
  );
  if (countUser && countUser.cnt >= 5) return false;

  return true;
}

function maskPassword(pw) {
  const len = pw.length;
  if (len <= 2) return '*'.repeat(len);
  return pw.substring(0, 2) + '*'.repeat(Math.min(len - 2, 8));
}

async function logLogin(username, userId, success, password = '') {
  try {
    await db.insert('login_log', {
      username: username.substring(0, 100),
      user_id: userId || null,
      ip_address: '',
      attempted_pass: (!success && password) ? maskPassword(password) : '',
      success: success ? 1 : 0,
    });
  } catch (e) {}
}

// POST /api/login
router.post('/login', async (req, res) => {
  const { username = '', password = '' } = req.body;
  const ip = getClientIp(req);

  if (!username || !password)
    return res.status(400).json({ ok: false, error: 'Введите логин и пароль' });

  const allowed = await checkRateLimit(username, ip);
  if (!allowed) {
    await logLogin(username, null, false, password);
    return res.status(429).json({ ok: false, error: 'Слишком много попыток. Подождите 15 минут.' });
  }

  const user = await db.queryOne(
    "SELECT * FROM users WHERE username = ? AND is_active = 1", [username]
  );

  let passwordOk = false;
  if (user) {
    // Support legacy sha256 or bcrypt
    if (/^[a-f0-9]{64}$/.test(user.password_hash)) {
      const crypto = require('crypto');
      passwordOk = crypto.createHash('sha256').update(password).digest('hex') === user.password_hash;
      if (passwordOk) {
        // Rehash to bcrypt
        const newHash = await bcrypt.hash(password, 10);
        await db.update('users', { password_hash: newHash }, { id: user.id });
      }
    } else {
      passwordOk = await bcrypt.compare(password, user.password_hash);
    }
  }

  if (user && passwordOk) {
    // Check maintenance
    const maintenance = await db.queryOne("SELECT value FROM system_settings WHERE `key` = 'maintenance_mode'");
    if (maintenance && maintenance.value === '1' && !user.is_superadmin) {
      const perms = await getUserPerms(user.id);
      if (!perms.can_access_during_maintenance) {
        const msg = await db.queryOne("SELECT value FROM system_settings WHERE `key` = 'maintenance_message'");
        await logLogin(username, user.id, true);
        return res.status(503).json({
          ok: false,
          error: '🔧 ' + (msg ? msg.value : 'Система на техническом обслуживании.'),
          maintenance: true
        });
      }
    }

    const perms = await getUserPerms(user.id);
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.isSuperadmin = !!user.is_superadmin;
    req.session.perms = perms;
    req.session.lang = req.session.lang || 'ru';

    await logLogin(username, user.id, true);
    return res.json({ ok: true, is_superadmin: !!user.is_superadmin });
  } else {
    await logLogin(username, user ? user.id : null, false, password);
    return res.status(401).json({ ok: false, error: 'Неверный логин или пароль' });
  }
});

// GET /api/logout
router.all('/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

// POST /api/set_lang/:lang
router.post('/set_lang/:lang', (req, res) => {
  const { lang } = req.params;
  if (['ru', 'kg', 'en'].includes(lang)) req.session.lang = lang;
  res.json({ ok: true });
});

module.exports = { router, requireAuth, requireSuperadmin, checkPerm, getUserPerms };
