const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcryptjs');
const { requireAuth, requireSuperadmin, checkPerm, getUserPerms } = require('./auth');
const {
  getMonthCalendar, getDayNames, calcEmployeeMonth,
  getEmployeesForMonthBatch, getStatusToMarkFromDb, calcExperience
} = require('../helpers');

// ─── /api/me ───
router.get('/me', requireAuth, async (req, res) => {
  const user = await db.queryOne('SELECT * FROM users WHERE id = ? AND is_active = 1', [req.session.userId]);
  if (!user) return res.status(401).json({ logged_in: false });

  const perms = await getUserPerms(user.id);

  let dbs;
  if (user.is_superadmin) {
    dbs = await db.query('SELECT * FROM `databases` ORDER BY display_name');
  } else {
    dbs = await db.query(
      'SELECT d.* FROM `databases` d JOIN user_databases ud ON ud.db_name = d.name WHERE ud.user_id = ? ORDER BY d.display_name',
      [user.id]
    );
  }

  let activeDb = req.session.activeDb;
  if (!activeDb && dbs.length > 0) {
    activeDb = dbs[0].name;
    req.session.activeDb = activeDb;
  }

  res.json({
    logged_in: true,
    user_id: user.id,
    username: user.username,
    display_name: user.display_name || '',
    is_superadmin: !!user.is_superadmin,
    perms,
    active_db: activeDb,
    accessible_dbs: dbs,
  });
});

// ─── /api/profile ───
router.get('/profile', requireAuth, async (req, res) => {
  const user = await db.queryOne('SELECT * FROM users WHERE id = ?', [req.session.userId]);
  res.json({ username: user.username, display_name: user.display_name || '' });
});

router.post('/profile', requireAuth, async (req, res) => {
  const { display_name, password: newPassword } = req.body;
  const updates = {};
  if (display_name !== undefined) updates.display_name = String(display_name).substring(0, 255);
  if (newPassword) {
    if (newPassword.length < 4) return res.status(400).json({ ok: false, error: 'Пароль должен быть не менее 4 символов' });
    updates.password_hash = await bcrypt.hash(newPassword, 10);
  }
  if (Object.keys(updates).length > 0)
    await db.update('users', updates, { id: req.session.userId });
  res.json({ ok: true, display_name: updates.display_name || display_name });
});

// ─── /api/switch_db ───
router.post('/switch_db', requireAuth, async (req, res) => {
  const { db_name } = req.body;
  const row = await db.queryOne('SELECT * FROM `databases` WHERE name = ?', [db_name]);
  if (!row) return res.status(404).json({ ok: false, error: 'БД не найдена' });

  if (!req.session.isSuperadmin) {
    const access = await db.queryOne('SELECT id FROM user_databases WHERE user_id = ? AND db_name = ?', [req.session.userId, db_name]);
    if (!access) return res.status(403).json({ ok: false, error: 'Нет доступа' });
  }

  req.session.activeDb = db_name;
  res.json({ ok: true, db_name, display_name: row.display_name, db_type: row.db_type || 'pps' });
});

// ─── EMPLOYEES ───
router.get('/employees', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).json({ error: 'no_db' });
  const lang = req.session.lang || 'ru';

  const emps = await db.query(
    "SELECT * FROM employees WHERE db_name = ? ORDER BY CASE WHEN pay_type = 'fixed' THEN 1 ELSE 0 END, full_name",
    [dbName]
  );

  const posIds = [...new Set(emps.filter(e => e.position_id).map(e => e.position_id))];
  let posMap = {};
  if (posIds.length) {
    const pos = await db.query(`SELECT * FROM positions WHERE id IN (${posIds.map(() => '?').join(',')})`, posIds);
    for (const p of pos) posMap[p.id] = p;
  }

  const result = emps.map(e => {
    const out = { ...e, id: parseInt(e.id), position_id: e.position_id ? parseInt(e.position_id) : null };
    if (e.position_id && posMap[e.position_id]) {
      const p = posMap[e.position_id];
      const nameField = lang === 'en' ? 'name_en' : `name_${lang}`;
      out.position_name = p[nameField] || p.name_ru;
      out.planned_hours = parseInt(p.planned_hours);
      if (e.actual_hours && p.planned_hours && (!e.rate || e.rate == 0)) {
        out.rate = Math.round(e.actual_hours / p.planned_hours * 100) / 100;
      }
    } else {
      out.position_name = e.position;
      out.planned_hours = 0;
    }
    return out;
  });

  res.json(result);
});

router.post('/employees', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_employees'))) return;
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).json({ error: 'no_db' });
  const d = req.body;
  const id = await db.insert('employees', {
    db_name: dbName,
    full_name: d.full_name,
    position: d.position || '',
    pay_type: d.pay_type || 'rate',
    rate: parseFloat(d.rate) || 0,
    employment_internal: d.employment_internal || null,
    employment_external: d.employment_external || null,
    pedagog_experience: d.pedagog_experience || null,
    actual_hours: d.actual_hours ? parseFloat(d.actual_hours) : null,
    position_id: d.position_id || null,
    note: d.note || null,
  });
  res.json({ ok: true, id });
});

router.put('/employees/:id', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_employees'))) return;
  const dbName = req.session.activeDb;
  const d = req.body;
  await db.update('employees', {
    full_name: d.full_name,
    position: d.position || '',
    pay_type: d.pay_type || 'rate',
    rate: parseFloat(d.rate) || 0,
    employment_internal: d.employment_internal || null,
    employment_external: d.employment_external || null,
    pedagog_experience: d.pedagog_experience || null,
    actual_hours: d.actual_hours ? parseFloat(d.actual_hours) : null,
    position_id: d.position_id || null,
    note: d.note || null,
  }, { id: parseInt(req.params.id), db_name: dbName });
  res.json({ ok: true });
});

router.delete('/employees/:id', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_employees'))) return;
  const dbName = req.session.activeDb;
  const eid = parseInt(req.params.id);
  await db.remove('timesheet_entries', { employee_id: eid, db_name: dbName });
  await db.remove('monthly_settings', { employee_id: eid, db_name: dbName });
  await db.remove('employees', { id: eid, db_name: dbName });
  res.json({ ok: true });
});

router.post('/employees/:id/name', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_edit_fio'))) return;
  const dbName = req.session.activeDb;
  const eid = parseInt(req.params.id);
  const { full_name, year, month } = req.body;
  if (!full_name) return res.status(400).json({ ok: false, error: 'Name empty' });
  await db.update('employees', { full_name }, { id: eid, db_name: dbName });
  if (year && month) {
    const exists = await db.queryOne(
      'SELECT id FROM monthly_settings WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ?',
      [dbName, eid, year, month]
    );
    if (exists) {
      await db.update('monthly_settings', { full_name }, { id: exists.id });
    } else {
      await db.insert('monthly_settings', { db_name: dbName, employee_id: eid, year, month, full_name });
    }
  }
  res.json({ ok: true });
});

router.get('/employees/search', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.json([]);
  const q = `%${req.query.q || ''}%`;
  const rows = await db.query(
    'SELECT DISTINCT full_name, position FROM employees WHERE db_name = ? AND full_name LIKE ? LIMIT 10',
    [dbName, q]
  );
  res.json(rows);
});

router.get('/employees/fired', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.json([]);
  const rows = await db.query(
    `SELECT DISTINCT e.* FROM employees e
     JOIN monthly_settings ms ON ms.employee_id = e.id AND ms.db_name = e.db_name
     WHERE e.db_name = ? AND ms.is_fired = 1`,
    [dbName]
  );
  res.json(rows);
});

// ─── POSITIONS ───
router.get('/positions', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).json({ error: 'no_db' });
  const lang = req.session.lang || 'ru';
  const rows = await db.query('SELECT * FROM positions WHERE db_name = ? ORDER BY id', [dbName]);
  const nameField = lang === 'en' ? 'name_en' : `name_${lang}`;
  res.json(rows.map(p => ({
    id: parseInt(p.id), name: p[nameField] || p.name_ru,
    name_ru: p.name_ru, name_kg: p.name_kg, name_en: p.name_en,
    planned_hours: parseInt(p.planned_hours),
  })));
});

router.post('/positions', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_positions'))) return;
  const dbName = req.session.activeDb;
  const d = req.body;
  const id = await db.insert('positions', {
    db_name: dbName, name_ru: d.name_ru, name_kg: d.name_kg,
    name_en: d.name_en, planned_hours: parseInt(d.planned_hours) || 0,
  });
  res.json({ ok: true, id });
});

router.put('/positions/:id', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_positions'))) return;
  const d = req.body;
  await db.update('positions', {
    name_ru: d.name_ru, name_kg: d.name_kg, name_en: d.name_en,
    planned_hours: parseInt(d.planned_hours) || 0,
  }, { id: parseInt(req.params.id) });
  res.json({ ok: true });
});

router.delete('/positions/:id', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_positions'))) return;
  await db.remove('positions', { id: parseInt(req.params.id) });
  res.json({ ok: true });
});

// ─── TIMESHEET ───
router.get('/timesheet/:year/:month', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).json({ error: 'no_db' });
  const year = parseInt(req.params.year);
  const month = parseInt(req.params.month);
  const lang = req.session.lang || 'ru';

  // Get db_type
  const dbRow = await db.queryOne('SELECT db_type FROM `databases` WHERE name = ?', [dbName]);
  const dbType = dbRow ? (dbRow.db_type || 'pps') : 'pps';

  const employees = await db.query(
    "SELECT * FROM employees WHERE db_name = ? ORDER BY CASE WHEN pay_type = 'fixed' THEN 1 ELSE 0 END, full_name",
    [dbName]
  );

  const daysInfo = getMonthCalendar(year, month);

  // Find fired employees
  const firedIds = new Set();
  if (employees.length) {
    const empIds = employees.map(e => parseInt(e.id));
    const ph = empIds.map(() => '?').join(',');
    const firedCandidates = await db.query(
      `SELECT employee_id, MAX(year*100+month) as fired_ym FROM monthly_settings
       WHERE db_name = ? AND is_fired = 1 AND employee_id IN (${ph})
       AND (year < ? OR (year = ? AND month <= ?))
       GROUP BY employee_id`,
      [dbName, ...empIds, year, year, month]
    );
    for (const fc of firedCandidates) {
      const eid = parseInt(fc.employee_id);
      const fy = Math.floor(fc.fired_ym / 100);
      const fm = fc.fired_ym % 100;
      const restored = await db.queryOne(
        `SELECT COUNT(*) as cnt FROM monthly_settings
         WHERE db_name = ? AND employee_id = ? AND is_fired = 0
         AND (year > ? OR (year = ? AND month >= ?))`,
        [dbName, eid, fy, fy, fm]
      );
      if (!restored || restored.cnt == 0) firedIds.add(eid);
    }
  }

  const activeEmployees = employees.filter(e => !firedIds.has(parseInt(e.id)));
  const empDicts = await getEmployeesForMonthBatch(db, activeEmployees, year, month, dbName);

  // Batch load entries
  let allEntries = {};
  if (activeEmployees.length) {
    const ids = activeEmployees.map(e => parseInt(e.id));
    const ph = ids.map(() => '?').join(',');
    const entryRows = await db.query(
      `SELECT * FROM timesheet_entries WHERE db_name = ? AND employee_id IN (${ph}) AND year = ? AND month = ?`,
      [dbName, ...ids, year, month]
    );
    for (const e of entryRows) {
      const eid = parseInt(e.employee_id);
      if (!allEntries[eid]) allEntries[eid] = {};
      allEntries[eid][parseInt(e.day)] = e;
    }
  }

  // Check custom settings
  let hasCustomMap = {};
  if (activeEmployees.length) {
    const ids = activeEmployees.map(e => parseInt(e.id));
    const ph = ids.map(() => '?').join(',');
    const customRows = await db.query(
      `SELECT employee_id FROM monthly_settings WHERE db_name = ? AND employee_id IN (${ph}) AND year = ? AND month = ?`,
      [dbName, ...ids, year, month]
    );
    for (const r of customRows) hasCustomMap[parseInt(r.employee_id)] = true;
  }

  const result = [];
  for (const emp of activeEmployees) {
    const eid = parseInt(emp.id);
    const empDict = empDicts[eid] ? { ...empDicts[eid] } : { ...emp };

    for (const f of ['pedagog_experience', 'actual_hours', 'position_id']) {
      if (empDict[f] === null || empDict[f] === undefined) empDict[f] = emp[f] || null;
    }

    // Auto-calc experience for pps type
    if (dbType === 'pps') {
      try {
        const periods = await db.query('SELECT * FROM experience WHERE employee_id = ? ORDER BY date_from', [eid]);
        if (periods.length) {
          const expData = calcExperience(periods, `${year}-${String(month).padStart(2,'0')}-01`);
          if (expData.total_days > 0) {
            empDict.pedagog_experience = expData.display;
            empDict.experience_auto = true;
          }
        }
      } catch (e) {}
    }

    empDict.is_fired = false;
    empDict.has_custom_settings = !!hasCustomMap[eid];
    empDict.rate_manual = parseInt(empDict.rate_manual) || 0;

    const entriesDict = allEntries[eid] || {};
    const calc = calcEmployeeMonth(empDict, entriesDict, daysInfo, dbType);
    calc.employee = empDict;
    result.push(calc);
  }

  const marksJson = await db.queryOne(
    "SELECT setting_value FROM excel_settings WHERE db_name = ? AND setting_key = 'marks_list'",
    [dbName]
  );
  let customMarks = [];
  try { customMarks = marksJson ? JSON.parse(marksJson.setting_value) : []; } catch(e) {}

  const markMap = await getStatusToMarkFromDb(db, dbName);

  res.json({
    employees: result, days: daysInfo,
    day_names: getDayNames(lang), month, year,
    db_type: dbType, custom_marks: customMarks, status_to_mark: markMap,
  });
});

router.post('/timesheet/entry', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_edit_days'))) return;
  const dbName = req.session.activeDb;
  const d = req.body;
  const exists = await db.queryOne(
    'SELECT id FROM timesheet_entries WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ? AND day = ?',
    [dbName, d.employee_id, d.year, d.month, d.day]
  );
  if (exists) {
    await db.update('timesheet_entries', { status: d.status, custom_value: d.custom_value || null }, { id: exists.id });
  } else {
    await db.insert('timesheet_entries', {
      db_name: dbName, employee_id: d.employee_id,
      year: d.year, month: d.month, day: d.day,
      status: d.status, custom_value: d.custom_value || null,
    });
  }
  res.json({ ok: true });
});

router.post('/timesheet/batch', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_edit_days'))) return;
  const dbName = req.session.activeDb;
  const { cells = [], status, custom_value, year, month } = req.body;
  for (const cell of cells) {
    const eid = parseInt(cell.emp), day = parseInt(cell.day);
    const exists = await db.queryOne(
      'SELECT id FROM timesheet_entries WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ? AND day = ?',
      [dbName, eid, year, month, day]
    );
    if (exists) {
      await db.update('timesheet_entries', { status, custom_value: custom_value || null }, { id: exists.id });
    } else {
      await db.insert('timesheet_entries', {
        db_name: dbName, employee_id: eid, year, month, day, status, custom_value: custom_value || null,
      });
    }
  }
  res.json({ ok: true });
});

router.post('/timesheet/bulk', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_edit_days'))) return;
  const dbName = req.session.activeDb;
  const { employee_id, year, month, status, custom_value } = req.body;
  const daysInfo = getMonthCalendar(parseInt(year), parseInt(month));
  for (const di of daysInfo) {
    if (!di.is_sunday) {
      const exists = await db.queryOne(
        'SELECT id FROM timesheet_entries WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ? AND day = ?',
        [dbName, employee_id, year, month, di.day]
      );
      if (exists) {
        await db.update('timesheet_entries', { status, custom_value: custom_value || null }, { id: exists.id });
      } else {
        await db.insert('timesheet_entries', {
          db_name: dbName, employee_id, year, month, day: di.day, status, custom_value: custom_value || null,
        });
      }
    }
  }
  res.json({ ok: true });
});

router.post('/timesheet/sunday_bulk', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_edit_days'))) return;
  const dbName = req.session.activeDb;
  const { employee_id, year, month, status } = req.body;
  const daysInfo = getMonthCalendar(parseInt(year), parseInt(month));
  for (const di of daysInfo) {
    if (di.is_sunday) {
      const exists = await db.queryOne(
        'SELECT id FROM timesheet_entries WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ? AND day = ?',
        [dbName, employee_id, year, month, di.day]
      );
      if (exists) {
        await db.update('timesheet_entries', { status }, { id: exists.id });
      } else {
        await db.insert('timesheet_entries', { db_name: dbName, employee_id, year, month, day: di.day, status });
      }
    }
  }
  res.json({ ok: true });
});

// ─── MONTHLY SETTINGS ───
router.post('/monthly_settings', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  const d = req.body;
  const existing = await db.queryOne(
    'SELECT id FROM monthly_settings WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ?',
    [dbName, d.employee_id, d.year, d.month]
  );
  const data = {
    db_name: dbName, employee_id: d.employee_id, year: d.year, month: d.month,
    position: d.position !== undefined ? d.position : null,
    rate: d.rate !== undefined ? parseFloat(d.rate) : null,
    rate_manual: d.rate_manual ? 1 : 0,
    is_fired: d.is_fired ? 1 : 0,
    employment_internal: d.employment_internal !== undefined ? d.employment_internal : null,
    employment_external: d.employment_external !== undefined ? d.employment_external : null,
    actual_hours: d.actual_hours !== undefined ? parseFloat(d.actual_hours) || null : null,
    pedagog_experience: d.pedagog_experience !== undefined ? d.pedagog_experience : null,
    position_id: d.position_id !== undefined ? d.position_id : null,
    full_name: d.full_name !== undefined ? d.full_name : null,
  };
  if (existing) {
    await db.update('monthly_settings', data, { id: existing.id });
  } else {
    await db.insert('monthly_settings', data);
  }
  res.json({ ok: true });
});

// Employee field updates
router.post('/employee/fire', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_fire_employee'))) return;
  const dbName = req.session.activeDb;
  const { employee_id, year, month, is_fired } = req.body;
  const existing = await db.queryOne(
    'SELECT id FROM monthly_settings WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ?',
    [dbName, employee_id, year, month]
  );
  if (existing) {
    await db.update('monthly_settings', { is_fired: is_fired ? 1 : 0 }, { id: existing.id });
  } else {
    await db.insert('monthly_settings', { db_name: dbName, employee_id, year, month, is_fired: is_fired ? 1 : 0 });
  }
  res.json({ ok: true });
});

router.post('/employee/update_field', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  const { employee_id, year, month, field, value } = req.body;
  const allowedFields = ['position', 'rate', 'actual_hours', 'employment_internal', 'employment_external', 'pedagog_experience', 'position_id', 'rate_manual'];
  if (!allowedFields.includes(field)) return res.status(400).json({ ok: false, error: 'Invalid field' });

  const existing = await db.queryOne(
    'SELECT id FROM monthly_settings WHERE db_name = ? AND employee_id = ? AND year = ? AND month = ?',
    [dbName, employee_id, year, month]
  );
  const data = { [field]: value };
  if (existing) {
    await db.update('monthly_settings', data, { id: existing.id });
  } else {
    await db.insert('monthly_settings', { db_name: dbName, employee_id, year, month, ...data });
  }
  res.json({ ok: true });
});

// ─── EXCEL SETTINGS ───
router.get('/excel_settings', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).json({ error: 'no_db' });
  const rows = await db.query('SELECT setting_key, setting_value FROM excel_settings WHERE db_name = ?', [dbName]);
  const result = {};
  for (const r of rows) result[r.setting_key] = r.setting_value;
  res.json(result);
});

router.post('/excel_settings', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_edit_excel'))) return;
  const dbName = req.session.activeDb;
  const settings = req.body;
  for (const [key, value] of Object.entries(settings)) {
    await db.upsert('excel_settings',
      { db_name: dbName, setting_key: key, setting_value: String(value) },
      ['db_name', 'setting_key']
    );
  }
  res.json({ ok: true });
});

// ─── USERS ───
router.get('/users', requireAuth, requireSuperadmin, async (req, res) => {
  const users = await db.query('SELECT u.*, p.* FROM users u LEFT JOIN user_permissions p ON p.user_id = u.id ORDER BY u.id');
  res.json(users.map(u => ({ ...u, password_hash: undefined })));
});

router.post('/users', requireAuth, requireSuperadmin, async (req, res) => {
  const d = req.body;
  const hash = await bcrypt.hash(d.password || 'changeme', 10);
  const uid = await db.insert('users', {
    username: d.username,
    password_hash: hash,
    display_name: d.display_name || '',
    is_superadmin: d.is_superadmin ? 1 : 0,
    is_active: 1,
  });
  await db.insert('user_permissions', {
    user_id: uid,
    can_manage_employees: d.can_manage_employees ? 1 : 1,
    can_manage_positions: d.can_manage_positions ? 1 : 1,
    can_edit_excel: d.can_edit_excel !== undefined ? (d.can_edit_excel ? 1 : 0) : 1,
    can_edit_fio: d.can_edit_fio !== undefined ? (d.can_edit_fio ? 1 : 0) : 1,
    can_edit_position_col: d.can_edit_position_col !== undefined ? (d.can_edit_position_col ? 1 : 0) : 1,
    can_edit_conditions: d.can_edit_conditions !== undefined ? (d.can_edit_conditions ? 1 : 0) : 1,
    can_edit_experience: d.can_edit_experience !== undefined ? (d.can_edit_experience ? 1 : 0) : 1,
    can_edit_hours: d.can_edit_hours !== undefined ? (d.can_edit_hours ? 1 : 0) : 1,
    can_edit_rate: d.can_edit_rate !== undefined ? (d.can_edit_rate ? 1 : 0) : 1,
    can_edit_days: d.can_edit_days !== undefined ? (d.can_edit_days ? 1 : 0) : 1,
    can_manage_databases: d.can_manage_databases ? 1 : 0,
    can_view_stats: d.can_view_stats !== undefined ? (d.can_view_stats ? 1 : 0) : 1,
    can_view_history: d.can_view_history ? 1 : 0,
    can_export_excel: d.can_export_excel !== undefined ? (d.can_export_excel ? 1 : 0) : 1,
    can_fire_employee: d.can_fire_employee ? 1 : 0,
    can_manage_experience: d.can_manage_experience !== undefined ? (d.can_manage_experience ? 1 : 0) : 1,
    can_access_during_maintenance: d.can_access_during_maintenance ? 1 : 0,
    can_toggle_maintenance: d.can_toggle_maintenance ? 1 : 0,
    can_send_notifications: d.can_send_notifications ? 1 : 0,
    can_manage_workflow: d.can_manage_workflow ? 1 : 0,
  });
  res.json({ ok: true, id: uid });
});

router.put('/users/:id', requireAuth, requireSuperadmin, async (req, res) => {
  const uid = parseInt(req.params.id);
  const d = req.body;
  const updates = { display_name: d.display_name || '', is_superadmin: d.is_superadmin ? 1 : 0 };
  if (d.password) updates.password_hash = await bcrypt.hash(d.password, 10);
  if (d.username) updates.username = d.username;
  await db.update('users', updates, { id: uid });

  const permFields = [
    'can_manage_employees','can_manage_positions','can_edit_excel','can_edit_fio',
    'can_edit_position_col','can_edit_conditions','can_edit_experience','can_edit_hours',
    'can_edit_rate','can_edit_days','can_manage_databases','can_view_stats','can_view_history',
    'can_export_excel','can_fire_employee','can_manage_experience','can_access_during_maintenance',
    'can_toggle_maintenance','can_send_notifications','can_manage_workflow',
  ];
  const permData = {};
  for (const f of permFields) {
    if (d[f] !== undefined) permData[f] = d[f] ? 1 : 0;
  }
  if (Object.keys(permData).length) await db.update('user_permissions', permData, { user_id: uid });
  res.json({ ok: true });
});

router.delete('/users/:id', requireAuth, requireSuperadmin, async (req, res) => {
  const uid = parseInt(req.params.id);
  if (uid === req.session.userId) return res.status(400).json({ ok: false, error: 'Cannot delete yourself' });
  await db.update('users', { is_active: 0 }, { id: uid });
  res.json({ ok: true });
});

// ─── DATABASES ───
router.get('/databases', requireAuth, requireSuperadmin, async (req, res) => {
  res.json(await db.query('SELECT * FROM `databases` ORDER BY display_name'));
});

router.post('/databases', requireAuth, requireSuperadmin, async (req, res) => {
  const { name, display_name, db_type = 'pps' } = req.body;
  await db.insert('databases', { name, display_name, db_type });

  // Init default positions
  const cnt = await db.queryOne('SELECT COUNT(*) as cnt FROM positions WHERE db_name = ?', [name]);
  if (!cnt || cnt.cnt == 0) {
    const defaults = [
      ['Стажёр', 'Стажёр', 'Intern', 850],
      ['Преподаватель', 'Окутуучу', 'Teacher', 850],
      ['Старший преподаватель', 'Ага окутуучу', 'Senior Teacher', 850],
      ['Доцент', 'Доцент', 'Associate Professor', 800],
      ['Профессор', 'Профессор', 'Professor', 750],
    ];
    for (const d of defaults) {
      await db.insert('positions', { db_name: name, name_ru: d[0], name_kg: d[1], name_en: d[2], planned_hours: d[3] });
    }
  }

  // Init excel settings
  const cnt2 = await db.queryOne('SELECT COUNT(*) as cnt FROM excel_settings WHERE db_name = ?', [name]);
  if (!cnt2 || cnt2.cnt == 0) {
    const defaultSettings = [
      ['header_left1', 'Макулдашылды'],
      ['header_left2', 'ЖАЭУнун ОИ боюнча проректору,'],
      ['header_left3', '____________ м.и.к. Садырова Н.А.'],
      ['header_center1', 'Жалал-Абад эл аралык университети'],
      ['header_center2', 'Медицина факультети'],
      ['header_center3', 'Гуманитардык жана табигый дисциплиналар кафедрасы'],
      ['header_right1', 'БЕКИТЕМ'],
      ['header_right2', 'ЖАЭУнун ректору, ф-м.и.к.'],
      ['header_right3', '____________ Нарбаев М.Р.'],
      ['sig1', 'Кафедра башчысы: ______________________   ______________________ '],
      ['sig2', 'ОМБнун башчысы, ф-м.и.к. : ______________________ Канетова Д.Э.'],
      ['sig3', 'Укук иштери жана адам ресурстарынын бөлүмү: ____________________ Сыдыкова  Б.Ж.'],
      ['marks_list', JSON.stringify([
        {"symbol":"К","status":"vacation","description":"Каникулдар"},
        {"symbol":"О","status":"sick","description":"Оорулуу"},
        {"symbol":"С","status":"business_trip","description":"Иш сапарлар"},
        {"symbol":"КӨ","status":"maternity","description":"Кош бойлуулук жана төрөт өргүү"},
        {"symbol":"БӨ","status":"childcare","description":"Бала багуу боюнча өргүү"},
        {"symbol":"ОӨ","status":"study_leave","description":"Окуусуна байланыштуу өргүү"},
        {"symbol":"АӨ","status":"admin_leave","description":"Администрация тарабынан берилген дем алыш"},
        {"symbol":"Дк","status":"absence","description":"Дайынсыз ишке келбей калуу"},
        {"symbol":"Кк","status":"late","description":"Ишке кечигип келүү"},
        {"symbol":"Эк","status":"early_leave","description":"Иштен эрте кетип калуу"},
      ])],
    ];
    for (const [key, value] of defaultSettings) {
      await db.upsert('excel_settings', { db_name: name, setting_key: key, setting_value: value }, ['db_name', 'setting_key']);
    }
  }

  res.json({ ok: true });
});

router.delete('/databases/:name', requireAuth, requireSuperadmin, async (req, res) => {
  const name = req.params.name;
  await db.remove('databases', { name });
  res.json({ ok: true });
});

router.post('/databases/:name/assign', requireAuth, requireSuperadmin, async (req, res) => {
  const dbName = req.params.name;
  const { user_id, assign } = req.body;
  if (assign) {
    try { await db.insert('user_databases', { user_id, db_name: dbName }); } catch(e) {}
  } else {
    await db.remove('user_databases', { user_id, db_name: dbName });
  }
  res.json({ ok: true });
});

router.get('/databases/:name/users', requireAuth, requireSuperadmin, async (req, res) => {
  const rows = await db.query('SELECT user_id FROM user_databases WHERE db_name = ?', [req.params.name]);
  res.json(rows.map(r => r.user_id));
});

// ─── STATS ───
router.get('/stats/:year/:month', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.status(400).json({ error: 'no_db' });
  const year = parseInt(req.params.year), month = parseInt(req.params.month);

  const empCount = await db.queryOne('SELECT COUNT(*) as cnt FROM employees WHERE db_name = ?', [dbName]);
  const posCount = await db.queryOne('SELECT COUNT(*) as cnt FROM positions WHERE db_name = ?', [dbName]);
  const entryCount = await db.queryOne(
    'SELECT COUNT(*) as cnt FROM timesheet_entries WHERE db_name = ? AND year = ? AND month = ?',
    [dbName, year, month]
  );

  res.json({
    employees: empCount ? empCount.cnt : 0,
    positions: posCount ? posCount.cnt : 0,
    entries: entryCount ? entryCount.cnt : 0,
    year, month,
  });
});

// ─── NOTIFICATIONS ───
router.get('/notifications/unread_count', requireAuth, async (req, res) => {
  const row = await db.queryOne(
    'SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0',
    [req.session.userId]
  );
  res.json({ count: row ? parseInt(row.cnt) : 0 });
});

router.get('/notifications', requireAuth, async (req, res) => {
  const rows = await db.query(
    'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
    [req.session.userId]
  );
  res.json(rows);
});

router.post('/notifications/read', requireAuth, async (req, res) => {
  const { ids } = req.body;
  if (ids && ids.length) {
    const ph = ids.map(() => '?').join(',');
    await db.query(`UPDATE notifications SET is_read = 1 WHERE id IN (${ph}) AND user_id = ?`, [...ids, req.session.userId]);
  } else {
    await db.query('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.session.userId]);
  }
  res.json({ ok: true });
});

// ─── EXPERIENCE ───
router.get('/experience/:empId', requireAuth, async (req, res) => {
  const rows = await db.query('SELECT * FROM experience WHERE employee_id = ? ORDER BY date_from', [req.params.empId]);
  const data = calcExperience(rows);
  res.json({ ...data, periods: rows });
});

router.post('/experience/:empId', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_experience'))) return;
  const eid = parseInt(req.params.empId);
  const d = req.body;
  if (d.id) {
    await db.update('experience', {
      date_from: d.date_from, date_to: d.date_to || null,
      is_current: d.is_current ? 1 : 0, note: d.note || '',
    }, { id: d.id });
  } else {
    await db.insert('experience', {
      employee_id: eid, date_from: d.date_from,
      date_to: d.date_to || null, is_current: d.is_current ? 1 : 0, note: d.note || '',
    });
  }
  res.json({ ok: true });
});

router.delete('/experience/period/:id', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_experience'))) return;
  await db.remove('experience', { id: parseInt(req.params.id) });
  res.json({ ok: true });
});

router.get('/experience/all', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.json([]);
  const emps = await db.query('SELECT id FROM employees WHERE db_name = ?', [dbName]);
  const result = [];
  for (const emp of emps) {
    const periods = await db.query('SELECT * FROM experience WHERE employee_id = ? ORDER BY date_from', [emp.id]);
    const data = calcExperience(periods);
    result.push({ employee_id: emp.id, ...data });
  }
  res.json(result);
});

// ─── MAINTENANCE ───
router.get('/maintenance', requireAuth, async (req, res) => {
  const mode = await db.queryOne("SELECT value FROM system_settings WHERE `key` = 'maintenance_mode'");
  const msg = await db.queryOne("SELECT value FROM system_settings WHERE `key` = 'maintenance_message'");
  res.json({
    enabled: mode ? mode.value === '1' : false,
    message: msg ? msg.value : '',
  });
});

router.post('/maintenance', requireAuth, requireSuperadmin, async (req, res) => {
  const { enabled, message } = req.body;
  await db.upsert('system_settings', { key: 'maintenance_mode', value: enabled ? '1' : '0' }, ['key']);
  if (message !== undefined)
    await db.upsert('system_settings', { key: 'maintenance_message', value: message }, ['key']);
  res.json({ ok: true });
});

// ─── SYSTEM NOTIFICATION ───
router.post('/system_notification', requireAuth, requireSuperadmin, async (req, res) => {
  const { message, user_ids, db_name, year, month } = req.body;
  const targets = user_ids && user_ids.length ? user_ids :
    (await db.query('SELECT id FROM users WHERE is_active = 1')).map(u => u.id);
  for (const uid of targets) {
    await db.insert('notifications', {
      user_id: uid, db_name: db_name || '', year: year || 0, month: month || 0, message,
    });
  }
  res.json({ ok: true });
});

// ─── LOGIN LOGS ───
router.get('/login_logs', requireAuth, requireSuperadmin, async (req, res) => {
  const rows = await db.query('SELECT * FROM login_log ORDER BY created_at DESC LIMIT 200');
  res.json(rows);
});

// ─── EXPORT HISTORY ───
router.get('/export_history', requireAuth, async (req, res) => {
  const rows = await db.query(
    'SELECT id, user_id, username, db_name, export_type, year, month, employee_name, exported_at FROM export_log ORDER BY exported_at DESC LIMIT 100'
  );
  res.json(rows);
});

router.delete('/export_history/:id/delete', requireAuth, requireSuperadmin, async (req, res) => {
  await db.remove('export_log', { id: parseInt(req.params.id) });
  res.json({ ok: true });
});

router.post('/export_history_clear', requireAuth, requireSuperadmin, async (req, res) => {
  await db.query('DELETE FROM export_log');
  res.json({ ok: true });
});

// ─── WORKFLOW ───
router.get('/workflow/chains', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  if (!dbName) return res.json([]);
  res.json(await db.query('SELECT * FROM workflow_chains WHERE db_name = ? ORDER BY step_order', [dbName]));
});

router.post('/workflow/chains', requireAuth, async (req, res) => {
  if (!(await checkPerm(req, res, 'can_manage_workflow'))) return;
  const dbName = req.session.activeDb;
  const { chains } = req.body;
  await db.query('DELETE FROM workflow_chains WHERE db_name = ?', [dbName]);
  if (chains && chains.length) {
    for (const c of chains) {
      await db.insert('workflow_chains', {
        db_name: dbName, step_order: c.step_order,
        step_name: c.step_name || '', user_ids: JSON.stringify(c.user_ids || []),
        is_reviewer: c.is_reviewer ? 1 : 0,
      });
    }
  }
  res.json({ ok: true });
});

router.get('/workflow/status', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  const { year, month } = req.query;
  if (!dbName) return res.json(null);
  const row = await db.queryOne(
    'SELECT * FROM workflow_status WHERE db_name = ? AND year = ? AND month = ?',
    [dbName, year, month]
  );
  res.json(row || { status: 'draft', current_step: 0, activated: 0 });
});

router.get('/workflow/log', requireAuth, async (req, res) => {
  const dbName = req.session.activeDb;
  const { year, month } = req.query;
  res.json(await db.query(
    'SELECT * FROM workflow_log WHERE db_name = ? AND year = ? AND month = ? ORDER BY created_at',
    [dbName, year, month]
  ));
});

module.exports = router;
