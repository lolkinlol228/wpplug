'use strict';
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const { router: authRouter, requireAuth } = require('./routes/auth');
const apiRouter = require('./routes/api');
const exportRouter = require('./routes/export');
const { renderPage } = require('./renderer');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'tabel-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 86400 * 1000,
    httpOnly: true,
    sameSite: 'lax',
  },
}));

// ─── API Routes ───
app.use('/api', authRouter);
app.use('/api', apiRouter);
app.use('/export', exportRouter);

// ─── Main page ───
app.get('/', async (req, res) => {
  try {
    const html = await renderPage(req);
    res.send(html);
  } catch (e) {
    console.error('Render error:', e);
    res.status(500).send('<pre>Server error: ' + e.message + '</pre>');
  }
});

// ─── Static (favicon, etc) ───
app.use(express.static(path.join(__dirname, '../public'), { index: false }));

// ─── 404 ───
app.use((req, res) => res.status(404).json({ error: 'not_found' }));

// ─── Error handler ───
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'internal_error', message: err.message });
});

// ─── Start ───
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Tabel server running on http://0.0.0.0:${PORT}`);
  console.log(`   Login: Frazy / FrazyAmp`);
});
