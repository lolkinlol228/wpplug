let meIsAdmin = false;
let meUserId = null;

function escHtml(s) {
  if (!s) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}


function showPage(page) {
  if (currentPage === 'notifications' && page !== 'notifications') notifTabOpened = false;
  currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('nav-' + page).classList.add('active');
  if (page === 'employees') loadEmployees();
  if (page === 'positions') loadPositions();
  if (page === 'timesheet') loadTimesheet();
  if (page === 'excel-settings') loadExcelSettings();
  if (page === 'experience') loadExperiencePage();
  if (page === 'users') loadUsers();
  if (page === 'databases') loadDatabases();
  if (page === 'statistics') loadStats();
  if (page === 'history') loadHistory(1);
  if (page === 'notifications') loadNotifications();
  if (page === 'workflow') loadWorkflowPage();
  if (page === 'profile') loadProfilePage();
  if (page === 'admin-panel') loadAdminPanel();
  // Stop chat polling when leaving chat
}

function setLang(lang) {
  fetch(API_BASE + 'set_lang/' + lang).then(() => location.reload());
}

function changeMonth() {
  selectedMonth = parseInt(document.getElementById('monthSelect').value);
  selectedYear = parseInt(document.getElementById('yearInput').value);
  localStorage.setItem('selectedMonth', selectedMonth);
  localStorage.setItem('selectedYear', selectedYear);
  loadTimesheet();
}

function goCurrentMonth() {
  selectedYear = currentYear;
  selectedMonth = currentMonth;
  localStorage.setItem('selectedMonth', selectedMonth);
  localStorage.setItem('selectedYear', selectedYear);
  document.getElementById('monthSelect').value = selectedMonth;
  document.getElementById('yearInput').value = selectedYear;
  loadTimesheet();
}

function goPrevMonth() {
  let m = selectedMonth - 1, y = selectedYear;
  if (m < 1) { m = 12; y--; }
  selectedYear = y;
  selectedMonth = m;
  localStorage.setItem('selectedMonth', selectedMonth);
  localStorage.setItem('selectedYear', selectedYear);
  document.getElementById('monthSelect').value = selectedMonth;
  document.getElementById('yearInput').value = selectedYear;
  loadTimesheet();
}

function goNextMonth() {
  let m = selectedMonth + 1, y = selectedYear;
  if (m > 12) { m = 1; y++; }
  selectedYear = y;
  selectedMonth = m;
  localStorage.setItem('selectedMonth', selectedMonth);
  localStorage.setItem('selectedYear', selectedYear);
  document.getElementById('monthSelect').value = selectedMonth;
  document.getElementById('yearInput').value = selectedYear;
  loadTimesheet();
}


async function loadEmployees() {
  try {
    const res = await fetch(API_BASE + 'employees');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    employees = await res.json();
    if (showFiredEmployees) await loadFiredEmployees();
    renderEmployees();
  } catch (error) {
    console.error('Failed to load employees:', error);
  }
}

let firedEmployeesList = [];
let showFiredEmployees = false;
async function loadFiredEmployees() { try { const r = await fetch(API_BASE + 'employees/fired'); if (r.ok) firedEmployeesList = await r.json(); } catch(e) { firedEmployeesList = []; } }
async function toggleFiredEmployees() { showFiredEmployees = document.getElementById('showFiredCheck').checked; if (showFiredEmployees && !firedEmployeesList.length) await loadFiredEmployees(); renderEmployees(); }
// ─── Restore Employee Modal ───
let _restoreEmpId = null;
let _restoreEmpName = '';

function restoreFiredEmployee(empId) {
  // Find employee info from list
  const emp = firedEmployeesList.find(e => e.id === empId);
  _restoreEmpId = empId;
  _restoreEmpName = emp ? emp.full_name : '';

  // Populate year select
  const yearSel = document.getElementById('restoreYear');
  const curYear = new Date().getFullYear();
  yearSel.innerHTML = '';
  for (let y = curYear + 1; y >= curYear - 5; y--) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    if (y === selectedYear) opt.selected = true;
    yearSel.appendChild(opt);
  }

  // Set month
  document.getElementById('restoreMonth').value = selectedMonth;

  // Show fired date hint
  const hint = document.getElementById('restoreFiredHint');
  if (emp) {
    const mn = ['','Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
    hint.textContent = `Уволен: ${mn[emp.fired_month] || emp.fired_month} ${emp.fired_year}`;
    hint.style.display = 'block';
  } else {
    hint.style.display = 'none';
  }

  document.getElementById('restoreEmpName').textContent = _restoreEmpName;
  document.getElementById('restoreModal').classList.remove('hidden');
}

function closeRestoreModal() {
  document.getElementById('restoreModal').classList.add('hidden');
  _restoreEmpId = null;
}

async function confirmRestoreEmployee() {
  if (!_restoreEmpId) return;
  const year  = parseInt(document.getElementById('restoreYear').value);
  const month = parseInt(document.getElementById('restoreMonth').value);
  if (!year || !month || month < 1 || month > 12) {
    document.getElementById('restoreError').textContent = 'Укажите корректный год и месяц';
    document.getElementById('restoreError').style.display = 'block';
    return;
  }
  document.getElementById('restoreError').style.display = 'none';
  const btn = document.getElementById('restoreConfirmBtn');
  btn.disabled = true; btn.textContent = 'Восстанавливаем...';

  try {
    const r = await fetch(API_BASE + 'employee/fire', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ employee_id: _restoreEmpId, year, month, fire: false })
    });
    const d = await r.json();
    if (d.ok === false) throw new Error(d.error || 'Ошибка');
    closeRestoreModal();
    showToast('✅ Сотрудник восстановлен', 'success');
    await loadFiredEmployees();
    renderEmployees();
    await loadTimesheet();
  } catch(e) {
    document.getElementById('restoreError').textContent = e.message || 'Ошибка соединения';
    document.getElementById('restoreError').style.display = 'block';
  } finally {
    btn.disabled = false; btn.textContent = '✅ Восстановить';
  }
}

function renderEmployees() {
  const grid = document.getElementById('empGrid');
  if (!employees.length && !showFiredEmployees) {
    grid.innerHTML = `<div class="empty-state"><p>${T.no_employees}</p></div>`;
    return;
  }
  let firedHtml = '';
  if (firedEmployeesList.length > 0 && showFiredEmployees) {
    const mn = ['','Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];
    firedHtml = '<div style="margin-bottom:16px;padding:12px 16px;background:#fff8e1;border:1px solid #ffe082;border-radius:var(--radius)"><div style="font-weight:600;font-size:13px;color:#7a4700;margin-bottom:8px">🚫 Уволенные</div>' +
      firedEmployeesList.map(e => `<div class="emp-card" style="border-color:#ffe082;background:#fffbe6"><div class="emp-info"><div class="emp-name" style="text-decoration:line-through;opacity:0.7">${escHtml(e.full_name)}</div><div class="emp-meta"><span class="emp-badge" style="background:#ffebe9;color:var(--danger);border-color:#ffadb5">Уволен: ${mn[e.fired_month]} ${e.fired_year}</span></div></div><div class="emp-actions"><button class="btn btn-success" style="font-size:12px" onclick="restoreFiredEmployee(${e.id})">♻️ Восстановить</button></div></div>`).join('') + '</div>';
  }
  grid.innerHTML = firedHtml + employees.map(e => {
    const posName = e.position_name || e.position || '';
    const empType = e.employment_internal || e.employment_external || '';
    const empTypeLabel = empType === 'staff' ? (T.staff || 'Штат') : 
                        empType === 'part_time' ? (T.part_time || 'Совм.') : '';
    const noteHtml = e.note ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:4px;padding:4px 8px;background:var(--surface2);border-radius:4px;border-left:2px solid var(--primary)">📝 ${escHtml(e.note)}</div>` : '';
    return `
    <div class="emp-card">
      <div class="emp-info">
        <div class="emp-name">${escHtml(e.full_name)}</div>
        <div class="emp-pos">${escHtml(posName)}</div>
        <div class="emp-meta">
          ${empTypeLabel ? `<span class="emp-badge badge-rate">${empTypeLabel}</span>` : ''}
          <span class="emp-badge badge-rate">${T.rate || 'Ставка'}: ${e.rate || 0}</span>
          ${e.pedagog_experience ? `<span class="emp-badge badge-fixed">${escHtml(e.pedagog_experience)}</span>` : ''}
        </div>
        ${noteHtml}
      </div>
      <div class="emp-actions">
        <button class="btn btn-ghost" onclick="editEmployee(${e.id})">${T['edit'] || ''}</button>
        <button class="btn btn-danger" onclick="deleteEmployee(${e.id})">${T['delete'] || ''}</button>
      </div>
    </div>
  `;
  }).join('');
}

async function saveEmployee() {
  if (!editingEmpId && isWorkflowBlocked()) { showToast('🔒 Нельзя добавлять сотрудников — не ваша очередь в цепочке','warning'); return; }
  const posId = document.getElementById('empPosition').value;
  const posName = positions.find(p => p.id == posId)?.name || '';
  
  const empValue = document.getElementById('empEmployment').value;
  let empInternal = null;
  let empExternal = null;
  if (empValue === 'staff_internal') empInternal = 'staff';
  else if (empValue === 'part_time_internal') empInternal = 'part_time';
  else if (empValue === 'part_time_external') empExternal = 'part_time';
  
  const data = {
    full_name: document.getElementById('empName').value.trim(),
    position: posName,
    position_id: posId ? parseInt(posId) : null,
    pay_type: document.getElementById('empPayType').value,
    rate: parseFloat(document.getElementById('empRate').value) || 0,
    employment_internal: empInternal,
    employment_external: empExternal,
    pedagog_experience: document.getElementById('empExperience').value.trim() || null,
    actual_hours: parseFloat(document.getElementById('empActualHours').value) || null,
    note: document.getElementById('empNote') ? document.getElementById('empNote').value.trim() || null : null,
  };
  if (!data.full_name) return;


  try {
    if (editingEmpId) {
      const response = await fetch(API_BASE + `employees/${editingEmpId}`, { 
        method:'PUT', 
        headers:{'Content-Type':'application/json'}, 
        body: JSON.stringify(data) 
      });
      const result = await response.json();
      editingEmpId = null;
      document.getElementById('cancelEditBtn').style.display = 'none';
    } else {
      const response = await fetch(API_BASE + 'employees', { 
        method:'POST', 
        headers:{'Content-Type':'application/json'}, 
        body: JSON.stringify(data) 
      });
      const result = await response.json();
    }
    
    // Очищаем форму и принудительно перезагружаем
    clearForm();
    
    // Принудительная перезагрузка с небольшой задержкой
    setTimeout(async () => {
      await loadEmployees();
      await loadTimesheet();
    }, 100);
    
  } catch (error) {
    console.error('ERROR: Failed to save employee:', error);
    showToast('Ошибка при сохранении','error');
  }
}

function editEmployee(id) {
  const e = employees.find(x => x.id == id);
  if (!e) return;
  editingEmpId = id;
  document.getElementById('empName').value = e.full_name;
  document.getElementById('empPosition').value = e.position_id || '';
  document.getElementById('empPayType').value = e.pay_type;
  document.getElementById('empRate').value = e.rate;
  // Устанавливаем единый select условий работы
  let empVal = '';
  if (e.employment_internal === 'staff') empVal = 'staff_internal';
  else if (e.employment_internal === 'part_time') empVal = 'part_time_internal';
  else if (e.employment_external === 'part_time') empVal = 'part_time_external';
  document.getElementById('empEmployment').value = empVal;
  document.getElementById('empExperience').value = e.pedagog_experience || '';
  document.getElementById('empActualHours').value = e.actual_hours || '';
  if (document.getElementById('empNote')) document.getElementById('empNote').value = e.note || '';
  document.getElementById('cancelEditBtn').style.display = 'inline-flex';
  toggleRateLabel();
}

async function deleteEmployee(id) {
  if (!confirm(T.confirm_delete)) return;
  await fetch(API_BASE + `employees/${id}`, { method:'DELETE' });
  await loadEmployees();
  await loadTimesheet();
}

function cancelEdit() {
  editingEmpId = null;
  document.getElementById('cancelEditBtn').style.display = 'none';
  clearForm();
}

function clearForm() {
  document.getElementById('empName').value = '';
  document.getElementById('empPosition').value = '';
  document.getElementById('empPayType').value = 'rate';
  document.getElementById('empRate').value = '';
  document.getElementById('empEmployment').value = '';
  document.getElementById('empExperience').value = '';
  document.getElementById('empActualHours').value = '';
  if (document.getElementById('empNote')) document.getElementById('empNote').value = '';
  toggleRateLabel();
}

function toggleRateLabel() {
  const pt = document.getElementById('empPayType').value;
  const rateInput = document.getElementById('empRate');

  if (pt === 'fixed') {
    // Фиксированная сумма — поле редактируемое
    document.getElementById('rateLabel').innerHTML = T.fixed || 'Фиксированная сумма';
    rateInput.readOnly = false;
    rateInput.style.background = 'var(--surface)';
    rateInput.style.cursor = 'text';
    rateInput.placeholder = 'Введите сумму';
  } else {
    // По ставке:
    // - Для ППС: ставка считается автоматически из факт.часов → readOnly
    // - Для Сотрудников: ставка вводится вручную → редактируемая
    document.getElementById('rateLabel').innerHTML = T.rate || 'Ставка';
    if (activeDbType === 'staff') {
      rateInput.readOnly = false;
      rateInput.style.background = 'var(--surface)';
      rateInput.style.cursor = 'text';
      rateInput.placeholder = '0.00';
    } else {
      rateInput.readOnly = true;
      rateInput.style.background = 'var(--surface2)';
      rateInput.style.cursor = 'not-allowed';
      rateInput.placeholder = '0.00 (рассчитывается)';
    }
  }
}

function updateRateCalculation() {
  // Для staff-режима ставка вводится вручную — не трогаем
  if (activeDbType === 'staff') return;

  const pt = document.getElementById('empPayType').value;
  if (pt === 'fixed') return;

  const posId = document.getElementById('empPosition').value;
  const actualHours = parseFloat(document.getElementById('empActualHours').value) || 0;

  if (!posId || !actualHours) {
    document.getElementById('empRate').value = '0.00';
    return;
  }

  const pos = positions.find(p => p.id == posId);
  if (pos && pos.planned_hours) {
    document.getElementById('empRate').value = (actualHours / pos.planned_hours).toFixed(2);
  }
}

// ============ ДОЛЖНОСТИ ============

async function loadPositions() {
  const res = await fetch(API_BASE + 'positions');
  positions = await res.json();
  
  // Обновляем select в форме сотрудника
  const sel = document.getElementById('empPosition');
  sel.innerHTML = `<option value="">${T['position'] || ''}</option>`;
  positions.forEach(p => {
    sel.innerHTML += `<option value="${p.id}">${p.name}</option>`;
  });
  
  renderPositions();
}

function renderPositions() {
  const grid = document.getElementById('posGrid');
  if (!positions.length) {
    grid.innerHTML = '<div class="empty-state"><p>Нет должностей</p></div>';
    return;
  }
  
  grid.innerHTML = positions.map(p => `
    <div class="emp-card">
      <div class="emp-info">
        <div class="emp-name">${p.name}</div>
        <div class="emp-meta">
          <span class="emp-badge badge-rate">${p.planned_hours} ч.</span>
        </div>
      </div>
      <div class="emp-actions">
        <button class="btn btn-ghost" onclick="editPosition(${p.id})">${T['edit'] || ''}</button>
        <button class="btn btn-danger" onclick="deletePosition(${p.id})">${T['delete'] || ''}</button>
      </div>
    </div>
  `).join('');
}

async function savePosition() {
  const data = {
    name_ru: document.getElementById('posNameRu').value.trim(),
    name_kg: document.getElementById('posNameKg').value.trim(),
    name_en: document.getElementById('posNameEn').value.trim(),
    planned_hours: parseInt(document.getElementById('posHours').value) || 0,
  };
  
  if (!data.name_ru) {
    showToast('Заполните название (RU)','warning');
    return;
  }
  
  if (editingPosId) {
    await fetch(API_BASE + `positions/${editingPosId}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
    editingPosId = null;
    document.getElementById('cancelPosBtn').style.display = 'none';
  } else {
    await fetch(API_BASE + 'positions', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
  }
  
  clearPosForm();
  loadPositions();
}

function editPosition(id) {
  const p = positions.find(x => x.id == id);
  if (!p) return;
  editingPosId = id;
  document.getElementById('posNameRu').value = p.name_ru;
  document.getElementById('posNameKg').value = p.name_kg;
  document.getElementById('posNameEn').value = p.name_en;
  document.getElementById('posHours').value = p.planned_hours;
  document.getElementById('cancelPosBtn').style.display = 'inline-flex';
}

async function deletePosition(id) {
  if (!confirm('Удалить должность?')) return;
  const res = await fetch(API_BASE + `positions/${id}`, { method:'DELETE' });
  const result = await res.json();
  if (!result.ok) {
    showToast(result.error || 'Ошибка при удалении','error');
    return;
  }
  loadPositions();
}

function cancelEditPos() {
  editingPosId = null;
  clearPosForm();
  document.getElementById('cancelPosBtn').style.display = 'none';
}

function clearPosForm() {
  document.getElementById('posNameRu').value = '';
  document.getElementById('posNameKg').value = '';
  document.getElementById('posNameEn').value = '';
  document.getElementById('posHours').value = '';
}


let acTimeout;
async function searchEmployees(q) {
  clearTimeout(acTimeout);
  const list = document.getElementById('nameAutocomplete');
  if (q.length < 2) { list.classList.remove('show'); return; }
  acTimeout = setTimeout(async () => {
    const res = await fetch(API_BASE + `employees/search&q=${encodeURIComponent(q)}`);
    const items = await res.json();
    if (!items.length) { list.classList.remove('show'); return; }
    list.innerHTML = items.map(i => `
      <div class="autocomplete-item" onclick="selectAutoComplete('${i.full_name}','${i.position}')">
        ${i.full_name} <small>${i.position}</small>
      </div>`).join('');
    list.classList.add('show');
  }, 200);
}

function selectAutoComplete(name, position) {
  document.getElementById('empName').value = name;
  document.getElementById('empPosition').value = position;
  document.getElementById('nameAutocomplete').classList.remove('show');
}

document.addEventListener('click', e => {
  if (!e.target.closest('.autocomplete-list') && !e.target.closest('#empName'))
    document.getElementById('nameAutocomplete').classList.remove('show');
});


async function loadTimesheet() {
  try {
    const [tsRes] = await Promise.all([
      fetch(API_BASE + `timesheet/${selectedYear}/${selectedMonth}`),
      loadWorkflowStatus()
    ]);
    if (!tsRes.ok) throw new Error(`HTTP ${tsRes.status}`);
    const data = await tsRes.json();
    renderTimesheet(data);
  } catch (error) {
    document.getElementById('tsContent').innerHTML = `<div class="empty-state"><p>Ошибка загрузки: ${error.message}</p></div>`;
  }
}

function renderTimesheet(data) {
  timesheetData = data;
  window._statusMarkMap = data.status_to_mark || {};
  const { employees: rawEmps, days, day_names } = data;
  
  // Sort: non-fixed first (A-Z), then fixed (A-Z)
  const emps = [...rawEmps].sort((a, b) => {
    const aFixed = (a.employee.pay_type === 'fixed') ? 1 : 0;
    const bFixed = (b.employee.pay_type === 'fixed') ? 1 : 0;
    if (aFixed !== bFixed) return aFixed - bFixed;
    return (a.employee.full_name || '').localeCompare(b.employee.full_name || '', 'ru');
  });
  const monthLabel = T[MONTH_KEYS[selectedMonth - 1]] + ' ' + selectedYear;
  document.getElementById('tsMonthLabel').textContent = monthLabel;

  if (!emps.length) {
    document.getElementById('tsContent').innerHTML = `<div class="empty-state"><p>${T.no_employees}</p></div>`;
    return;
  }

  
  const isStaff = (data.db_type === 'staff');
  
  let html = '<div class="ts-table-wrap"><table class="ts-table"><thead><tr>';
  html += `<th class="emp-check-header"><input type="checkbox" id="checkAllEmps" checked onchange="toggleAllEmpChecks(this.checked)" style="accent-color:var(--primary);width:14px;height:14px;cursor:pointer" title="Отметить / убрать всех"></th>`;
  html += `<th>${T.number}</th><th>${T.full_name}</th><th>${T.position}</th>`;
  html += `<th>${T.employment_conditions}</th>`;
  if (!isStaff) {
    html += `<th>${T.pedagog_experience || 'Стаж'}</th>`;
    html += `<th>${T.actual_hours || 'Факт.ч.'}</th>`;
  }
  html += `<th>${T.rate}</th>`;
  for (const d of days) {
    const dn = day_names[d.weekday];
    const cls = d.is_sunday ? ' sunday' : '';
    html += `<th class="day-header${cls}" onclick="openDayDropdown(event, ${d.day})" style="cursor:pointer" title="${T.click_to_change_all}">${d.day}<br>${dn}</th>`;
  }
  html += `<th>${T.working_days}</th><th>${T.weekends}</th><th>${T.days_in_month}</th>`;
  html += '</tr></thead><tbody>';

  emps.forEach((emp, idx) => {
    const e = emp.employee;
    const customClass = e.has_custom_settings ? 'has-custom' : '';
    
    // Единое поле условий работы
    let employmentLabel = '-';
    let employmentValue = null; // для определения что сейчас выбрано
    if (e.employment_internal === 'staff') {
      employmentLabel = T.staff_internal || 'Штатный';
      employmentValue = 'staff_internal';
    } else if (e.employment_internal === 'part_time') {
      employmentLabel = T.part_time_internal || 'Совм. внутр.';
      employmentValue = 'part_time_internal';
    } else if (e.employment_external === 'part_time') {
      employmentLabel = T.part_time_external || 'Совм. внешн.';
      employmentValue = 'part_time_external';
    }
    
    html += '<tr>';
    html += `<td class="emp-check-cell"><input type="checkbox" class="emp-export-check" data-emp-id="${e.id}" checked onchange="updateEmpCheckBar()"></td>`;
    // Fire/restore - only if can manage employees
    const canManageEmp = hasPerm('can_manage_employees');
    if (canManageEmp) {
      html += `<td class="emp-number" onclick="toggleEmployeeStatus(${e.id}, \`${e.full_name}\`, ${e.is_fired || false})" style="cursor:pointer; color:var(--primary); font-weight:600;" title="${e.is_fired ? 'Восстановить' : 'Уволить'}">${idx+1}</td>`;
    } else {
      html += `<td class="emp-number">${idx+1}</td>`;
    }
    
    // FIO
    const noteTooltip = e.note ? ` data-tooltip="${escHtml(e.note)}"` : '';
    if (hasPerm('can_edit_fio')) {
      html += `<td class="name-cell-editable" contenteditable="true" data-employee-id="${e.id}" data-field="full_name" onblur="updateEmployeeName(this)"${noteTooltip}>${e.full_name || ''}</td>`;
    } else {
      html += `<td${noteTooltip}>${e.full_name || ''}</td>`;
    }
    
    // Position
    if (hasPerm('can_edit_position_col')) {
      html += `<td class="pos-cell ${customClass}" onclick="openPositionDropdown(event, ${e.id})" style="cursor:pointer" title="${T.click_to_select_position}">${e.position || ''}</td>`;
    } else {
      html += `<td class="pos-cell">${e.position || ''}</td>`;
    }
    
    // Employment/conditions
    if (hasPerm('can_edit_conditions')) {
      html += `<td onclick="openEmploymentDropdown(event, ${e.id})" style="cursor:pointer; font-size:11px;" title="${T.click_to_change_employment}">${employmentLabel}</td>`;
    } else {
      html += `<td style="font-size:11px;">${employmentLabel}</td>`;
    }
    
    // Pedagog experience + Actual hours — скрыть для staff БД
    if (!isStaff) {
      // Pedagog experience
      if (e.experience_auto) {
        html += `<td style="color:var(--primary);font-weight:500" title="Авто-расчёт из стажа">${e.pedagog_experience || ''}</td>`;
      } else if (hasPerm('can_edit_experience')) {
        html += `<td contenteditable="true" data-employee-id="${e.id}" data-field="pedagog_experience" onblur="updateEmployeeField(this)" style="cursor:text">${e.pedagog_experience || ''}</td>`;
      } else {
        html += `<td>${e.pedagog_experience || ''}</td>`;
      }
    
      // Actual hours
      if (hasPerm('can_edit_hours')) {
        html += `<td contenteditable="true" data-employee-id="${e.id}" data-field="actual_hours" onblur="updateEmployeeField(this)" style="cursor:text" title="${T.actual_hours_hint}">${e.actual_hours || ''}</td>`;
      } else {
        html += `<td>${e.actual_hours || ''}</td>`;
      }
    }
    
    // Rate
    if (hasPerm('can_edit_rate')) {
      const manualCls = e.rate_manual ? ' rate-manual' : '';
      const manualTitle = e.rate_manual ? (T.rate_manual_hint || 'Ставка установлена вручную') : (T.rate_hint || '');
      const resetBtn = e.rate_manual ? `<span class="rate-manual-badge" onmousedown="event.preventDefault();event.stopPropagation();resetRateManual(${e.id})" title="${T.rate_reset_confirm || 'Сбросить на авто'}">✎↺</span>` : '';
      html += `<td class="rate-cell${manualCls}" style="position:relative;padding-right:${e.rate_manual ? '20px' : ''};cursor:text;" onclick="this.querySelector('span[contenteditable]')?.focus()"><span contenteditable="true" data-employee-id="${e.id}" data-field="rate" data-rate-manual="${e.rate_manual || 0}" onblur="updateEmployeeField(this)" style="cursor:text;outline:none;display:inline-block;min-width:100%;min-height:100%;" title="${manualTitle}">${e.rate || 0}</span>${resetBtn}</td>`;
    } else {
      const resetBtn = e.rate_manual ? `<span class="rate-manual-badge" style="cursor:default">✎</span>` : '';
      html += `<td class="rate-cell${e.rate_manual ? ' rate-manual' : ''}">${e.rate || 0}${resetBtn}</td>`;
    }

    for (const dc of emp.day_cells) {
      const cls = `status-${dc.status}`;
      const customStyle = dc.custom_value && timesheetData.custom_marks ? (() => {
        const cm = timesheetData.custom_marks.find(m => m.symbol === dc.custom_value);
        return cm && cm.color ? `background:${cm.color}22;color:${cm.color};font-weight:600` : '';
      })() : '';
      if (hasPerm('can_edit_days')) {
        html += `<td class="day-cell ${dc.custom_value ? '' : cls}" data-emp="${e.id}" data-day="${dc.day}" ${customStyle ? `style="${customStyle}"` : ''}>${dc.display}</td>`;
      } else {
        html += `<td class="day-cell ${dc.custom_value ? '' : cls}" ${customStyle ? `style="${customStyle};cursor:default"` : 'style="cursor:default"'}>${dc.display}</td>`;
      }
    }

    html += `<td class="summary-cell">${emp.working_days}</td>`;
    html += `<td class="summary-cell">${emp.weekends}</td>`;
    html += `<td class="summary-cell">${emp.total_days}</td>`;
    html += '</tr>';
  });

  html += '</tbody></table></div>';
  
  // Workflow status bar
  const blocked = isWorkflowBlocked();
  if (wfCurrentStatus && wfCurrentStatus.chains && wfCurrentStatus.chains.length) {
    const statusMap = {draft:'⬜ Черновик',in_progress:'🔄 В процессе',revision:'🔙 На доработке',completed:'✅ Завершён'};
    const st = wfCurrentStatus.status || 'draft';
    const curStep = wfCurrentStatus.current_step;
    const curChain = wfCurrentStatus.chains[curStep];
    const isCompleted = st === 'completed';
    
    let bgStyle = blocked || isCompleted ? 'background:#fff3e0;border:1px solid #FFB74D' : 'background:#e8f5e9;border:1px solid #81C784';
    if (isCompleted) bgStyle = 'background:#e8f5e9;border:1px solid #81C784';
    
    let wfHtml = `<div style="padding:10px 14px;margin-bottom:8px;border-radius:var(--radius);display:flex;align-items:center;gap:10px;flex-wrap:wrap;font-size:13px;${bgStyle}">
      <span style="font-weight:700">${statusMap[st]||st}</span>`;
    
    if (isCompleted) {
      wfHtml += `<span style="color:#2e7d32">🔒 Табель согласован и заблокирован</span>`;
    } else if (curChain && wfCurrentStatus.activated) {
      wfHtml += `<span>Этап: <b>${curChain.step_name}</b></span>`;
    }
    
    if (blocked && !isCompleted && !meIsAdmin) {
      wfHtml += `<span style="color:#E65100">🔒 Только чтение — ожидайте вашей очереди</span>`;
    }
    
    if (canSubmitWorkflow() && !meIsAdmin) {
      wfHtml += `<button class="btn btn-primary" style="margin-left:auto;font-size:12px" onclick="workflowSubmit()">📤 Отправить дальше</button>`;
    }
    
    if (!isCompleted && canReturnWorkflow()) {
      const returnBtns = wfCurrentStatus.chains
        .filter((c, i) => i < curStep && !c.is_reviewer)
        .map(c => `<button class="btn btn-ghost" style="font-size:11px;color:var(--danger)" onclick="workflowReturn(${c.step_order})">🔙 ${c.step_name}</button>`).join('');
      if (returnBtns) wfHtml += returnBtns;
    }
    
    wfHtml += '</div>';
    html = wfHtml + html;
  }

  document.getElementById('tsContent').innerHTML = html;

  // Панель "Отметить всех / Убрать всех" — вставляем перед таблицей
  const _cb = document.createElement('div');
  _cb.className = 'export-check-bar';
  _cb.innerHTML =
    `<button class="btn btn-ghost" style="font-size:12px;padding:5px 10px" onclick="toggleAllEmpChecks(true)">☑ Отметить всех</button>` +
    `<button class="btn btn-ghost" style="font-size:12px;padding:5px 10px" onclick="toggleAllEmpChecks(false)">☐ Убрать всех</button>` +
    `<span class="check-count" id="empCheckCount"></span>` +
    `<span style="color:var(--text-tertiary);font-size:11px">— только отмеченные попадут в Excel</span>`;
  var _tw = document.querySelector('#tsContent .ts-table-wrap');
  if (_tw) _tw.parentNode.insertBefore(_cb, _tw);
  
  // Block all editing if workflow blocked
  if (blocked && !meIsAdmin) {
    document.querySelectorAll('#tsContent [contenteditable]').forEach(el => {
      el.contentEditable = 'false';
      el.style.cursor = 'default';
    });
    document.querySelectorAll('#tsContent .day-cell[data-emp]').forEach(el => {
      el.removeAttribute('data-emp');
      el.removeAttribute('data-day');
      el.style.cursor = 'default';
    });
    document.querySelectorAll('#tsContent .pos-cell[onclick], #tsContent td[onclick], #tsContent .emp-number[onclick]').forEach(el => {
      el.removeAttribute('onclick');
      el.style.cursor = 'default';
    });
  }
  
  // Init drag selection for cells
  initDragSelect();

  // Inject custom marks into cell/day dropdowns
  updateCustomMarksInDropdowns(data.custom_marks || []);

  const expDiv = document.getElementById('exportByEmployee');
  expDiv.innerHTML = '<div style="border-top:1px solid var(--border); margin-top:4px; padding-top:4px; font-size:11px; color:var(--text-tertiary); padding-left:12px;">' + T.export_employee + '</div>';
  emps.forEach(emp => {
    expDiv.innerHTML += `<a href="#" onclick="exportEmployee(${emp.employee.id}); return false;" class="exp-emp-link" data-emp-id="${emp.employee.id}">${emp.employee.full_name}</a>`;
  });
  updateEmpCheckBar();
}


let dayDropdownTarget = null;

function openDayDropdown(event, day) {
  if (isWorkflowBlocked() && !meIsAdmin) return;
  event.stopPropagation();
  dayDropdownTarget = day;
  const dd = document.getElementById('dayDropdown');
  dd.classList.add('show');
  const rect = event.target.getBoundingClientRect();
  positionDropdown(dd, rect);
}

document.addEventListener('click', e => {
  if (!e.target.closest('#dayDropdown') && !e.target.closest('.day-header')) {
    const dd = document.getElementById('dayDropdown');
    if (dd) dd.classList.remove('show');
  }
});

async function setDayStatusForAll(status) {
  if (dayDropdownTarget === null) return;
  document.getElementById('dayDropdown').classList.remove('show');
  
  document.querySelectorAll(`td.day-cell[data-day="${dayDropdownTarget}"]`).forEach(cell => {
    const empId = Number(cell.dataset.emp);
    cell.textContent = getCellDisplay(status, empId, dayDropdownTarget);
    cell.className = 'day-cell status-' + status;
  });
  
  // Пересчитать рабочие дни для всех сотрудников в столбце
  const affectedEmps = new Set([...document.querySelectorAll(`td.day-cell[data-day="${dayDropdownTarget}"]`)].map(c => Number(c.dataset.emp)));
  affectedEmps.forEach(eid => recalcEmployeeSummary(eid));
  
  try {
    const res = await fetch(API_BASE + 'timesheet/bulk', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ year: selectedYear, month: selectedMonth, day: dayDropdownTarget, status })
    });
    if (!res.ok) throw new Error();
  } catch(e) {
    showToast('❌ Ошибка сохранения', 'error');
    loadTimesheet();
  }
}


function saveScrollPosition() {
  const wrap = document.querySelector('.ts-table-wrap');
  if (!wrap) return null;
  return {
    scrollLeft: wrap.scrollLeft,
    scrollTop: wrap.scrollTop
  };
}

function restoreScrollPosition(pos) {
  if (!pos) return;
  const wrap = document.querySelector('.ts-table-wrap');
  if (!wrap) return;
  wrap.scrollLeft = pos.scrollLeft;
  wrap.scrollTop = pos.scrollTop;
}


// Умное позиционирование дропдауна — открывается вверх если не помещается вниз
function positionDropdown(dd, rect) {
  dd.style.left = '';
  dd.style.top = '';
  dd.style.bottom = '';
  dd.style.right = '';
  dd.style.maxHeight = '';
  const ddW = dd.offsetWidth || 180;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const margin = 8;
  const spaceBelow = vh - rect.bottom - margin;
  const spaceAbove = rect.top - margin;
  // Открыть вверх если снизу меньше места И сверху больше
  if (spaceBelow < 200 && spaceAbove > spaceBelow) {
    const availH = Math.min(spaceAbove, vh * 0.7);
    dd.style.maxHeight = availH + 'px';
    dd.style.top = (rect.top - availH - 4) + 'px';
  } else {
    const availH = Math.min(spaceBelow, vh * 0.7);
    dd.style.maxHeight = availH + 'px';
    dd.style.top = (rect.bottom + 4) + 'px';
  }
  // Горизонталь: если уходит за правый край — сдвинуть влево
  const left = Math.min(rect.left, vw - ddW - margin);
  dd.style.left = Math.max(4, left) + 'px';
}

function openCellDropdown(event, empId, day) {
  if (isWorkflowBlocked() && !meIsAdmin) return;
  event.stopPropagation();
  dropdownTarget = { employeeId: empId, day };
  const dd = document.getElementById('cellDropdown');
  dd.classList.add('show');
  const rect = event.target.getBoundingClientRect();
  positionDropdown(dd, rect);
  document.getElementById('customCellValue').value = '';
}

document.addEventListener('click', e => {
  if (dragJustFinished) return;
  if (!e.target.closest('.cell-dropdown') && !e.target.closest('.day-cell')) {
    document.getElementById('cellDropdown').classList.remove('show');
    clearDragSelection();
    bulkTargets = [];
  }
});

// Status-to-color map for custom mark dots
const MARK_STATUS_COLORS = {
  work:'#4CAF50', day_off:'#E91E63', holiday:'#FF9800', sick:'#2196F3',
  vacation:'#9C27B0', business_trip:'#FF9800', maternity:'#E91E63',
  childcare:'#FF5722', study_leave:'#607D8B', admin_leave:'#795548',
  absence:'#F44336', late:'#FF6F00', early_leave:'#BF360C'
};

// Standard mark symbols that are already in the hardcoded dropdown
const STANDARD_SYMBOLS = new Set(['К','О','С','КӨ','БӨ','ОӨ','АӨ','Дк','Кк','Эк']);

function updateCustomMarksInDropdowns(marks) {
  // Always remove old custom marks first
  document.querySelectorAll('.custom-mark-item, .custom-mark-divider').forEach(el => el.remove());
  
  if (!marks || !marks.length) return;
  
  // Build a color map from ALL marks (including standard ones for color override)
  const markColorMap = {};
  marks.forEach(m => { if (m.symbol && m.color) markColorMap[m.symbol.trim()] = m.color; });
  
  // Update colors of standard buttons in cellDropdown and dayDropdown
  document.querySelectorAll('#cellDropdown button[onclick*="setCellStatus"], #dayDropdown button[onclick*="setDayStatusForAll"]').forEach(btn => {
    const match = btn.textContent.match(/\(([^)]+)\)\s*$/);
    if (match && markColorMap[match[1]]) {
      const dot = btn.querySelector('.dot');
      if (dot) dot.style.background = markColorMap[match[1]];
    }
  });
  
  // Only show marks that are NOT already standard
  const newMarks = marks.filter(m => m.symbol && !STANDARD_SYMBOLS.has(m.symbol.trim()));
  if (!newMarks.length) return;
  
  const cellDD = document.getElementById('cellDropdown');
  const dayDD = document.getElementById('dayDropdown');
  const dividerText = T.es_marks_panel || 'Условные обозначения';
  
  const markBtns = newMarks.map(m => ({
    symbol: m.symbol,
    color: m.color || '#9E9E9E',
    label: m.symbol + (m.description ? ' — ' + m.description : ''),
  }));

  // Insert into cellDropdown before the custom-input-row (no extra divider)
  const customInput = cellDD.querySelector('.custom-input-row');
  if (customInput) {
    markBtns.forEach(m => {
      const btn = document.createElement('button');
      btn.className = 'custom-mark-item';
      btn.innerHTML = `<span class="dot" style="background:${m.color}"></span>${m.label}`;
      btn.onclick = () => setCellMarkCustom('work', m.symbol);
      customInput.before(btn);
    });
  }
  
  // Insert into dayDropdown at the end (no extra divider)
  if (dayDD) {
    markBtns.forEach(m => {
      const btn = document.createElement('button');
      btn.className = 'custom-mark-item';
      btn.innerHTML = `<span class="dot" style="background:${m.color}"></span>${m.label}`;
      btn.onclick = () => setDayMarkCustomForAll('work', m.symbol);
      dayDD.appendChild(btn);
    });
  }
}

async function setCellMarkCustom(status, symbol) {
  if (!dropdownTarget) return;
  const scrollPos = saveScrollPosition();
  await fetch(API_BASE + 'timesheet/entry', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      employee_id: dropdownTarget.employeeId,
      year: selectedYear, month: selectedMonth, day: dropdownTarget.day,
      status: status, custom_value: symbol,
    })
  });
  document.getElementById('cellDropdown').classList.remove('show');
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}

async function setDayMarkCustomForAll(status, symbol) {
  const scrollPos = saveScrollPosition();
  await fetch(API_BASE + 'timesheet/bulk', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      year: selectedYear, month: selectedMonth, day: dayDropdownTarget,
      status: status, custom_value: symbol,
    })
  });
  document.getElementById('dayDropdown').classList.remove('show');
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}

const DEFAULT_MARKS = {
  vacation:'К', sick:'О', business_trip:'С', maternity:'КӨ', childcare:'БӨ',
  study_leave:'ОӨ', admin_leave:'АӨ', absence:'Дк', late:'Кк', early_leave:'Эк'
};

function getCellDisplay(status, employeeId, day) {
  const MK = window._statusMarkMap || {};
  if (status === 'day_off') return '-';
  if (status !== 'work') return MK[status] || DEFAULT_MARKS[status] || status;
  if (!timesheetData || !timesheetData.employees) return '+';
  const empData = timesheetData.employees.find(e => e.employee && e.employee.id == employeeId);
  if (!empData || !empData.employee) return '+';
  const e = empData.employee;
  const rate = parseFloat(e.rate);
  if (!rate || rate <= 0 || e.pay_type === 'fixed') return '+';
  const dbType = timesheetData.db_type || 'pps';
  if (dbType === 'staff') {
    const dayInfo = timesheetData.days ? timesheetData.days.find(d => d.day == day) : null;
    const wd = dayInfo ? dayInfo.weekday : 0;
    return String(round2(rate * (wd === 5 ? 5 : 7)));
  }
  return String(round2(rate * 6));
}

function round2(n) { return Math.round(n * 100) / 100; }

// Update summary columns (working days, weekends) instantly from DOM
function recalcEmployeeSummary(employeeId) {
  const cells = document.querySelectorAll(`td.day-cell[data-emp="${employeeId}"]`);
  let workDays = 0, weekends = 0;
  cells.forEach(c => {
    const cls = c.className || '';
    // A cell counts as work if it has status-work OR has no status-day_off/holiday/sick etc
    // We check explicitly what status it has
    if (cls.includes('status-work')) workDays++;
    else if (cls.includes('status-day_off')) weekends++;
    // cells with custom_value have no status class — they are work days
    else if (!cls.includes('status-')) workDays++;
  });
  const row = cells.length ? cells[0].closest('tr') : null;
  if (row) {
    const sc = row.querySelectorAll('.summary-cell');
    if (sc[0]) sc[0].textContent = workDays;
    if (sc[1]) sc[1].textContent = weekends;
  }
}

async function setCellStatus(status) {
  // Bulk mode
  if (bulkTargets && bulkTargets.length > 0) { await setCellStatusBulk(status); return; }
  
  if (!dropdownTarget) return;
  const {employeeId, day} = dropdownTarget;
  document.getElementById('cellDropdown').classList.remove('show');
  
  const cell = document.querySelector(`td.day-cell[data-emp="${employeeId}"][data-day="${day}"]`);
  const prevText = cell ? cell.textContent : '';
  const prevClass = cell ? cell.className : '';
  if (cell) {
    cell.textContent = getCellDisplay(status, employeeId, day);
    cell.className = 'day-cell status-' + status;
  }
  recalcEmployeeSummary(employeeId);
  
  try {
    const res = await fetch(API_BASE + 'timesheet/entry', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({employee_id: employeeId, year: selectedYear, month: selectedMonth, day, status})
    });
    if (!res.ok) throw new Error();
  } catch(e) {
    if (cell) { cell.textContent = prevText; cell.className = prevClass; }
    recalcEmployeeSummary(employeeId); // пересчёт после отката
    showToast('❌ Ошибка сохранения', 'error');
  }
}

async function setCellCustom() {
  const val = document.getElementById('customCellValue').value.trim();
  if (!val) return;
  
  // Bulk mode
  if (bulkTargets && bulkTargets.length > 0) {
    document.getElementById('cellDropdown').classList.remove('show');
    bulkTargets.forEach(t => {
      const cell = document.querySelector(`td.day-cell[data-emp="${t.emp}"][data-day="${t.day}"]`);
      if (cell) { cell.textContent = val; cell.className = 'day-cell status-work'; }
    });
    const cells = [...bulkTargets];
    clearDragSelection(); bulkTargets = [];
    try {
      const res = await fetch(API_BASE + 'timesheet/batch', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({cells, year: selectedYear, month: selectedMonth, status: 'work', custom_value: val})
      });
      if (!res.ok) throw new Error();
    } catch(e) { showToast('❌ Ошибка', 'error'); loadTimesheet(); }
    return;
  }
  
  if (!dropdownTarget) return;
  const {employeeId, day} = dropdownTarget;
  document.getElementById('cellDropdown').classList.remove('show');
  
  const cell = document.querySelector(`td.day-cell[data-emp="${employeeId}"][data-day="${day}"]`);
  const prevText = cell ? cell.textContent : '';
  const prevClass = cell ? cell.className : '';
  if (cell) { cell.textContent = val; cell.className = 'day-cell status-work'; }
  
  try {
    const res = await fetch(API_BASE + 'timesheet/entry', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({employee_id: employeeId, year: selectedYear, month: selectedMonth, day, status: 'work', custom_value: val})
    });
    if (!res.ok) throw new Error();
  } catch(e) {
    if (cell) { cell.textContent = prevText; cell.className = prevClass; }
    showToast('❌ Ошибка сохранения', 'error');
  }
}

async function sundayBulk(status) {
  document.getElementById('dayDropdown').classList.remove('show');
  await fetch(API_BASE + 'timesheet/sunday_bulk', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ year: selectedYear, month: selectedMonth, status })
  });
  loadTimesheet();
}


async function updateMonthlyField(cell) {
  const employeeId = parseInt(cell.dataset.employeeId);
  const field = cell.dataset.field;
  const value = cell.textContent.trim();
  
  if (!value) return;
  
  const data = {
    employee_id: employeeId,
    year: selectedYear,
    month: selectedMonth,
  };
  
  if (field === 'position') {
    data.position = value;
    data.rate = null; 
  } else if (field === 'rate') {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) {
      showToast('Ставка должна быть числом','warning');
      loadTimesheet();
      return;
    }
    data.rate = numValue;
    data.rate_manual = 1; // User manually set rate via monthly settings
    data.position = null; 
  }
  
  await fetch(API_BASE + 'monthly_settings', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  
  loadTimesheet();
}


// Переменная для хранения данных о выбираемой должности
let positionDropdownTarget = null;

// Открыть выпадающее меню для выбора должности
function openPositionDropdown(event, employeeId) {
  if (isWorkflowBlocked() && !meIsAdmin) return;
  event.stopPropagation();
  
  // Находим текущую должность сотрудника из данных табеля
  let currentPosition = '';
  if (timesheetData && timesheetData.employees) {
    const empData = timesheetData.employees.find(e => e.employee.id == employeeId);
    if (empData) {
      currentPosition = empData.employee.position || '';
    }
  }
  
  positionDropdownTarget = { employeeId, currentPosition };
  
  const dd = document.getElementById('positionDropdown');
  const content = document.getElementById('positionDropdownContent');
  
  // Формируем список должностей
  let html = '';
  positions.forEach(pos => {
    const isSelected = pos.name === currentPosition ? ' style="background:var(--surface2)"' : '';
    const safeName = pos.name.replace(/'/g, "\\'");
    html += `<button onclick="setEmployeePosition('${safeName}')"${isSelected}>${pos.name}</button>`;
  });
  content.innerHTML = html;
  
  dd.classList.add('show');
  const rect = event.target.getBoundingClientRect();
  positionDropdown(dd, rect);
}

// Закрытие dropdown при клике вне его
document.addEventListener('click', e => {
  if (!e.target.closest('#positionDropdown') && !e.target.closest('.pos-cell')) {
    document.getElementById('positionDropdown').classList.remove('show');
  }
});

// Установить выбранную должность для сотрудника
async function setEmployeePosition(positionName) {
  if (!positionDropdownTarget) return;
  
  const scrollPos = saveScrollPosition();
  
  // Находим выбранную должность чтобы получить planned_hours
  const selectedPos = positions.find(p => p.name === positionName);
  
  // Находим сотрудника чтобы получить actual_hours и pay_type
  let actualHours = null;
  let payType = null;
  let rateManual = false;
  if (timesheetData && timesheetData.employees) {
    const empData = timesheetData.employees.find(e => e.employee.id == positionDropdownTarget.employeeId);
    if (empData) {
      actualHours = empData.employee.actual_hours;
      payType = empData.employee.pay_type;
      rateManual = empData.employee.rate_manual;
    }
  }
  
  // Рассчитываем новую ставку ТОЛЬКО если pay_type = 'rate' И ставка НЕ установлена вручную
  let newRate = null;
  if (!rateManual && payType === 'rate' && selectedPos && selectedPos.planned_hours && actualHours) {
    newRate = Math.round((actualHours / selectedPos.planned_hours) * 100) / 100;
  }
  
  // Отправляем запрос с обновлением должности и должности ID
  await fetch(API_BASE + 'employee/update_position', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      employee_id: positionDropdownTarget.employeeId,
      year: selectedYear,
      month: selectedMonth,
      position: positionName,
      position_id: selectedPos ? selectedPos.id : null,
      rate: newRate
    })
  });
  
  document.getElementById('positionDropdown').classList.remove('show');
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}

// Уволить или восстановить сотрудника
async function toggleEmployeeStatus(employeeId, employeeName, isFired) {
  if (isWorkflowBlocked() && !meIsAdmin) { showToast('🔒 Табель заблокирован','warning'); return; }

  let name = employeeName || '';
  if (!name && timesheetData && timesheetData.employees) {
    const empData = timesheetData.employees.find(e => e.employee.id == employeeId);
    if (empData) name = empData.employee.full_name || '';
  }

  if (isFired) {
    // Восстановление — открываем модальное окно с выбором года и месяца
    if (!firedEmployeesList.find(e => e.id === employeeId)) {
      firedEmployeesList.push({ id: employeeId, full_name: name, fired_year: selectedYear, fired_month: selectedMonth });
    }
    restoreFiredEmployee(employeeId);
    return;
  }

  // Увольнение — confirm + запрос
  const mn = ['','Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  if (!confirm(`Уволить "${name}" начиная с ${mn[selectedMonth]} ${selectedYear}?`)) return;

  const scrollPos = saveScrollPosition();
  await fetch(API_BASE + 'employee/fire', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ employee_id: employeeId, year: selectedYear, month: selectedMonth, fire: true })
  });
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}

// Переменная для типа занятости
let employmentDropdownTarget = null;

// Открыть единое выпадающее меню для условий работы
function openEmploymentDropdown(event, employeeId) {
  if (isWorkflowBlocked() && !meIsAdmin) return;
  event.stopPropagation();
  
  // Находим текущие значения
  let currentInternal = null;
  let currentExternal = null;
  if (timesheetData && timesheetData.employees) {
    const empData = timesheetData.employees.find(e => e.employee.id == employeeId);
    if (empData) {
      currentInternal = empData.employee.employment_internal;
      currentExternal = empData.employee.employment_external;
    }
  }
  
  employmentDropdownTarget = { employeeId };
  
  const dd = document.getElementById('employmentDropdown');
  const content = document.getElementById('employmentDropdownContent');
  
  // Определяем текущий выбор
  const isStaffInt = currentInternal === 'staff';
  const isPartInt = currentInternal === 'part_time';
  const isPartExt = currentExternal === 'part_time';
  const isNone = !currentInternal && !currentExternal;
  
  let html = '';
  html += `<button onclick="setEmploymentUnified(null, null)" ${isNone ? 'style="background:var(--surface2)"' : ''}>— ${T.not_selected || 'Тандалган эмес'}</button>`;
  html += `<button onclick="setEmploymentUnified('staff', null)" ${isStaffInt ? 'style="background:var(--surface2)"' : ''}>${T.staff_internal || 'Штатный'}</button>`;
  html += `<button onclick="setEmploymentUnified('part_time', null)" ${isPartInt ? 'style="background:var(--surface2)"' : ''}>${T.part_time_internal || 'Совм. внутр.'}</button>`;
  html += `<button onclick="setEmploymentUnified(null, 'part_time')" ${isPartExt ? 'style="background:var(--surface2)"' : ''}>${T.part_time_external || 'Совм. внешн.'}</button>`;
  
  content.innerHTML = html;
  
  dd.classList.add('show');
  const rect = event.target.getBoundingClientRect();
  positionDropdown(dd, rect);
}

// Закрытие dropdown типа занятости
document.addEventListener('click', e => {
  if (!e.target.closest('#employmentDropdown')) {
    document.getElementById('employmentDropdown').classList.remove('show');
  }
});

// Установить условия работы (всегда отправляем оба поля, одно заполнено, другое null)
async function setEmploymentUnified(internalValue, externalValue) {
  if (!employmentDropdownTarget) return;
  
  const scrollPos = saveScrollPosition();
  document.getElementById('employmentDropdown').classList.remove('show');
  
  const data = {
    employee_id: employmentDropdownTarget.employeeId,
    year: selectedYear,
    month: selectedMonth,
    employment_internal: internalValue,
    employment_external: externalValue
  };
  
  // Optimistic: update local data and re-render just the cell
  if (timesheetData && timesheetData.employees) {
    const empData = timesheetData.employees.find(e => e.employee.id == employmentDropdownTarget.employeeId);
    if (empData) {
      empData.employee.employment_internal = internalValue;
      empData.employee.employment_external = externalValue;
    }
  }
  
  // Fire request, reload after to sync totals
  await fetch(API_BASE + 'employee/update_employment', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}

// Обновить поле сотрудника (фактические часы или пед.стаж)
async function updateEmployeeField(cell) {
  if (isWorkflowBlocked() && !meIsAdmin) { loadTimesheet(); return; }
  const employeeId = parseInt(cell.dataset.employeeId);
  const field = cell.dataset.field;
  const value = cell.textContent.trim();
  
  const scrollPos = saveScrollPosition();
  
  const data = {
    employee_id: employeeId,
    year: selectedYear,
    month: selectedMonth
  };
  
  if (field === 'actual_hours') {
    const numValue = parseFloat(value);
    if (isNaN(numValue) && value !== '') {
      showToast('Факт. часы должны быть числом','warning');
      await loadTimesheet();
      restoreScrollPosition(scrollPos);
      return;
    }
    data.actual_hours = value === '' ? null : numValue;
    
    // Пересчитываем ставку ТОЛЬКО если pay_type = 'rate' И ставка НЕ установлена вручную
    if (timesheetData && timesheetData.employees) {
      const empData = timesheetData.employees.find(e => e.employee.id == employeeId);
      if (empData && empData.employee.pay_type === 'rate' && !empData.employee.rate_manual && empData.employee.position_id && numValue) {
        const pos = positions.find(p => p.id == empData.employee.position_id);
        if (pos && pos.planned_hours) {
          data.rate = Math.round((numValue / pos.planned_hours) * 100) / 100;
        }
      }
    }
  } else if (field === 'rate') {
    const numValue = parseFloat(value);
    if (isNaN(numValue) && value !== '') {
      showToast('Ставка должна быть числом','warning');
      await loadTimesheet();
      restoreScrollPosition(scrollPos);
      return;
    }
    data.rate = value === '' ? null : numValue;
    // Direct edit → marks as manual on the server side
    // Update day cells immediately in DOM so user sees change without waiting
    if (numValue > 0) {
      const empData = timesheetData && timesheetData.employees
        ? timesheetData.employees.find(e => e.employee.id == employeeId) : null;
      if (empData && empData.employee.pay_type === 'rate') {
        const dailyValue = Math.round(numValue * 6 * 100) / 100;
        const dayCells = document.querySelectorAll(`td.day-cell[data-emp="${employeeId}"]`);
        dayCells.forEach(c => {
          if (c.className.includes('status-work') || (!c.className.includes('status-'))) {
            if (!c.dataset.customValue) c.textContent = dailyValue;
          }
        });
      }
    }
  } else if (field === 'pedagog_experience') {
    data.pedagog_experience = value || null;
  }
  
  await fetch(API_BASE + 'employee/update_field', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}

// Сбросить ручной режим ставки → пересчитать автоматически
async function resetRateManual(employeeId) {
  if (!timesheetData || !timesheetData.employees) return;
  const empData = timesheetData.employees.find(e => e.employee.id == employeeId);
  if (!empData || !empData.employee.rate_manual) return;
  
  const msg = (T.rate_reset_confirm || 'Сбросить ручную ставку и пересчитать автоматически?');
  if (!confirm(msg)) return;
  
  const scrollPos = saveScrollPosition();
  const e = empData.employee;
  
  // Пересчитываем ставку из факт.часов / план.часов
  let newRate = null;
  if (e.pay_type === 'rate' && e.position_id && e.actual_hours) {
    const pos = positions.find(p => p.id == e.position_id);
    if (pos && pos.planned_hours) {
      newRate = Math.round((e.actual_hours / pos.planned_hours) * 100) / 100;
    }
  }
  
  try {
    const res = await fetch(API_BASE + 'monthly_settings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        employee_id: employeeId,
        year: selectedYear,
        month: selectedMonth,
        rate: newRate,
        rate_manual: 0
      })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      showToast('❌ ' + (err.error || 'Ошибка сброса ставки'), 'error');
      return;
    }
  } catch(e) {
    showToast('❌ Ошибка сети', 'error');
    return;
  }
  
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}


// Обновить имя сотрудника из таблицы
async function updateEmployeeName(cell) {
  if (isWorkflowBlocked() && !meIsAdmin) { loadTimesheet(); return; }
  const employeeId = parseInt(cell.dataset.employeeId);
  const newName = cell.textContent.trim();
  
  if (!newName) {
    await loadTimesheet();
    return;
  }
  
  const scrollPos = saveScrollPosition();
  
  await fetch(API_BASE + `employees/${employeeId}/name`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ 
      full_name: newName,
      year: selectedYear,
      month: selectedMonth
    })
  });
  
  await loadTimesheet();
  restoreScrollPosition(scrollPos);
}


// ===== EXCEL НАСТРОЙКИ =====
// ===== STATUS OPTIONS for mark dropdown =====
const STATUS_OPTIONS = [
  {value: '', label: '— ' + (T.not_selected || 'не выбрано') + ' —'},
  {value: 'vacation',      label: '🟣 ' + (T.vacation || 'Каникулы') + ' (К)'},
  {value: 'sick',          label: '🔵 ' + (T.sick || 'Больничный') + ' (О)'},
  {value: 'business_trip', label: '🟠 ' + (T.business_trip || 'Командировка') + ' (С)'},
  {value: 'maternity',     label: '🩷 ' + (T.maternity || 'Декрет') + ' (КӨ)'},
  {value: 'childcare',     label: '🟤 ' + (T.childcare || 'Уход за ребенком') + ' (БӨ)'},
  {value: 'study_leave',   label: '⬜ ' + (T.study_leave || 'Учебный') + ' (ОӨ)'},
  {value: 'admin_leave',   label: '🟫 ' + (T.admin_leave || 'Адм. отпуск') + ' (АӨ)'},
  {value: 'absence',       label: '🔴 ' + (T.absence || 'Неявка') + ' (Дк)'},
  {value: 'late',          label: '🟡 ' + (T.late || 'Опоздание') + ' (Кк)'},
  {value: 'early_leave',   label: '🟠 ' + (T.early_leave || 'Ранний уход') + ' (Эк)'},
];

let excelSettings = {};
let marksList = []; // [{symbol, status, description}, ...]

function renderMarksList() {
  const list = document.getElementById('marksSettingsList');
  if (!list) return;
  
  if (marksList.length === 0) {
    list.innerHTML = `
      <div style="padding:16px 0;color:var(--text-tertiary);font-size:13px;text-align:center">
        ${T.es_add_mark ? T.es_add_mark + ' ↓' : 'Нет обозначений'}
      </div>`;
    return;
  }
  
  list.innerHTML = marksList.map((m, idx) => {
    const isStandard = STANDARD_SYMBOLS.has((m.symbol||'').trim());
    const color = m.color || MARK_STATUS_COLORS[m.status] || '#9E9E9E';
    return `
    <div class="es-mark-row" data-idx="${idx}" style="display:grid;grid-template-columns:36px 70px 1fr 36px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)">
      <input type="color" class="mk-color" value="${color}" oninput="marksList[${idx}].color=this.value"
             style="width:32px;height:32px;padding:0;border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;background:none">
      <input type="text" class="mk-symbol" value="${(m.symbol||'').replace(/"/g,'&quot;')}" placeholder="К"
             maxlength="4" oninput="marksList[${idx}].symbol=this.value"
             style="text-align:center;font-weight:700;font-size:16px;padding:6px 4px;border:1px solid var(--border);border-radius:var(--radius);width:100%">
      <input type="text" class="mk-desc" value="${(m.description||'').replace(/"/g,'&quot;')}" placeholder="${T.es_description || 'Описание'}..."
             oninput="marksList[${idx}].description=this.value"
             style="padding:6px 10px;border:1px solid var(--border);border-radius:var(--radius);font-family:inherit;font-size:13px;width:100%">
      <button onclick="deleteMark(${idx})" title="Удалить"
              style="padding:5px 9px;background:#ffebe9;border:1px solid #ffadb5;border-radius:var(--radius);cursor:pointer;font-size:14px;color:var(--danger);font-weight:700">✕</button>
    </div>`;
  }).join('');
}

function addMark() {
  marksList.push({symbol: '', status: '', description: '', color: '#9E9E9E'});
  renderMarksList();
}

function deleteMark(idx) {
  marksList.splice(idx, 1);
  renderMarksList();
}

async function loadExcelSettings() {
  try {
    const res = await fetch(API_BASE + 'excel_settings');
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      if (err.error === 'no_db') {
        document.getElementById('marksSettingsList').innerHTML =
          '<p style="color:var(--text-secondary);font-size:13px;padding:8px 0">⚠️ Сначала выберите базу данных</p>';
      }
      return;
    }
    excelSettings = await res.json();
    
    // Fill header fields
    ['header_left1','header_left2','header_left3',
     'header_center1','header_center2','header_center3',
     'header_right1','header_right2','header_right3',
     'sig1','sig2','sig3','doc_title'].forEach(key => {
      const el = document.getElementById('s_' + key);
      if (el && excelSettings[key] !== undefined) el.value = excelSettings[key];
    });
    
    // Load marks list
    if (Array.isArray(excelSettings.marks_list)) {
      marksList = JSON.parse(JSON.stringify(excelSettings.marks_list));
    } else {
      marksList = [];
    }
    renderMarksList();
  } catch(e) {
    console.error('loadExcelSettings error:', e);
  }
}

async function saveExcelSettings() {
  const data = {};
  ['header_left1','header_left2','header_left3',
   'header_center1','header_center2','header_center3',
   'header_right1','header_right2','header_right3',
   'sig1','sig2','sig3','doc_title'].forEach(key => {
    const el = document.getElementById('s_' + key);
    if (el) data[key] = el.value;
  });
  
  // Sync marks from DOM to marksList
  document.querySelectorAll('.es-mark-row').forEach((row, idx) => {
    const sym = row.querySelector('.mk-symbol');
    const desc = row.querySelector('.mk-desc');
    const col = row.querySelector('.mk-color');
    if (sym && marksList[idx] !== undefined) {
      marksList[idx].symbol = sym.value;
      marksList[idx].description = desc ? desc.value : '';
      marksList[idx].color = col ? col.value : '';
    }
  });
  
  data.marks_list = marksList;
  
  const res = await fetch(API_BASE + 'excel_settings', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  
  const btn = document.getElementById('excelSaveBtn');
  if (res.ok) {
    const orig = btn.innerHTML;
    btn.innerHTML = '✅ Сакталды!';
    btn.disabled = true;
    setTimeout(() => { btn.innerHTML = orig; btn.disabled = false; }, 2000);
  } else {
    btn.innerHTML = '❌ Ката';
    setTimeout(() => { btn.innerHTML = '💾 Баарын сактоо'; btn.disabled = false; }, 2000);
  }
}

function toggleExportMenu() {
  document.getElementById('exportDropdown').classList.toggle('show');
}
document.addEventListener('click', e => {
  if (!e.target.closest('.export-menu'))
    document.getElementById('exportDropdown').classList.remove('show');
});

function exportFull() {
  var ids = getCheckedEmpIds();
  var q = '&emp_ids=' + (ids.length ? ids.join(',') : 'none');
  window.open(EXPORT_BASE + 'full/' + selectedYear + '/' + selectedMonth + q, '_blank');
}
function exportBrief() {
  var ids = getCheckedEmpIds();
  var q = '&emp_ids=' + (ids.length ? ids.join(',') : 'none');
  window.open(EXPORT_BASE + 'brief/' + selectedYear + '/' + selectedMonth + q, '_blank');
}
function exportEmployee(eid) {
  window.open(EXPORT_BASE + 'employee/' + eid + '/' + selectedYear + '/' + selectedMonth, '_blank');
}

// Экспорт стажа в Excel
function exportExperienceExcel() {
  if (!activeDbName) { alert('Выберите базу данных'); return; }
  window.open(EXPORT_BASE + 'experience_excel', '_blank');
}

// Экспорт БД в ZIP
function exportDbBackup() {
  var db = activeDbName;
  var url = EXPORT_BASE + 'backup_zip' + (db ? '&db=' + encodeURIComponent(db) : '');
  // Суперадмин может выбрать — текущую БД или всё
  if (meIsAdmin && db) {
    if (!confirm('Экспортировать только базу «' + db + '»?\n\nОК — только эта БД\nОтмена — все данные')) {
      url = EXPORT_BASE + 'backup_zip';
    }
  }
  window.open(url, '_blank');
}

// Импорт БД из ZIP
async function importDbBackup(input) {
  if (!input.files || !input.files[0]) return;
  var file = input.files[0];
  input.value = '';

  var mode = confirm('Режим импорта:\n\nОК — Merge (добавить к существующим данным)\nОтмена — Replace (заменить данные текущей БД)') ? 'merge' : 'replace';

  if (mode === 'replace' && !confirm('⚠️ Все данные текущей базы «' + (activeDbName || 'все') + '» будут УДАЛЕНЫ и заменены. Продолжить?')) {
    return;
  }

  var fd = new FormData();
  fd.append('backup_zip', file);
  fd.append('mode', mode);
  if (activeDbName) fd.append('db_name', activeDbName);

  var btn = document.querySelector('[onclick="document.getElementById(\'importBackupInput\').click()"]');
  if (btn) { btn.textContent = '⏳ Импорт...'; btn.disabled = true; }

  try {
    var res = await fetch(API_BASE + 'import_backup', { method: 'POST', body: fd });
    var data = await res.json();
    if (data.ok) {
      var summary = Object.entries(data.imported || {}).map(([t, n]) => t + ': ' + n + ' записей').join('\n');
      alert('✅ Импорт завершён!\n\n' + summary);
      window.location.reload();
    } else {
      alert('❌ Ошибка: ' + (data.error || 'Неизвестная ошибка'));
    }
  } catch (e) {
    alert('❌ Ошибка соединения');
  } finally {
    if (btn) { btn.textContent = '📥 Импорт ZIP'; btn.disabled = false; }
  }
}

function getCheckedEmpIds() {
  return Array.prototype.slice.call(document.querySelectorAll('.emp-export-check:checked')).map(function(cb){ return cb.dataset.empId; });
}

function toggleAllEmpChecks(state) {
  document.querySelectorAll('.emp-export-check').forEach(function(cb){ cb.checked = state; });
  var master = document.getElementById('checkAllEmps');
  if (master) { master.checked = state; master.indeterminate = false; }
  updateEmpCheckBar();
}

function updateEmpCheckBar() {
  var all     = document.querySelectorAll('.emp-export-check');
  var checked = document.querySelectorAll('.emp-export-check:checked');

  // Счётчик
  var countEl = document.getElementById('empCheckCount');
  if (countEl) countEl.textContent = 'Отмечено: ' + checked.length + ' из ' + all.length;

  // Мастер-чекбокс
  var master = document.getElementById('checkAllEmps');
  if (master) {
    master.indeterminate = checked.length > 0 && checked.length < all.length;
    master.checked = checked.length === all.length;
  }

  // Скрыть/показать ссылки экспорта по сотруднику
  document.querySelectorAll('.exp-emp-link').forEach(function(link) {
    var cb = document.querySelector('.emp-export-check[data-emp-id="' + link.dataset.empId + '"]');
    link.style.display = (cb && cb.checked) ? '' : 'none';
  });
}


document.getElementById('monthSelect').value = selectedMonth;
document.getElementById('yearInput').value = selectedYear;

// ===== INIT: load current user & permissions =====
const PERM_LABELS = {
  can_manage_databases: '🗄️ Управление базами данных',
  can_view_stats: '📊 Просмотр статистики',
  can_view_history: '🕐 История экспортов',
  can_export_excel: '📥 Скачивание Excel',
  can_fire_employee: '🚫 Увольнение сотрудников',
  can_manage_employees: '👤 Управление сотрудниками',
  can_manage_positions: '💼 Управление должностями',
  can_edit_excel: '📊 Редактировать Excel / Заголовки',
  can_edit_fio: '✏️ Редактировать ФИО в табеле',
  can_edit_position_col: '💼 Менять должность в табеле',
  can_edit_conditions: '📋 Менять шарттары в табеле',
  can_edit_experience: '🎓 Менять стаж в табеле',
  can_edit_hours: '⏱️ Менять факт.часы в табеле',
  can_edit_rate: '💰 Менять ставку в табеле',
  can_edit_days: '📅 Редактировать дни табеля',
  can_manage_experience: '🕐 Управление стажем',
  can_access_during_maintenance: '🔧 Доступ во время тех. работ',
  can_toggle_maintenance: '⚙️ Включать / выключать тех. работы',
  can_send_notifications: '🔔 Отправка уведомлений',
  can_manage_workflow: '🔗 Управление цепочкой согласования',
};

let accessibleDbs = [];
let activeDbName = null;
let activeDbType = 'pps'; // 'pps' or 'staff'

async function initMe() {
  try {
    const res = await fetch(API_BASE + 'me');
    if (res.status === 401) { window.location.reload(); return; }
    const me = await res.json();
    if (!me.logged_in) { window.location.reload(); return; }
    
    meIsAdmin = me.is_superadmin;
    meUserId = me.user_id;
    mePerms = me.perms || {};
    accessibleDbs = me.accessible_dbs || [];
    activeDbName = me.active_db || null;
    const activeDbObj = accessibleDbs.find(d => d.name === activeDbName);
    activeDbType = activeDbObj ? (activeDbObj.db_type || 'pps') : 'pps';
    
    // Update user bar
    const uname = me.username || '?';
    const displayName = me.display_name && me.display_name.trim() ? me.display_name.trim() : uname;
    const avatarLetter = displayName[0].toUpperCase();
    document.getElementById('sidebarAvatar').textContent = avatarLetter;
    document.getElementById('sidebarUsername').textContent = displayName;
    document.getElementById('sidebarRole').textContent = meIsAdmin ? '⭐ Суперадмин' : 'Пользователь';
    
    // Show privileged nav items
    if (meIsAdmin) {
      document.getElementById('nav-users').style.display = '';
      document.getElementById('nav-databases').style.display = '';
      document.getElementById('nav-statistics').style.display = '';
      document.getElementById('nav-history').style.display = '';
      document.getElementById('nav-workflow').style.display = '';
      document.getElementById('nav-experience').style.display = '';
      document.getElementById('nav-admin-panel').style.display = '';
    } else {
      if (mePerms.can_manage_databases) document.getElementById('nav-databases').style.display = '';
      if (mePerms.can_view_stats) document.getElementById('nav-statistics').style.display = '';
      if (mePerms.can_view_history) document.getElementById('nav-history').style.display = '';
      if (mePerms.can_manage_employees) document.getElementById('nav-experience').style.display = '';
      if (mePerms.can_manage_experience) document.getElementById('nav-experience').style.display = '';
      if (mePerms.can_manage_workflow) document.getElementById('nav-workflow').style.display = '';
      if (mePerms.can_toggle_maintenance) document.getElementById('nav-admin-panel').style.display = '';
    }
    
    // Load notification count
    pollNotifications();
    
    // Poll chat unread count
    
    // Render DB switcher
    renderDbSwitcher();
    initStatSelectors();
    
    // Apply permission visibility restrictions
    applyPermUI();
    // Apply db type UI (pps vs staff)
    applyDbTypeModeUI();
    
    // Show gentle banner if no db, but don't block
    updateNoDbBanner();
    
    // Load data only if we have an active db
    if (activeDbName) {
      loadTimesheet();
      loadEmployees();
      loadPositions();
    }
    
  } catch(e) {
    console.error('Auth check failed', e);
  }
}

function updateNoDbBanner() {
  const banner = document.getElementById('noDbBanner');
  if (!banner) return;
  if (!activeDbName) {
    banner.style.display = 'flex';
    const canCreate = meIsAdmin || mePerms.can_manage_databases;
    const actionBtn = canCreate
      ? `<button class="btn btn-primary" style="margin-left:auto;font-size:12px" onclick="showPage('databases')">＋ Создать / выбрать БД</button>`
      : `<span style="margin-left:auto;color:var(--text-secondary);font-size:12px">Обратитесь к администратору</span>`;
    banner.innerHTML = `<span>⚠️ База данных не выбрана.</span>${actionBtn}`;
  } else {
    banner.style.display = 'none';
  }
}


function applyDbTypeModeUI() {
  // Hide/show pps-only fields (actual_hours, pedagog_experience, planned_hours)
  const isStaffMode = (activeDbType === 'staff');
  document.querySelectorAll('.pps-only-field').forEach(el => {
    el.style.display = isStaffMode ? 'none' : '';
  });
  // Update DB type badge in switcher
  const badge = document.getElementById('dbTypeBadge');
  if (badge) {
    badge.textContent = isStaffMode ? '👷 Сотр.' : '🎓 ППС';
    badge.style.background = isStaffMode ? '#fff8c5' : '#ddf4ff';
    badge.style.color = isStaffMode ? '#7a4700' : 'var(--primary)';
  }
}
// ===== DB SWITCHER =====
function renderDbSwitcher() {
  const nameEl = document.getElementById('dbActiveName');
  const dropdown = document.getElementById('dbDropdown');
  
  if (activeDbName) {
    const activeDb = accessibleDbs.find(d => d.name === activeDbName);
    nameEl.textContent = activeDb ? activeDb.display_name : activeDbName;
  } else {
    nameEl.textContent = 'Не выбрана';
  }
  
  if (accessibleDbs.length <= 1) {
    // Hide switcher arrow if only one db
    const btn = document.getElementById('dbSelectBtn');
    if (btn) btn.querySelector('.db-arrow').style.display = 'none';
  }
  
  dropdown.innerHTML = accessibleDbs.map(db => `
    <div class="db-opt ${db.name === activeDbName ? 'active' : ''}" onclick="switchDb('${db.name}')">
      <span class="db-dot"></span>
      ${db.display_name}
    </div>
  `).join('') || '<div style="padding:8px 10px;font-size:12px;color:var(--text-tertiary)">Нет доступных БД</div>';
}

function toggleDbDropdown() {
  if (accessibleDbs.length <= 1) return;
  document.getElementById('dbDropdown').classList.toggle('show');
}

document.addEventListener('click', e => {
  if (!e.target.closest('#dbSwitcherWrap')) {
    const dd = document.getElementById('dbDropdown');
    if (dd) dd.classList.remove('show');
  }
});

async function switchDb(dbName, force) {
  document.getElementById('dbDropdown').classList.remove('show');
  if (!force && dbName === activeDbName) return;
  
  const res = await fetch(API_BASE + 'switch_db', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({db_name: dbName})
  });
  const data = await res.json();
  if (data.ok) {
    activeDbName = dbName;
    const swDbObj = accessibleDbs.find(d => d.name === dbName);
    activeDbType = data.db_type || (swDbObj ? swDbObj.db_type : 'pps') || 'pps';
    renderDbSwitcher();
    updateNoDbBanner();
    applyDbTypeModeUI();
    toggleRateLabel();
    loadTimesheet();
    loadEmployees();
    loadPositions();
    if (currentPage === 'workflow') loadWorkflowPage();
  } else {
    showToast(data.error || 'Ошибка','error');
  }
}

// ===== DATABASE MANAGEMENT PAGE =====
let assigningDb = null;
let allUsersForAssign = [];

async function loadDatabases() {
  const res = await fetch(API_BASE + 'databases');
  if (!res.ok) return;
  const dbs = await res.json();
  
  // Show create button for those with permission
  const createBtn = document.getElementById('createDbBtn');
  if (createBtn && (meIsAdmin || mePerms.can_manage_databases)) {
    createBtn.style.display = '';
  }
  
  const grid = document.getElementById('dbsGrid');
  if (!dbs.length) {
    grid.innerHTML = '<div class="empty-state"><p>Нет баз данных. Создайте первую.</p></div>';
    return;
  }
  
  grid.innerHTML = dbs.map(db => `
    <div class="db-card">
      <div class="db-card-icon">🗄️</div>
      <div class="db-card-info">
        <div class="db-card-name">${db.display_name}</div>
        <div class="db-card-meta">
          Системное имя: <code>${db.name}</code>
          &nbsp;·&nbsp;
          ${db.db_type === 'staff' ? '👷 Сотрудники (Пн–Пт×7, Сб×5)' : '🎓 ППС (ставка×6)'}
        </div>
      </div>
      <div class="db-card-actions">
        <button class="btn btn-ghost" onclick="switchDb('${db.name}'); showPage('timesheet');" style="font-size:12px">
          ${db.name === activeDbName ? '✅ Активна' : '🔄 Открыть'}
        </button>
        ${meIsAdmin ? `
          <button class="btn btn-ghost" onclick="openDbAssignModal('${db.name}', '${db.display_name}')" style="font-size:12px">👥 Доступ</button>
          <button class="btn btn-danger" onclick="deleteDb('${db.name}', '${db.display_name}')" style="font-size:12px">✕</button>
        ` : ''}
      </div>
    </div>
  `).join('');
}

function openCreateDbModal() {
  document.getElementById('db_display_name').value = '';
  document.getElementById('db_sys_name').value = '';
  document.getElementById('db_sys_name').dataset.manual = '';
  selectedDbType = 'pps';
  selectDbType('pps');
  document.getElementById('dbModal').classList.remove('hidden');
}
function closeDbModal() {
  document.getElementById('dbModal').classList.add('hidden');
}

function autoDbName(input) {
  // Auto-suggest sys name from display name
}

document.getElementById('db_display_name').addEventListener('input', function() {
  const sysInput = document.getElementById('db_sys_name');
  if (!sysInput.dataset.manual) {
    sysInput.value = this.value
      .toLowerCase()
      .replace(/\s+/g, '_')
      .replace(/[^a-z0-9_-]/g, '');
  }
});
document.getElementById('db_sys_name').addEventListener('input', function() {
  this.dataset.manual = '1';
});

let selectedDbType = 'pps';

function selectDbType(type) {
  selectedDbType = type;
  const ppsCard = document.getElementById('dbTypeCardPps');
  const staffCard = document.getElementById('dbTypeCardStaff');
  if (type === 'pps') {
    ppsCard.style.borderColor = 'var(--primary)';
    ppsCard.style.background = '#ddf4ff';
    staffCard.style.borderColor = 'var(--border)';
    staffCard.style.background = 'var(--surface)';
  } else {
    staffCard.style.borderColor = 'var(--primary)';
    staffCard.style.background = '#ddf4ff';
    ppsCard.style.borderColor = 'var(--border)';
    ppsCard.style.background = 'var(--surface)';
  }
}

async function saveDbModal() {
  const display_name = document.getElementById('db_display_name').value.trim();
  const name = document.getElementById('db_sys_name').value.trim();
  if (!display_name || !name) { showToast('Заполните все поля','warning'); return; }
  
  const res = await fetch(API_BASE + 'databases', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({display_name, name, db_type: selectedDbType})
  });
  const data = await res.json();
  if (!data.ok) { showToast(data.error || 'Ошибка','error'); return; }
  
  closeDbModal();
  accessibleDbs.push({name: data.name, display_name, db_type: data.db_type || selectedDbType});
  renderDbSwitcher();
  loadDatabases();
  await switchDb(data.name, true);
}

async function deleteDb(dbName, displayName) {
  if (!confirm('Удалить базу данных "' + displayName + '"? Данные НЕ удаляются с диска.')) return;
  const res = await fetch(API_BASE + 'databases/' + dbName, {method: 'DELETE'});
  const data = await res.json();
  if (!data.ok) { showToast(data.error || 'Ошибка','error'); return; }
  accessibleDbs = accessibleDbs.filter(d => d.name !== dbName);
  if (activeDbName === dbName) {
    activeDbName = null;
    updateNoDbBanner();
  }
  renderDbSwitcher();
  loadDatabases();
}

async function openDbAssignModal(dbName, displayName) {
  assigningDb = dbName;
  document.getElementById('dbAssignTitle').textContent = '👥 Доступ к БД: ' + displayName;
  
  // Load all users and current assignments
  const [usersRes, assignedRes] = await Promise.all([
    fetch(API_BASE + 'users'),
    fetch(API_BASE + 'databases/' + dbName + '/users').catch(() => ({json: () => []}))
  ]);
  
  const users = await usersRes.json();
  let assigned = [];
  try { assigned = await assignedRes.json(); } catch(e) {}
  const assignedIds = new Set(assigned.map(u => u.id));
  
  const nonAdmins = users.filter(u => !u.is_superadmin);
  document.getElementById('dbAssignUserList').innerHTML = nonAdmins.length === 0
    ? '<p style="color:var(--text-secondary);font-size:13px">Нет обычных пользователей</p>'
    : nonAdmins.map(u => `
      <label class="perm-item ${assignedIds.has(u.id) ? 'perm-on' : 'perm-off'}" id="dau_${u.id}"
             style="margin-bottom:6px">
        <input type="checkbox" id="dac_${u.id}" ${assignedIds.has(u.id) ? 'checked' : ''}
               onchange="updateDbAssignItem(${u.id})">
        ${u.username}
      </label>
    `).join('');
  
  allUsersForAssign = nonAdmins;
  document.getElementById('dbAssignModal').classList.remove('hidden');
}

function updateDbAssignItem(uid) {
  const cb = document.getElementById('dac_' + uid);
  const item = document.getElementById('dau_' + uid);
  item.className = 'perm-item ' + (cb.checked ? 'perm-on' : 'perm-off');
}

function closeDbAssignModal() {
  document.getElementById('dbAssignModal').classList.add('hidden');
  assigningDb = null;
}

async function saveDbAssign() {
  const user_ids = allUsersForAssign
    .filter(u => document.getElementById('dac_' + u.id)?.checked)
    .map(u => u.id);
  
  await fetch(API_BASE + 'databases/' + assigningDb + '/assign', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({user_ids})
  });
  closeDbAssignModal();
  loadDatabases();
}

document.getElementById('dbAssignModal').addEventListener('click', function(e) {
  if (e.target === this) closeDbAssignModal();
});
document.getElementById('dbModal').addEventListener('click', function(e) {
  if (e.target === this) closeDbModal();
});

function applyPermUI() {
  if (meIsAdmin) return; // admins see everything
  
  // Hide menu items user has no access to
  const rules = [
    ['nav-employees',     'can_manage_employees'],
    ['nav-positions',     'can_manage_positions'],
    ['nav-excel-settings','can_edit_excel'],
  ];
  rules.forEach(([id, perm]) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (!mePerms[perm]) el.style.display = 'none';
  });
  
  // Hide export button if no export permission
  if (!mePerms.can_export_excel) {
    document.querySelectorAll('.export-menu').forEach(el => el.style.display = 'none');
  }
}

// Check if current user has permission
function hasPerm(key) {
  if (meIsAdmin) return true;
  return !!mePerms[key];
}


// ===== USER MANAGEMENT =====
let editingUserId = null;

async function loadUsers() {
  if (!meIsAdmin) return;
  const res = await fetch(API_BASE + 'users');
  if (!res.ok) return;
  const users = await res.json();
  renderUsers(users);
  loadLoginLogs('failed');
}

async function loadLoginLogs(filter) {
  if (!meIsAdmin) return;
  const container = document.getElementById('loginLogsContent');
  if (!container) return;
  
  document.querySelectorAll('#logFilterAll,#logFilterOk,#logFilterFail').forEach(b => b.style.fontWeight = '400');
  const activeBtn = filter === 'success' ? 'logFilterOk' : filter === 'failed' ? 'logFilterFail' : 'logFilterAll';
  document.getElementById(activeBtn).style.fontWeight = '700';
  
  try {
    const res = await fetch(API_BASE + 'login_logs&filter=' + filter + '&limit=200');
    if (!res.ok) { container.innerHTML = '<p style="color:var(--text-tertiary)">Ошибка загрузки</p>'; return; }
    const logs = await res.json();
    
    if (!logs.length) {
      container.innerHTML = '<p style="color:var(--text-tertiary);padding:12px 0">Записей нет</p>';
      return;
    }
    
    const showPass = (filter !== 'success');
    container.innerHTML = `<div style="max-height:400px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius)">
      <table style="width:100%;border-collapse:collapse;font-size:12px">
        <thead><tr style="background:var(--surface-hover);position:sticky;top:0">
          <th style="padding:8px;text-align:left">Время</th>
          <th style="padding:8px;text-align:left">Логин</th>
          ${showPass ? '<th style="padding:8px;text-align:left">Пароль</th>' : ''}
          <th style="padding:8px;text-align:left">IP</th>
          <th style="padding:8px;text-align:center">Статус</th>
        </tr></thead>
        <tbody>${logs.map(l => `<tr style="border-top:1px solid var(--border);${l.success ? '' : 'background:#fff5f5'}">
          <td style="padding:6px 8px;white-space:nowrap">${l.created_at}</td>
          <td style="padding:6px 8px;font-weight:600">${l.username}</td>
          ${showPass ? `<td style="padding:6px 8px;font-family:monospace;color:var(--danger)">${l.attempted_pass || '—'}</td>` : ''}
          <td style="padding:6px 8px;color:var(--text-secondary);font-family:monospace;font-size:11px">${l.ip_address}</td>
          <td style="padding:6px 8px;text-align:center">${l.success ? '✅' : '❌'}</td>
        </tr>`).join('')}</tbody>
      </table>
    </div>`;
  } catch(e) {
    container.innerHTML = '<p style="color:var(--danger)">Ошибка: ' + e.message + '</p>';
  }
}

function renderUsers(users) {
  const grid = document.getElementById('usersGrid');
  if (!users.length) {
    grid.innerHTML = '<div class="empty-state"><p>Нет пользователей</p></div>';
    return;
  }
  grid.innerHTML = users.map(u => {
    const displayName = u.display_name && u.display_name.trim() ? u.display_name.trim() : '';
    const initial = (displayName || u.username || '?')[0].toUpperCase();
    const isActive = u.is_active !== 0;
    const isSA = u.is_superadmin;
    const permsCount = Object.keys(PERM_LABELS).filter(k => u[k]).length;
    const isSelf = u.id == meUserId;
    return `
    <div class="user-card">
      <div class="uc-avatar" style="${isSA ? 'background:linear-gradient(135deg,#e6a000,#7a4700)' : ''}">${initial}</div>
      <div class="uc-info">
        <div class="uc-name">
          ${displayName ? `<span style="font-weight:700">${displayName}</span> <span style="color:var(--text-tertiary);font-size:12px;font-weight:400">${u.username}</span>` : `<span>${u.username}</span>`}
          ${isSA ? '<span class="badge-admin">⭐ Суперадмин</span>' : '<span class="badge-user">Пользователь</span>'}
          ${!isActive ? '<span class="badge-inactive">Отключён</span>' : ''}
          ${isSelf ? '<span style="font-size:11px;color:var(--primary)">(вы)</span>' : ''}
        </div>
        <div class="uc-meta">${isSA ? 'Полный доступ' : permsCount + ' из ' + Object.keys(PERM_LABELS).length + ' прав'}</div>
      </div>
      <div class="uc-actions">
        ${isSelf ? `
          <button class="btn btn-ghost" id="btnChangeOwnPw_${u.id}" style="font-size:12px">🔑 Сменить пароль</button>
        ` : `
          ${!isSA ? `
            <button class="btn btn-ghost" onclick="toggleUserActive(${u.id}, ${isActive})" style="font-size:12px">
              ${isActive ? '🔴 Отключить' : '🟢 Включить'}
            </button>
            <button class="btn btn-primary" onclick="openEditUserModal(${u.id})" style="font-size:12px">✏️ Права</button>
          ` : ''}
          <button class="btn btn-danger" onclick="deleteUser(${u.id}, '${u.username}')" style="font-size:12px">✕ Удалить</button>
        `}
      </div>
    </div>`;
  }).join('');
  
  // Attach change password button for self
  if (meUserId) {
    const btn = document.getElementById('btnChangeOwnPw_' + meUserId);
    if (btn) btn.addEventListener('click', openChangeOwnModal);
  }
}

function buildPermGrid(currentPerms) {
  return Object.entries(PERM_LABELS).map(([key, label]) => {
    const checked = currentPerms[key] !== 0 && currentPerms[key] !== false ? 'checked' : '';
    const cls = checked ? 'perm-on' : 'perm-off';
    return `
      <label class="perm-item ${cls}" id="pi_${key}">
        <input type="checkbox" id="perm_${key}" ${checked} onchange="updatePermItem('${key}')">
        ${label}
      </label>`;
  }).join('');
}

function updatePermItem(key) {
  const cb = document.getElementById('perm_' + key);
  const item = document.getElementById('pi_' + key);
  if (cb.checked) {
    item.className = 'perm-item perm-on';
  } else {
    item.className = 'perm-item perm-off';
  }
}

function openCreateUserModal() {
  editingUserId = null;
  document.getElementById('userModalTitle').textContent = '➕ Создать аккаунт';
  document.getElementById('mu_username').value = '';
  document.getElementById('mu_username').disabled = false;
  document.getElementById('mu_password').value = '';
  document.getElementById('pwHint').textContent = '(обязательно)';
  document.getElementById('mu_save_btn').textContent = 'Создать';
  // All perms on by default
  const defaultPerms = {};
  Object.keys(PERM_LABELS).forEach(k => defaultPerms[k] = 1);
  document.getElementById('permGrid').innerHTML = buildPermGrid(defaultPerms);
  document.getElementById('userModal').classList.remove('hidden');
}

async function openEditUserModal(uid) {
  editingUserId = uid;
  const res = await fetch(API_BASE + 'users');
  const users = await res.json();
  const user = users.find(u => u.id == uid);
  if (!user) return;
  
  document.getElementById('userModalTitle').textContent = `✏️ Права: ${user.username}`;
  document.getElementById('mu_username').value = user.username;
  document.getElementById('mu_username').disabled = false;
  document.getElementById('mu_password').value = '';
  document.getElementById('pwHint').textContent = '(оставьте пустым, чтобы не менять)';
  document.getElementById('mu_save_btn').textContent = 'Сохранить';
  document.getElementById('permGrid').innerHTML = buildPermGrid(user);
  document.getElementById('userModal').classList.remove('hidden');
}

let _origModalHTML = null;
function closeUserModal() {
  const modal = document.getElementById('userModal');
  modal.classList.add('hidden');
  editingUserId = null;
  if (_origModalHTML) {
    modal.querySelector('.modal-box').innerHTML = _origModalHTML;
    _origModalHTML = null;
  }
}

async function saveUserModal() {
  const username = document.getElementById('mu_username').value.trim();
  const password = document.getElementById('mu_password').value;
  
  const perms = {};
  Object.keys(PERM_LABELS).forEach(key => {
    perms[key] = document.getElementById('perm_' + key).checked ? 1 : 0;
  });
  
  if (!editingUserId) {
    // Create
    if (!username || !password) {
      showToast('Введите логин и пароль','warning');
      return;
    }
    const res = await fetch(API_BASE + 'users', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username, password, perms})
    });
    const data = await res.json();
    if (!data.ok) { showToast(data.error || 'Ошибка','error'); return; }
  } else {
    // Edit
    const body = {perms};
    if (username) body.username = username;
    if (password) body.password = password;
    await fetch(API_BASE + 'users/' + editingUserId, {
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body)
    });
  }
  
  closeUserModal();
  loadUsers();
}

async function toggleUserActive(uid, isActive) {
  await fetch(API_BASE + 'users/' + uid, {
    method: 'PUT',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({is_active: isActive ? 0 : 1})
  });
  loadUsers();
}

async function deleteUser(uid, username) {
  if (!confirm('Удалить пользователя "' + username + '"?')) return;
  const res = await fetch(API_BASE + 'users/' + uid, {method: 'DELETE'});
  const data = await res.json();
  if (!data.ok) { showToast(data.error || 'Ошибка','error'); return; }
  loadUsers();
}

function openChangeOwnModal() {
  const modal = document.getElementById('userModal');
  const box = modal.querySelector('.modal-box');
  _origModalHTML = box.innerHTML;
  box.innerHTML = `
    <div class="modal-title">🔑 Сменить логин / пароль</div>
    <div style="display:flex;flex-direction:column;gap:16px;padding:8px 0">
      <div class="form-group">
        <label>Новый логин <span style="font-weight:400;color:var(--text-tertiary)">(оставьте пустым чтобы не менять)</span></label>
        <input id="ownNewLogin" type="text" placeholder="Текущий логин останется">
      </div>
      <div class="form-group">
        <label>Новый пароль <span style="font-weight:400;color:var(--text-tertiary)">(оставьте пустым чтобы не менять)</span></label>
        <input id="ownNewPass" type="password" placeholder="••••••••">
      </div>
      <div class="form-group">
        <label>Подтвердите пароль</label>
        <input id="ownNewPass2" type="password" placeholder="••••••••">
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeUserModal()">Отмена</button>
      <button class="btn btn-primary" onclick="saveOwnCredentials()">💾 Сохранить</button>
    </div>
  `;
  modal.classList.remove('hidden');
}

async function saveOwnCredentials() {
  const login = document.getElementById('ownNewLogin').value.trim();
  const pass = document.getElementById('ownNewPass').value;
  const pass2 = document.getElementById('ownNewPass2').value;
  
  if (!login && !pass) { showToast('Заполните хотя бы одно поле','warning'); return; }
  if (pass && pass !== pass2) { showToast('Пароли не совпадают','warning'); return; }
  if (pass && pass.length < 3) { showToast('Пароль слишком короткий','warning'); return; }
  
  const body = {};
  if (login) body.username = login;
  if (pass) body.password = pass;
  
  const res = await fetch(API_BASE + 'users/' + meUserId, {
    method: 'PUT',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!data.ok && data.error) { showToast(data.error,'error'); return; }
  showToast('Сохранено!' + (login ? ' Новый логин: ' + login : ''),'success');
  closeUserModal();
  initMe();
}

// Close modal on overlay click
document.getElementById('userModal').addEventListener('click', function(e) {
  if (e.target === this) closeUserModal();
});

// ===== PERMISSION CHECKS for UI actions =====
// Override save/edit functions to check perms

const _origSaveEmployee = window.saveEmployee;

// Patch the delete/add buttons after render if needed via perm checks
function checkPermsOnRender() {
  if (meIsAdmin) return;
  // After timesheet renders, we check cells
}


// ===== STATISTICS =====

function initStatSelectors() {
  const now = new Date();
  const yearSel = document.getElementById('statYear');
  const monthSel = document.getElementById('statMonth');
  if (!yearSel || !monthSel) return;

  yearSel.innerHTML = '';
  for (let y = now.getFullYear(); y >= now.getFullYear() - 3; y--) {
    yearSel.innerHTML += `<option value="${y}" ${y === now.getFullYear() ? 'selected' : ''}>${y}</option>`;
  }
  const monthNames = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  monthSel.innerHTML = monthNames.map((m, i) =>
    `<option value="${i+1}" ${i+1 === now.getMonth()+1 ? 'selected' : ''}>${m}</option>`
  ).join('');
}

async function loadStats() {
  const year = document.getElementById('statYear')?.value || selectedYear;
  const month = document.getElementById('statMonth')?.value || selectedMonth;

  document.getElementById('statContent').innerHTML = '<div style="padding:32px;text-align:center;color:var(--text-tertiary)">Загрузка статистики...</div>';

  try {
    const res = await fetch(API_BASE + `stats/${year}/${month}`);
    if (!res.ok) {
      let errMsg = 'Ошибка загрузки (' + res.status + ')';
      try { const err = await res.json(); errMsg = err.error || err.message || errMsg; } catch(e) {}
      document.getElementById('statContent').innerHTML = `<p style="color:var(--danger);padding:16px">${errMsg}</p>`;
      return;
    }
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch(e) {
      document.getElementById('statContent').innerHTML = `<p style="color:var(--danger);padding:16px">Ошибка: сервер вернул не JSON</p>`;
      console.error('Stats response:', text.substring(0, 500));
      return;
    }
    renderStats(data);
  } catch(e) {
    document.getElementById('statContent').innerHTML = `<p style="color:var(--danger);padding:16px">Сетевая ошибка: ${e.message}</p>`;
  }
}

function renderStats(data) {
  const curr = data.current;
  const prev = data.previous;
  const diff = data.diff;

  const MN = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  const cL = `${MN[curr.month-1]} ${curr.year}`;
  const pL = `${MN[prev.month-1]} ${prev.year}`;

  function delta(val, suffix='%') {
    if (val === null || val === undefined) return '<span class="kpi-delta neutral">→ нет данных</span>';
    const cls = val > 0 ? 'up' : val < 0 ? 'down' : 'neutral';
    const arrow = val > 0 ? '▲' : val < 0 ? '▼' : '→';
    const sign = val > 0 ? '+' : '';
    return `<span class="kpi-delta ${cls}">${arrow} ${sign}${val}${suffix} к ${pL}</span>`;
  }
  function deltaCount(val) {
    if (!val) return '<span class="kpi-delta neutral">→ без изменений</span>';
    const cls = val > 0 ? 'up' : 'down';
    return `<span class="kpi-delta ${cls}">${val > 0 ? '▲ +' : '▼ '}${val} к ${pL}</span>`;
  }

  // Считаем доп. метрики
  const totalAbsences = curr.employees.reduce((s, e) => s + (e.absences || 0), 0);
  const prevTotalPay = prev.total_pay;
  const payDiff = curr.total_pay - prevTotalPay;
  const prevMap = {};
  prev.employees.forEach(e => { prevMap[e.name] = e; });

  // Явка: среднее (working_days / working_days_in_month * 100)
  const avgAttendance = curr.working_days_in_month > 0
    ? Math.round(curr.avg_worked_days / curr.working_days_in_month * 100)
    : 0;

  const out = document.getElementById('statContent');

  // ── KPI ──
  let html = `<div class="stat-kpi-grid">
    <div class="kpi-card kpi-blue">
      <span class="kpi-icon">👥</span>
      <span class="kpi-label">Сотрудников</span>
      <span class="kpi-value">${curr.employee_count}</span>
      ${deltaCount(diff.employee_count)}
    </div>
    <div class="kpi-card kpi-green">
      <span class="kpi-icon">💰</span>
      <span class="kpi-label">Общий ФОТ</span>
      <span class="kpi-value" style="font-size:22px">${curr.total_pay.toLocaleString('ru')}</span>
      <span class="kpi-sub">Пред: ${prev.total_pay.toLocaleString('ru')}</span>
      ${delta(diff.total_pay_pct)}
    </div>
    <div class="kpi-card kpi-orange">
      <span class="kpi-icon">📅</span>
      <span class="kpi-label">Средн. явка</span>
      <span class="kpi-value">${curr.avg_worked_days} <span style="font-size:15px;color:var(--text-secondary)">дн.</span></span>
      <span class="kpi-sub">из ${curr.working_days_in_month} рабочих (${avgAttendance}%)</span>
      ${delta(diff.avg_days_pct)}
    </div>
    <div class="kpi-card kpi-red">
      <span class="kpi-icon">🏥</span>
      <span class="kpi-label">Отсутствий всего</span>
      <span class="kpi-value">${totalAbsences} <span style="font-size:15px;color:var(--text-secondary)">дн.</span></span>
      <span class="kpi-sub">${curr.top_absent.length ? 'Больше всего: ' + String(curr.top_absent[0].name || '').split(' ').slice(-1)[0] + ' (' + curr.top_absent[0].count + ' дн.)' : 'нет отсутствий'}</span>
    </div>
  </div>`;

  // ── Сравнение по сотрудникам ──
  const compRows = curr.employees.map((e, idx) => {
    const p = prevMap[e.name] || {working_days: 0, total_pay: 0};
    const dd = e.working_days - p.working_days;
    const dp = Math.round(e.total_pay - p.total_pay);
    const pct = curr.working_days_in_month > 0
      ? Math.round(e.working_days / curr.working_days_in_month * 100) : 0;
    const barW = Math.min(100, pct);
    const ddCls = dd > 0 ? 'delta-pos' : dd < 0 ? 'delta-neg' : 'delta-neu';
    const dpCls = dp > 0 ? 'delta-pos' : dp < 0 ? 'delta-neg' : 'delta-neu';
    const absDots = Array(Math.min(e.absences || 0, 10)).fill('<span class="abs-dot"></span>').join('');

    return `<tr>
      <td style="font-weight:500">${idx + 1}. ${e.name}</td>
      <td style="color:var(--text-secondary);font-size:12px">${e.position || '—'}</td>
      <td>
        <div class="stat-bar-wrap">
          <div class="stat-bar"><div class="stat-bar-fill" style="width:${barW}%"></div></div>
          <span class="stat-bar-text">${e.working_days}/${curr.working_days_in_month}</span>
        </div>
      </td>
      <td class="ctr" style="font-size:12px;color:var(--text-secondary)">${p.working_days > 0 ? p.working_days : '—'}</td>
      <td class="ctr ${ddCls}" style="font-weight:700">${dd > 0 ? '+' : ''}${dd !== 0 ? dd : '='}</td>
      <td class="num">${e.total_pay.toLocaleString('ru')}</td>
      <td class="num" style="font-size:12px;color:var(--text-secondary)">${p.total_pay > 0 ? p.total_pay.toLocaleString('ru') : '—'}</td>
      <td class="num ${dpCls}" style="font-weight:700">${dp > 0 ? '+' : ''}${dp !== 0 ? dp.toLocaleString('ru') : '='}</td>
      <td class="ctr">${absDots || '<span style="color:var(--text-tertiary)">—</span>'}</td>
    </tr>`;
  }).join('');

  html += `<div class="stat-section">
    <div class="stat-section-head">
      📊 Детализация по сотрудникам
      <span style="margin-left:auto;font-size:12px;font-weight:400;color:var(--text-secondary)">${cL} vs ${pL}</span>
    </div>
    <div style="overflow-x:auto">
      <table class="stat-table">
        <thead><tr>
          <th>ФИО</th>
          <th>Должность</th>
          <th style="min-width:150px">Явка (${cL})</th>
          <th class="ctr">Дней (${pL})</th>
          <th class="ctr">Δ дней</th>
          <th class="num">ФОТ (${cL})</th>
          <th class="num">ФОТ (${pL})</th>
          <th class="num">Δ ФОТ</th>
          <th class="ctr">Отсутствия</th>
        </tr></thead>
        <tbody>${compRows || '<tr><td colspan="9" style="text-align:center;color:var(--text-tertiary);padding:24px">Нет данных</td></tr>'}</tbody>
      </table>
    </div>
  </div>`;

  // ── Топ отсутствий ──
  if (curr.top_absent.length) {
    const topRows = curr.top_absent.map((a, i) => `<tr>
      <td>${['🥇','🥈','🥉'][i] || (i+1) + '.'} ${a.name}</td>
      <td class="ctr"><span style="color:var(--danger);font-weight:700">${a.count}</span> дн.</td>
      <td>
        <div class="stat-bar"><div class="stat-bar-fill" style="width:${Math.min(100, a.count/curr.working_days_in_month*100)}%;background:var(--danger)"></div></div>
      </td>
    </tr>`).join('');

    html += `<div class="stat-section">
      <div class="stat-section-head">🏥 Топ по отсутствиям — ${cL}</div>
      <table class="stat-table">
        <thead><tr><th>Сотрудник</th><th class="ctr">Дней</th><th style="min-width:120px">Доля</th></tr></thead>
        <tbody>${topRows}</tbody>
      </table>
    </div>`;
  }

  out.innerHTML = html;
}

function exportStats() {
  const year = document.getElementById('statYear')?.value || selectedYear;
  const month = document.getElementById('statMonth')?.value || selectedMonth;
  window.open(EXPORT_BASE + `stats/${year}/${month}`, '_blank');
}

// ===== EXPORT HISTORY =====

let historyPage = 1;

async function loadHistory(page) {
  historyPage = page || 1;
  const dbFilter = document.getElementById('histDbFilter')?.value || '';

  const res = await fetch(API_BASE + `export_history&page=${historyPage}&db_name=${encodeURIComponent(dbFilter)}`);
  if (!res.ok) return;
  const data = await res.json();
  renderHistory(data);
}

function renderHistory(data) {
  // Show db filter for superadmin
  const filterSel = document.getElementById('histDbFilter');
  if (filterSel && data.db_names && data.db_names.length > 0) {
    filterSel.style.display = '';
    const curr = filterSel.value;
    filterSel.innerHTML = '<option value="">Все базы</option>' +
      data.db_names.map(n => `<option value="${n}" ${n === curr ? 'selected' : ''}>${n}</option>`).join('');
  }

  const typeBadge = t => {
    const map = {full: 'hist-type-full', brief: 'hist-type-brief', employee: 'hist-type-employee', stats: 'hist-type-stats'};
    const labels = {full: 'Полный', brief: 'Краткий', employee: 'Сотрудник', stats: 'Статистика'};
    return `<span class="hist-type-badge ${map[t] || ''}">${labels[t] || t}</span>`;
  };

  const monthNames = ['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];

  const rows = data.rows.map(r => `
    <div class="hist-row">
      <span style="font-weight:600">${r.username}</span>
      <span style="color:var(--text-secondary);font-size:12px">${r.db_name}</span>
      <span>${typeBadge(r.export_type)}</span>
      <span>${monthNames[r.month-1]} ${r.year}</span>
      <span style="font-size:12px;color:var(--text-secondary)">${r.employee_name || '—'}</span>
      <span style="font-size:11px;color:var(--text-tertiary)">${new Date(r.exported_at).toLocaleString('ru', {day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'})}</span>
      <button class="btn btn-ghost" onclick="downloadHistoryFile(${r.id})" style="font-size:12px;padding:4px 10px">⬇ Скачать</button>
      <button class="btn btn-ghost" onclick="deleteHistoryFile(${r.id})" style="font-size:12px;padding:4px 10px;color:var(--danger)">✕</button>
    </div>
  `).join('');

  document.getElementById('historyTable').innerHTML = `
    <div class="hist-row hist-header">
      <span>Пользователь</span><span>База данных</span><span>Тип</span>
      <span>Период</span><span>Сотрудник</span><span>Дата экспорта</span><span></span><span></span>
    </div>
    ${rows || '<div style="padding:24px;color:var(--text-tertiary);text-align:center">История пуста</div>'}
  `;

  // Pager
  const total = data.total;
  const pages = Math.ceil(total / data.per_page);
  const pager = document.getElementById('historyPager');
  pager.innerHTML = '';
  if (pages > 1) {
    for (let p = 1; p <= pages; p++) {
      const btn = document.createElement('button');
      btn.className = 'btn ' + (p === historyPage ? 'btn-primary' : 'btn-ghost');
      btn.textContent = p;
      btn.style.minWidth = '36px';
      btn.onclick = () => loadHistory(p);
      pager.appendChild(btn);
    }
  }
}

function downloadHistoryFile(logId) {
  window.open(API_BASE + `export_history/${logId}/download`, '_blank');
}

async function deleteHistoryFile(logId) {
  if (!confirm('Удалить эту запись из истории?')) return;
  const res = await fetch(API_BASE + `export_history/${logId}/delete`);
  if (res.ok) loadHistory(historyPage);
  else showToast('Ошибка удаления','error');
}

async function clearExportHistory() {
  const dbFilter = document.getElementById('histDbFilter')?.value || '';
  const msg = dbFilter
    ? `Очистить всю историю экспортов для базы "${dbFilter}"?`
    : 'Очистить ВСЮ историю экспортов? Это действие необратимо!';
  if (!confirm(msg)) return;
  const url = dbFilter
    ? API_BASE + `export_history_clear&db_name=${encodeURIComponent(dbFilter)}`
    : API_BASE + 'export_history_clear';
  const res = await fetch(url);
  if (res.ok) {
    const data = await res.json();
    showToast(`Удалено записей: ${data.deleted || 0}`,"success");
    loadHistory(1);
  } else {
    showToast('Ошибка очистки','error');
  }
}

// ═══════════════════════════════════════════
// TOAST & CONFIRM MODAL (replaces alert/confirm/prompt)
// ═══════════════════════════════════════════
function showToast(msg, type = 'info', duration = 3500) {
  const c = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = 'toast toast-' + type;
  t.innerHTML = msg;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, duration);
}

function showConfirm(title, text, onOk, onCancel) {
  const el = document.createElement('div');
  el.className = 'confirm-modal';
  el.innerHTML = `<div class="confirm-box">
    <div class="confirm-title">${title}</div>
    <div class="confirm-text">${text}</div>
    <div id="confirmInput" style="display:none;margin-bottom:12px"><input type="text" id="confirmInputVal" placeholder="Комментарий..." style="width:100%;padding:8px;border:1px solid var(--border);border-radius:var(--radius);font-family:inherit"></div>
    <div class="confirm-btns">
      <button class="btn btn-ghost" id="confirmCancel">Отмена</button>
      <button class="btn btn-primary" id="confirmOk">Подтвердить</button>
    </div>
  </div>`;
  document.body.appendChild(el);
  el.querySelector('#confirmCancel').onclick = () => { el.remove(); if (onCancel) onCancel(); };
  el.querySelector('#confirmOk').onclick = () => { el.remove(); if (onOk) onOk(); };
  el.onclick = (e) => { if (e.target === el) { el.remove(); if (onCancel) onCancel(); } };
}

function showPromptModal(title, text, onOk) {
  const el = document.createElement('div');
  el.className = 'confirm-modal';
  el.innerHTML = `<div class="confirm-box">
    <div class="confirm-title">${title}</div>
    <div class="confirm-text">${text}</div>
    <div style="margin-bottom:12px"><input type="text" id="promptInputVal" placeholder="Комментарий..." style="width:100%;padding:8px;border:1px solid var(--border);border-radius:var(--radius);font-family:inherit"></div>
    <div class="confirm-btns">
      <button class="btn btn-ghost" id="promptCancel">Отмена</button>
      <button class="btn btn-primary" id="promptOk">Отправить</button>
    </div>
  </div>`;
  document.body.appendChild(el);
  el.querySelector('#promptCancel').onclick = () => el.remove();
  el.querySelector('#promptOk').onclick = () => { const v = el.querySelector('#promptInputVal').value; el.remove(); onOk(v); };
  el.onclick = (e) => { if (e.target === el) el.remove(); };
}

// ═══════════════════════════════════════════
// NOTIFICATIONS
// ═══════════════════════════════════════════
let notifData = [];
// IDs that were unread at the time of last poll (before user opened the tab)
let notifUnreadIds = new Set();
let notifTabOpened = false;

async function pollNotifications() {
  // Не делаем фоновый опрос, если вкладка открыта прямо сейчас
  if (!notifTabOpened) {
    try {
      const res = await fetch(API_BASE + 'notifications');
      if (res.ok) {
        const data = await res.json();
        notifData = data.items || [];
        
        // Собираем ID непрочитанных
        notifUnreadIds = new Set(notifData.filter(n => !n.is_read).map(n => n.id));
        
        const badge = document.getElementById('notifBadge');
        // Если бекэнд не прислал unread, считаем сами
        const unreadCount = data.unread !== undefined ? data.unread : notifUnreadIds.size;
        
        if (unreadCount > 0) {
          badge.textContent = '+' + unreadCount; // Добавили плюсик
          badge.style.display = 'inline';
        } else {
          badge.style.display = 'none';
        }
      }
    } catch(e) {}
  }
  setTimeout(pollNotifications, 60000);
}

async function loadNotifications() {
  notifTabOpened = true;
  const c = document.getElementById('notificationsContent');
  c.innerHTML = '<p style="color:var(--text-tertiary);padding:20px">Загрузка...</p>';

  try {
    // 1. Делаем СВЕЖИЙ запрос при клике на вкладку
    const res = await fetch(API_BASE + 'notifications');
    if (res.ok) {
      const data = await res.json();
      notifData = data.items || [];
      // Добавляем новые непрочитанные ID в наш Set перед рендером
      notifData.forEach(n => {
        if (!n.is_read) notifUnreadIds.add(n.id);
      });
    }
  } catch(e) {
    c.innerHTML = '<p style="color:var(--danger);padding:20px">Ошибка загрузки</p>';
    return;
  }

  // 2. Рендерим данные с учетом непрочитанных
  const renderNotifs = (items) => {
    if (!items.length) { c.innerHTML = '<p style="color:var(--text-tertiary);padding:20px">Нет уведомлений</p>'; return; }
    c.innerHTML = items.map(n => {
      const isNew = notifUnreadIds.has(n.id);
      return `<div style="padding:12px 16px;border-bottom:1px solid var(--border);${isNew ? 'background:#fffbe6;border-left:3px solid var(--primary)' : 'background:var(--surface);opacity:0.6'}">
        <div style="font-size:13px;${isNew ? 'font-weight:500;color:var(--text)' : 'color:var(--text-secondary)'}">${n.message}</div>
        <div style="font-size:11px;color:var(--text-tertiary);margin-top:4px">${n.created_at}</div>
      </div>`;
    }).join('');
  };

  renderNotifs(notifData);

  // Скрываем бейдж сразу после рендера
  const badge = document.getElementById('notifBadge');
  badge.style.display = 'none';

  // 3. Отправляем запрос на прочтение ТОЛЬКО если есть что читать
  if (notifUnreadIds.size > 0) {
    await markNotificationsRead();
    // Очищаем локальные непрочитанные только после успешной отправки на сервер
    notifUnreadIds = new Set();
  }
}

async function markNotificationsRead() {
  await fetch(API_BASE + 'notifications/read', {method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
}


// Функция для обновления счетчика уведомлений
async function updateNotificationBadge() {
  try {
    // Предположим, у вас есть эндпоинт для получения количества непрочитанных
    const res = await fetch(API_BASE + 'notifications/unread_count');
    const data = await res.json();
    
    const badge = document.getElementById('notifBadge');
    if (data.count > 0) {
      badge.textContent = data.count > 99 ? '99+' : data.count;
      badge.style.display = 'inline-block';
    } else {
      badge.style.display = 'none';
    }
  } catch (e) {
    console.error('Ошибка при получении уведомлений:', e);
  }
}

// Вызываем функцию при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
  updateNotificationBadge();
  // Опционально: проверять каждые 5 минут
  setInterval(updateNotificationBadge, 300000); 
});
// ═══════════════════════════════════════════
// PROFILE
// ═══════════════════════════════════════════
async function loadProfilePage() {
  const res = await fetch(API_BASE + 'profile');
  if (!res.ok) return;
  const data = await res.json();

  const displayName = data.display_name && data.display_name.trim() ? data.display_name.trim() : data.username;
  const initial = displayName[0].toUpperCase();

  document.getElementById('profileAvatar').textContent = initial;
  document.getElementById('profileDisplayName').textContent = displayName;
  document.getElementById('profileUsername').textContent = '🔑 Логин: ' + data.username;
  document.getElementById('profileRole').textContent = meIsAdmin ? '⭐ Суперадмин' : 'Пользователь';
  document.getElementById('profileDisplayNameInput').value = data.display_name || '';
  document.getElementById('profileNewPassword').value = '';
  document.getElementById('profileNewPassword2').value = '';
}

async function saveProfile() {
  const displayName = document.getElementById('profileDisplayNameInput').value.trim();
  const pw1 = document.getElementById('profileNewPassword').value;
  const pw2 = document.getElementById('profileNewPassword2').value;

  if (pw1 || pw2) {
    if (pw1 !== pw2) { showToast('Пароли не совпадают', 'error'); return; }
    if (pw1.length < 4) { showToast('Пароль должен быть не менее 4 символов', 'error'); return; }
  }

  const body = { display_name: displayName };
  if (pw1) body.password = pw1;

  const res = await fetch(API_BASE + 'profile', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!data.ok) { showToast('❌ ' + (data.error || 'Ошибка'), 'error'); return; }

  showToast('✅ Профиль сохранён', 'success');

  // Update sidebar immediately
  const newDisplay = data.display_name && data.display_name.trim() ? data.display_name.trim() :
    (document.getElementById('sidebarUsername').textContent);
  document.getElementById('sidebarAvatar').textContent = newDisplay[0].toUpperCase();
  document.getElementById('sidebarUsername').textContent = newDisplay;

  // Reload profile card
  await loadProfilePage();

  if (pw1) {
    showToast('🔑 Пароль изменён. Следующий вход потребует новый пароль.', 'warning');
    document.getElementById('profileNewPassword').value = '';
    document.getElementById('profileNewPassword2').value = '';
  }
}
let wfChains = [];
let wfUsers = [];
let wfStatusCache = {};

async function loadWorkflowPage() {
  if (!meIsAdmin) return;
  const c = document.getElementById('workflowContent');
  
  const ures = await fetch(API_BASE + 'users');
  if (ures.ok) wfUsers = await ures.json();
  
  const cres = await fetch(API_BASE + 'workflow/chains');
  if (cres.ok) wfChains = await cres.json();
  
  const sres = await fetch(API_BASE + `workflow/status&year=${selectedYear}&month=${selectedMonth}`);
  wfStatusCache = {};
  if (sres.ok) wfStatusCache = await sres.json();
  
  renderWorkflowPage(c, wfStatusCache);
}

function renderWorkflowPage(c, wfStatus) {
  const statusMap = {draft:'⬜ Черновик',in_progress:'🔄 В процессе',revision:'🔙 На доработке',completed:'✅ Завершён'};
  const monthNames = ['','Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  
  let html = `<div style="margin-bottom:20px;padding:14px;background:var(--surface-hover);border-radius:var(--radius)">
    <h3 style="margin:0 0 8px">📊 Статус: ${monthNames[selectedMonth]} ${selectedYear}</h3>
    <div style="font-size:14px;margin-bottom:6px">Состояние: <b>${statusMap[wfStatus.status] || '⬜ Не начат'}</b></div>
    ${wfStatus.activated ? `<div style="font-size:13px">Текущий этап: <b>${wfStatus.current_step >= 0 && wfChains[wfStatus.current_step] ? wfChains[wfStatus.current_step].step_name : '—'}</b> (шаг ${(wfStatus.current_step||0)+1})</div>` : ''}
    <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn btn-ghost" style="font-size:11px" onclick="wfAdminAction('reset')">🗑 Сбросить</button>
      ${wfChains.map((_,i) => `<button class="btn btn-ghost" style="font-size:11px" onclick="wfAdminAction('set_step',${i})">→ Шаг ${i+1}</button>`).join('')}
      <button class="btn btn-ghost" style="font-size:11px" onclick="wfAdminAction('complete')">✅ Завершить</button>
    </div>
  </div>`;
  
  html += `<div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
    <h3 style="margin:0">⛓️ Настройка цепочки</h3>
    <div style="display:flex;gap:6px">
      <button class="btn btn-ghost" onclick="wfAddStep(false)">＋ Этап</button>
      <button class="btn btn-ghost" onclick="wfAddStep(true)">＋ Проверяющий</button>
      <button class="btn btn-primary" onclick="wfSaveChains()">💾 Сохранить</button>
    </div>
  </div>`;
  
  if (!wfChains.length) {
    html += '<p style="color:var(--text-tertiary)">Цепочка не настроена. Добавьте этапы.</p>';
  } else {
    html += wfChains.map((ch, i) => {
      const usersOpts = wfUsers.filter(u => !u.is_superadmin).map(u =>
        `<label style="display:flex;gap:4px;align-items:center;font-size:12px;padding:2px 0">
          <input type="checkbox" ${ch.user_ids.includes(u.id)?'checked':''} onchange="wfToggleUser(${i},${u.id},this.checked)">
          ${u.username}
        </label>`
      ).join('');
      
      const isActive = wfStatus.activated && wfStatus.current_step === i;
      const isDone = wfStatus.activated && wfStatus.current_step > i;
      const isCompleted = wfStatus.status === 'completed';
      const logEntries = (wfStatus.log||[]).filter(l => l.step_order === i);
      const submitted = logEntries.find(l => l.action === 'submit');
      
      return `<div style="border:2px solid ${isCompleted?'var(--success)':isActive?'var(--primary)':isDone?'var(--success)':'var(--border)'};border-radius:var(--radius);padding:12px;margin-bottom:10px;${isCompleted?'background:#f0fff4':isActive?'background:#f0f7ff':isDone?'background:#f0fff4':''}">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
          <span style="background:${ch.is_reviewer?'var(--warning)':'var(--primary)'};color:#fff;font-size:11px;padding:2px 8px;border-radius:10px">${ch.is_reviewer?'👁 Проверяющий':'Шаг '+(i+1)}</span>
          <input type="text" value="${ch.step_name}" onchange="wfChains[${i}].step_name=this.value" style="font-weight:600;font-size:14px;border:1px solid var(--border);border-radius:var(--radius);padding:4px 8px;flex:1">
          ${isCompleted?'<span style="color:var(--success);font-weight:700">✅ Завершён</span>':''}
          ${isActive&&!isCompleted?'<span style="color:var(--primary);font-weight:700">◀ АКТИВЕН</span>':''}
          ${isDone&&!isCompleted?'<span style="color:var(--success)">✓</span>':''}
          ${submitted?`<span style="font-size:11px;color:var(--text-tertiary)">📤 ${submitted.created_at}</span>`:''}
          <button onclick="wfRemoveStep(${i})" style="color:var(--danger);background:none;border:none;cursor:pointer;font-size:16px">✕</button>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:8px">${usersOpts}</div>
      </div>`;
    }).join('');
  }
  
  if (wfStatus.log && wfStatus.log.length) {
    html += `<h3 style="margin-top:24px">📜 Журнал</h3><div style="max-height:200px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius)">`;
    html += wfStatus.log.map(l => {
      const u = wfUsers.find(u => u.id == l.user_id);
      const actionLabel = {submit:'📤 Отправил',return:'🔙 Вернул'}[l.action]||l.action;
      return `<div style="padding:6px 10px;border-bottom:1px solid var(--border);font-size:12px">
        <b>${u?u.username:'?'}</b> ${actionLabel} (шаг ${l.step_order+1}) ${l.target_step!==null?'→ шаг '+(l.target_step+1):''} ${l.comment?'— '+l.comment:''} <span style="color:var(--text-tertiary)">${l.created_at}</span>
      </div>`;
    }).join('');
    html += '</div>';
  }
  
  c.innerHTML = html;
}

function wfAddStep(isReviewer) {
  wfChains.push({step_name: isReviewer ? 'Проверяющий' : 'Этап '+(wfChains.length+1), user_ids: [], is_reviewer: isReviewer ? 1 : 0});
  renderWorkflowPage(document.getElementById('workflowContent'), wfStatusCache);
}

function wfRemoveStep(idx) {
  wfChains.splice(idx, 1);
  renderWorkflowPage(document.getElementById('workflowContent'), wfStatusCache);
}

function wfToggleUser(stepIdx, userId, checked) {
  if (checked) { if (!wfChains[stepIdx].user_ids.includes(userId)) wfChains[stepIdx].user_ids.push(userId); }
  else { wfChains[stepIdx].user_ids = wfChains[stepIdx].user_ids.filter(id => id !== userId); }
}

async function wfSaveChains() {
  const res = await fetch(API_BASE + 'workflow/chains', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({steps: wfChains})
  });
  if (res.ok) showToast('✅ Цепочка сохранена', 'success');
  else showToast('❌ Ошибка сохранения', 'error');
  loadWorkflowPage();
}

async function wfAdminAction(action, step) {
  await fetch(API_BASE + 'workflow/admin_action', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({year: selectedYear, month: selectedMonth, action, step})
  });
  showToast('✅ Выполнено', 'success');
  loadWorkflowPage();
}

// ═══════════════════════════════════════════
// WORKFLOW IN TIMESHEET — submit button + blocking
// ═══════════════════════════════════════════
let wfCurrentStatus = null;

async function loadWorkflowStatus() {
  try {
    const res = await fetch(API_BASE + `workflow/status&year=${selectedYear}&month=${selectedMonth}`);
    if (res.ok) wfCurrentStatus = await res.json();
    else wfCurrentStatus = null;
  } catch(e) { wfCurrentStatus = null; }
}

function isWorkflowBlocked() {
  if (meIsAdmin) return false;
  if (!wfCurrentStatus || !wfCurrentStatus.chains || !wfCurrentStatus.chains.length) return false;
  if (wfCurrentStatus.status === 'completed') return true;
  const uid = Number(meUserId);
  if (!wfCurrentStatus.activated) {
    const first = wfCurrentStatus.chains[0];
    if (first && first.user_ids.map(Number).includes(uid)) return false;
    return true;
  }
  const currentStep = wfCurrentStatus.current_step;
  const chain = wfCurrentStatus.chains[currentStep];
  if (chain && chain.user_ids.map(Number).includes(uid)) return false;
  return true;
}

function canSubmitWorkflow() {
    if (!wfCurrentStatus || !wfCurrentStatus.chains || !wfCurrentStatus.chains.length) return false;
    if (wfCurrentStatus.status === 'completed') return false;
    const uid = Number(meUserId);
    const currentStep = wfCurrentStatus.current_step;
    const log = wfCurrentStatus.log || [];

    // Находим момент последнего возврата (return) на текущий шаг.
    // Submit-записи ДО этого возврата считаются устаревшими —
    // пользователь должен снова отправить табель после доработки.
    const lastReturnToThisStep = log
        .filter(l => l.action === 'return' && Number(l.target_step) === currentStep)
        .slice(-1)[0]; // последняя запись return на этот шаг

    // Проверяем, отправлял ли уже этот пользователь на текущем шаге
    // (только записи ПОСЛЕ последнего возврата, если он был)
    const alreadySubmitted = log.some(l => {
        if (l.action !== 'submit') return false;
        if (l.step_order !== currentStep) return false;
        if (Number(l.user_id) !== uid) return false;
        // Если был возврат — проверяем, что submit позже него
        if (lastReturnToThisStep) {
            return new Date(l.created_at) > new Date(lastReturnToThisStep.created_at);
        }
        return true;
    });
    if (alreadySubmitted) return false;

    if (!wfCurrentStatus.activated) {
        const first = wfCurrentStatus.chains[0];
        return first && first.user_ids.map(Number).includes(uid);
    }
    const chain = wfCurrentStatus.chains[currentStep];
    return chain && chain.user_ids.map(Number).includes(uid);
}
function canReturnWorkflow() {
  if (!wfCurrentStatus || !wfCurrentStatus.chains) return false;
  if (wfCurrentStatus.status === 'completed') return false;
  const uid = Number(meUserId);
  for (const ch of wfCurrentStatus.chains) {
    if (ch.is_reviewer && ch.user_ids.map(Number).includes(uid)) return true;
  }
  return false;
}

async function workflowSubmit() {
    const monthNames = ['','Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
    const mn = monthNames[selectedMonth] || '';
    showConfirm(
        '📤 Отправить табель дальше?',
        `Вы уверены что хотите отправить табель за ${mn} ${selectedYear}?\nПосле отправки редактирование будет заблокировано для вас.`,
        async () => {
            const lastReturn = (wfCurrentStatus.log||[]).slice().reverse().find(l => l.action === 'return' && l.target_step === wfCurrentStatus.current_step);
            const body = {year: selectedYear, month: selectedMonth};
            if (lastReturn) body.return_to_step = lastReturn.step_order;

            // Блокируем кнопку сразу
            const btn = document.querySelector('.wf-submit-btn');
            if(btn) { btn.disabled = true; btn.textContent = '⏳ Отправка...'; }

            try {
                const res = await fetch(API_BASE + 'workflow/submit', {
                    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body)
                });
                const data = await res.json();
                if (res.ok) {
                    if (data.waiting && data.waiting_users) {
                        showToast(`✅ Ваша отправка принята. Ожидаем подтверждения от: ${data.waiting_users.join(', ')}`, 'info', 7000);
                    } else {
                        showToast('✅ Табель успешно передан дальше!', 'success');
                    }
                    // Перезагружаем табель, чтобы обновить статус и скрыть кнопку у всех
                    loadTimesheet();
                } else {
                    showToast('❌ ' + (data.error || 'Ошибка'), 'error');
                    if(btn) { btn.disabled = false; btn.textContent = '📤 Отправить дальше'; }
                }
            } catch(e) {
                showToast('❌ Ошибка сети', 'error');
                if(btn) { btn.disabled = false; btn.textContent = '📤 Отправить дальше'; }
            }
        }
    );
}

async function workflowReturn(targetStep) {
  showPromptModal(
    '🔙 Возврат на доработку',
    'Укажите причину возврата:',
    async (comment) => {
      const res = await fetch(API_BASE + 'workflow/return', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({year: selectedYear, month: selectedMonth, target_step: targetStep, comment})
      });
      if (res.ok) {
        showToast('🔙 Возвращено на доработку', 'warning');
        loadTimesheet();
      } else {
        const err = await res.json();
        showToast('❌ ' + (err.error || 'Ошибка'), 'error');
      }
    }
  );
}

// ═══════════════════════════════════════════
// ═══════════════════════════════════════════
// EXPERIENCE (СТАЖ)
// ═══════════════════════════════════════════
let allExpEmployees = [];
let currentExpEmpId = null;

async function loadExperiencePage() {
  const res = await fetch(API_BASE + 'experience/all');
  if (!res.ok) return;
  allExpEmployees = await res.json();
  renderExpEmployees(allExpEmployees);
}

function filterExpEmployees(q) {
  const filtered = q.length < 1 ? allExpEmployees : 
    allExpEmployees.filter(e => e.full_name.toLowerCase().includes(q.toLowerCase()));
  renderExpEmployees(filtered);
}

function renderExpEmployees(list) {
  const el = document.getElementById('expEmployeesList');
  if (!list.length) { el.innerHTML = '<div class="empty-state"><p>Нет сотрудников</p></div>'; return; }
  el.innerHTML = `<div style="display:grid;gap:6px">${list.map(e => {
    const exp = e.experience;
    const badge = exp.total_days > 0 ? `<span style="color:var(--primary);font-weight:600">${exp.display}</span>` : '<span style="color:var(--text-tertiary)">не указан</span>';
    const periods = exp.periods ? exp.periods.length : 0;
    return `<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);cursor:pointer" onclick="openExpModal(${e.id})">
      <div>
        <div style="font-weight:500">${e.full_name}</div>
        <div style="font-size:12px;color:var(--text-tertiary)">${e.db_name} · ${periods} период(ов)</div>
      </div>
      <div style="text-align:right">${badge}</div>
    </div>`;
  }).join('')}</div>`;
}

async function openExpModal(empId) {
  currentExpEmpId = empId;
  const emp = allExpEmployees.find(e => e.id === empId);
  document.getElementById('expModalTitle').textContent = 'Стаж: ' + (emp ? emp.full_name : '');
  document.getElementById('expModal').style.display = 'flex';
  document.getElementById('expDateFrom').value = '';
  document.getElementById('expDateTo').value = '';
  document.getElementById('expDateTo').disabled = false;
  document.getElementById('expIsCurrent').checked = false;
  document.getElementById('expNote').value = '';
  await refreshExpPeriods();
}

function closeExpModal() {
  document.getElementById('expModal').style.display = 'none';
  currentExpEmpId = null;
}

async function refreshExpPeriods() {
  const res = await fetch(API_BASE + `experience/${currentExpEmpId}`);
  const data = await res.json();
  document.getElementById('expTotalDisplay').textContent = data.display || '—';
  const container = document.getElementById('expPeriodsContainer');
  if (!data.periods || !data.periods.length) {
    container.innerHTML = '<p style="color:var(--text-tertiary);font-size:13px">Нет периодов</p>';
    return;
  }
  container.innerHTML = data.periods.map(p => {
    const to = (p.is_current == 1) ? 'по настоящее время' : (p.date_to || '?');
    const from = new Date(p.date_from);
    const end = (p.is_current == 1) ? new Date() : (p.date_to ? new Date(p.date_to) : new Date());
    const diffDays = Math.max(0, Math.floor((end - from) / 86400000));
    const yy = Math.floor(diffDays / 365);
    const mm = Math.floor((diffDays % 365) / 30);
    const dd = diffDays % 365 % 30;
    let dur = '';
    if (yy > 0) dur += yy + ' г. ';
    if (mm > 0) dur += mm + ' м. ';
    if (dd > 0 || !dur) dur += dd + ' д.';
    return `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--surface2);border-radius:var(--radius);margin-bottom:6px">
      <div style="flex:1">
        <div style="font-weight:500;font-size:13px">${p.date_from} — ${to}</div>
        <div style="font-size:12px;color:var(--primary);font-weight:500">${dur.trim()}</div>
        ${p.note ? `<div style="font-size:12px;color:var(--text-tertiary)">${p.note}</div>` : ''}
      </div>
      <button class="btn btn-ghost" onclick="deleteExpPeriod(${p.id})" style="color:var(--danger);font-size:12px;padding:4px 8px">✕</button>
    </div>`;
  }).join('');
  
  // Update allExpEmployees cache
  const emp = allExpEmployees.find(e => e.id === currentExpEmpId);
  if (emp) { emp.experience = data; }
}

async function saveExpPeriod() {
  const dateFrom = document.getElementById('expDateFrom').value;
  const dateTo = document.getElementById('expDateTo').value;
  const isCurrent = document.getElementById('expIsCurrent').checked;
  const note = document.getElementById('expNote').value;
  if (!dateFrom) { showToast('Укажите дату начала', 'warning'); return; }
  if (!isCurrent && !dateTo) { showToast('Укажите дату окончания или отметьте "работает"', 'warning'); return; }
  
  try {
    const res = await fetch(API_BASE + `experience/${currentExpEmpId}`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ date_from: dateFrom, date_to: isCurrent ? null : dateTo, is_current: isCurrent, note: note || '' })
    });
    if (!res.ok) { const err = await res.text(); showToast('Ошибка: ' + err, 'error'); return; }
    const data = await res.json();
    
    document.getElementById('expDateFrom').value = '';
    document.getElementById('expDateTo').value = '';
    document.getElementById('expIsCurrent').checked = false;
    document.getElementById('expDateTo').disabled = false;
    document.getElementById('expNote').value = '';
    await refreshExpPeriods();
    renderExpEmployees(allExpEmployees);
    showToast('✅ Период добавлен', 'success');
  } catch(e) {
    showToast('❌ Ошибка сохранения: ' + e.message, 'error');
  }
}

async function deleteExpPeriod(periodId) {
  await fetch(API_BASE + `experience/period/${periodId}`, { method: 'DELETE' });
  await refreshExpPeriods();
  showToast('Период удалён', 'info');
}

// DRAG SELECT FOR CELLS
// ═══════════════════════════════════════════
let dragState = null;
let bulkTargets = [];
let dragJustFinished = false;

function initDragSelect() {
  // Only register once
  if (window._dragSelectInit) return;
  window._dragSelectInit = true;

  document.addEventListener('mousedown', (e) => {
    const cell = e.target.closest('#tsContent td.day-cell[data-emp][data-day]');
    if (!cell || (isWorkflowBlocked() && !meIsAdmin)) return;
    e.preventDefault();
    clearDragSelection();
    const wrap = document.querySelector('.ts-table-wrap');
    if (wrap) wrap.classList.add('dragging');
    dragState = {
      startEmp: Number(cell.dataset.emp),
      startDay: Number(cell.dataset.day),
      active: true
    };
    cell.classList.add('drag-selected');
  });
  
  document.addEventListener('mouseover', (e) => {
    if (!dragState || !dragState.active) return;
    const cell = e.target.closest('#tsContent td.day-cell[data-emp][data-day]');
    if (!cell) return;
    updateDragSelection(Number(cell.dataset.emp), Number(cell.dataset.day));
  });
  
  document.addEventListener('mouseup', (e) => {
    if (!dragState || !dragState.active) return;
    dragState.active = false;
    const wrap = document.querySelector('.ts-table-wrap');
    if (wrap) wrap.classList.remove('dragging');
    const selected = document.querySelectorAll('.day-cell.drag-selected');
    if (selected.length === 1) {
      const c = selected[0];
      clearDragSelection();
      openCellDropdown(e, Number(c.dataset.emp), Number(c.dataset.day));
      dragJustFinished = true;
      setTimeout(() => dragJustFinished = false, 100);
    } else if (selected.length > 1) {
      openBulkCellDropdown(e);
      dragJustFinished = true;
      setTimeout(() => dragJustFinished = false, 100);
    } else {
      dragState = null;
    }
  });
}

function updateDragSelection(endEmp, endDay) {
  const allCells = document.querySelectorAll('td.day-cell[data-emp][data-day]');
  const empIds = [...new Set([...allCells].map(c => Number(c.dataset.emp)))];
  const startEmpIdx = empIds.indexOf(dragState.startEmp);
  const endEmpIdx = empIds.indexOf(endEmp);
  const minEmp = Math.min(startEmpIdx, endEmpIdx);
  const maxEmp = Math.max(startEmpIdx, endEmpIdx);
  const minDay = Math.min(dragState.startDay, endDay);
  const maxDay = Math.max(dragState.startDay, endDay);
  
  allCells.forEach(c => {
    const ce = Number(c.dataset.emp);
    const cd = Number(c.dataset.day);
    const ei = empIds.indexOf(ce);
    if (ei >= minEmp && ei <= maxEmp && cd >= minDay && cd <= maxDay) {
      c.classList.add('drag-selected');
    } else {
      c.classList.remove('drag-selected');
    }
  });
}

function clearDragSelection() {
  document.querySelectorAll('.day-cell.drag-selected').forEach(c => c.classList.remove('drag-selected'));
  dragState = null;
}

function openBulkCellDropdown(event) {
  const selected = document.querySelectorAll('.day-cell.drag-selected');
  if (!selected.length) return;
  
  const targets = [...selected].map(c => ({emp: Number(c.dataset.emp), day: Number(c.dataset.day)}));
  bulkTargets = targets;
  
  const dd = document.getElementById('cellDropdown');
  const rect = selected[selected.length - 1].getBoundingClientRect();
  positionDropdown(dd, rect);
  dd.classList.add('show');
  document.getElementById('customCellValue').value = '';
}

async function setCellStatusBulk(status) {
  if (!bulkTargets.length) return;
  document.getElementById('cellDropdown').classList.remove('show');
  
  bulkTargets.forEach(t => {
    const cell = document.querySelector(`td.day-cell[data-emp="${t.emp}"][data-day="${t.day}"]`);
    if (cell) { cell.textContent = getCellDisplay(status, t.emp, t.day); cell.className = 'day-cell status-' + status; }
  });
  
  // Пересчитать рабочие дни для всех затронутых сотрудников
  const affectedEmpsBulk = new Set(bulkTargets.map(t => t.emp));
  affectedEmpsBulk.forEach(eid => recalcEmployeeSummary(eid));
  
  const cells = [...bulkTargets];
  clearDragSelection();
  bulkTargets = [];
  
  try {
    const res = await fetch(API_BASE + 'timesheet/batch', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({cells, year: selectedYear, month: selectedMonth, status})
    });
    if (!res.ok) throw new Error();
    const data = await res.json();
    showToast(`✅ ${data.count} ячеек`, 'success', 2000);
  } catch(e) {
    showToast('❌ Ошибка сохранения', 'error');
    loadTimesheet();
  }
}
// ═══════════════════════════════════════════
// ADMIN PANEL
// ═══════════════════════════════════════════

async function loadAdminPanel() {
  if (!meIsAdmin) return;
  
  // Load maintenance status
  try {
    const res = await fetch(API_BASE + 'maintenance');
    const data = await res.json();
    document.getElementById('maintenanceToggle').checked = data.enabled;
    document.getElementById('maintenanceLabel').textContent = data.enabled ? '🔴 Включён' : 'Выключен';
    document.getElementById('maintenanceMessage').value = data.message || '';
  } catch(e) {}
  
  // Populate target selector with databases
  const sel = document.getElementById('sysNotifTarget');
  sel.innerHTML = '<option value="all">Всем пользователям</option>';
  if (accessibleDbs && accessibleDbs.length) {
    accessibleDbs.forEach(db => {
      sel.innerHTML += `<option value="${escHtml(db.name)}">${escHtml(db.display_name)}</option>`;
    });
  }
}

function toggleMaintenance() {
  const on = document.getElementById('maintenanceToggle').checked;
  document.getElementById('maintenanceLabel').textContent = on ? '🔴 Включён' : 'Выключен';
}

async function saveMaintenance() {
  const enabled = document.getElementById('maintenanceToggle').checked;
  const message = document.getElementById('maintenanceMessage').value.trim();
  
  try {
    await fetch(API_BASE + 'maintenance', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({enabled, message})
    });
    showToast(enabled ? '🔧 Техработы включены' : '✅ Техработы выключены', 'success');
  } catch(e) {
    showToast('Ошибка', 'error');
  }
}

async function sendSystemNotification() {
  const message = document.getElementById('sysNotifMessage').value.trim();
  const target = document.getElementById('sysNotifTarget').value;
  
  if (!message) { showToast('Введите сообщение', 'warning'); return; }
  
  try {
    const res = await fetch(API_BASE + 'system_notification', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({message, target})
    });
    const data = await res.json();
    if (data.ok) {
      showToast(`📢 Отправлено ${data.sent_to} пользователям`, 'success');
      document.getElementById('sysNotifMessage').value = '';
    } else {
      showToast(data.error || 'Ошибка', 'error');
    }
  } catch(e) {
    showToast('Ошибка отправки', 'error');
  }
}

// ===== INIT =====
// initMe() handles everything: auth check, db selection, then data load
initMe();