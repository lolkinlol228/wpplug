# Табель учёта рабочего времени — Standalone Docker

Полностью самостоятельный сайт. **Без WordPress. Без PHP.**
Стек: **Node.js 20 + Express + MySQL 8**.

## 🚀 Запуск

```bash
docker compose up -d
```

Через ~20 секунд сайт доступен:

## 🌐 Доступ

| | URL | Логин | Пароль |
|--|--|--|--|
| **Приложение** | http://localhost:3000 | `Frazy` | `FrazyAmp` |

## ✅ Функционал

- 📋 **Табель** — редактирование по дням, статусы (работа, больничный, отпуск и т.д.)
- 👥 **Сотрудники** — добавление, редактирование, увольнение
- 🏷️ **Должности** — управление должностями и плановыми часами
- 📊 **Статистика** — сводка по месяцу
- 📥 **Экспорт Excel** — полный, краткий, по сотруднику
- 🗄️ **Базы данных** — несколько отделов (баз) в одной системе
- 👤 **Пользователи** — управление правами доступа
- 🔔 **Уведомления** — системные сообщения
- 🔐 **Workflow** — цепочка согласования табелей
- 📅 **Стаж** — учёт педагогического стажа
- 🌐 **3 языка** — Русский, Кыргызский, English
- 🔧 **Режим обслуживания** — для суперадмина

## 📁 Структура

```
tabel-standalone/
├── docker-compose.yml
├── Dockerfile
├── package.json
├── docker/
│   └── init.sql          # Схема БД + начальные данные
├── public/
│   ├── app.css           # Все стили
│   ├── app_body.html     # HTML шаблон приложения
│   └── app.js            # Весь фронтенд JavaScript (~3500 строк)
└── src/
    ├── index.js          # Express сервер
    ├── renderer.js       # Server-side рендеринг страниц
    ├── db/index.js       # MySQL пул соединений
    ├── helpers/index.js  # Бизнес-логика (расчёты, календарь)
    └── routes/
        ├── auth.js       # Вход/выход, rate limiting
        ├── api.js        # Все REST API эндпоинты
        └── export.js     # Экспорт в Excel (ExcelJS)
```

## 🔧 Управление

```bash
# Запуск
docker compose up -d

# Логи
docker compose logs -f app
docker compose logs -f db

# Остановка
docker compose down

# Полный сброс (удалить все данные)
docker compose down -v

# Зайти в контейнер
docker exec -it tabel_app sh
docker exec -it tabel_db mysql -u tabel -ptabelpass tabel
```

## ⚙️ Переменные окружения

| Переменная | По умолчанию | Описание |
|--|--|--|
| `DB_HOST` | `db` | Хост MySQL |
| `DB_PORT` | `3306` | Порт MySQL |
| `DB_NAME` | `tabel` | Имя базы данных |
| `DB_USER` | `tabel` | Пользователь БД |
| `DB_PASS` | `tabelpass` | Пароль БД |
| `SESSION_SECRET` | *(см. compose)* | Секрет сессий — **смените в продакшн!** |
| `PORT` | `3000` | Порт приложения |

## 🔒 Продакшн

В `docker-compose.yml` обязательно смените:
```yaml
SESSION_SECRET: ваш_секретный_ключ_минимум_32_символа
```
И смените пароли MySQL.
